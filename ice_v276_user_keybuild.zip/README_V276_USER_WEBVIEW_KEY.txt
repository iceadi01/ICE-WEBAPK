ICE Inject v2.7.6 USER KEY BUILD

Perubahan:
- USER build, tetap wajib key. ADMIN_BUILD = false.
- Fix error: Value <html><body><script ... cannot be converted to JSONObject.
- Aktivasi Key sekarang memakai WebView mini, bukan HttpURLConnection langsung, supaya cocok dengan hosting gratis yang membalas native HTTP dengan HTML/JS.
- Tombol Buka Web sekarang punya JavaScript bridge Android/IceApp, jadi setelah halaman web sukses aktivasi, APK bisa menyimpan key dan langsung unlock.
- Tetap cocok dengan server license v6.5+.

Cara build GitHub:
1. Hapus ZIP source lama di repo.
2. Upload ZIP ini saja.
3. Jalankan workflow Build APK From ZIP.
4. Download artifact ice_v276_user_key_debug_apk.
5. Extract, install ice_v276_user_key_debug.apk.
6. Uninstall APK lama dulu sebelum install.
