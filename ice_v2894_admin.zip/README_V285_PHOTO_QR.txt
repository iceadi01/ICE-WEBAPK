ICE Inject Admin v2.8.5 - Foto QR langsung scan

Perubahan:
- Tombol "Foto QR lalu scan" pada panel Input Scanner.
- Kamera dibuka untuk menjepret QR/barcode.
- Foto disimpan hanya sementara di cache aplikasi, bukan ke galeri.
- Setelah dijepret, aplikasi membaca QR/barcode otomatis.
- Hasil yang terbaca langsung dikirim ke bridge scanner tanpa perlu memilih file atau menekan Kirim.
- File foto sementara langsung dihapus setelah proses baca selesai.
- Mendukung QR Code serta beberapa barcode 1D/2D umum.

Catatan pemakaian:
- Pastikan seluruh QR terlihat, cukup dekat, terang, dan tidak buram.
- Jika tidak terbaca, jepret ulang dengan posisi lebih lurus.
