ICE Inject Admin v2.8.6

FITUR BARU — FOTO BANYAK KE ANTREAN
- Tombol baru: "Jepret Banyak → Antrean".
- Kamera dibuka untuk satu jepretan, hasil langsung dibaca, lalu kamera terbuka kembali otomatis.
- Setiap QR/barcode yang berhasil dibaca hanya ditambahkan ke antrean; belum langsung dikirim ke website.
- Jepretan dapat diteruskan tanpa batas tetap selama kemampuan perangkat masih mencukupi.
- Foto hanya disimpan sementara di cache lalu langsung dihapus, sehingga tidak masuk galeri.
- Kode duplikat otomatis dilewati.
- Foto yang tidak terbaca dihitung gagal lalu kamera dibuka lagi.
- Tekan tombol Kembali pada kamera untuk menyelesaikan sesi.
- Dialog Antrean QR otomatis terbuka; tekan Mulai untuk mengirim satu per satu.
- Antrean yang sedang berjalan dijeda saat mode foto banyak dimulai.

FITUR FOTO SATUAN TETAP ADA
- Tombol "Foto QR lalu scan" tetap membaca lalu langsung mengirim satu kode.

VERSI
- Nama aplikasi: ICE Inject Admin
- Package/application ID: com.mimar.iceinject.admin
- Version code: 26
- Version name: 2.8.6-admin
- Mode admin / ADMIN_BUILD=true.

BUILD
- Jalankan workflow .github/workflows/build-apk.yml melalui GitHub Actions.
- Hasil artifact: ice_v286_admin.apk.
- Repository wajib Private karena source memuat keystore penandatanganan.
