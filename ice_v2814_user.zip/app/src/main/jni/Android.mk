LOCAL_PATH := $(call my-dir)

# Diambil otomatis oleh workflow GitHub Actions.
TOP_PATH := $(LOCAL_PATH)/hev-socks5-tunnel
include $(TOP_PATH)/Android.mk

LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := ice-dual-jni
LOCAL_SRC_FILES := ice_dual_jni.c
LOCAL_C_INCLUDES := $(LOCAL_PATH)/hev-socks5-tunnel/src
LOCAL_SHARED_LIBRARIES := hev-socks5-tunnel
LOCAL_LDLIBS := -llog
LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384
LOCAL_LDFLAGS += -Wl,-z,common-page-size=16384
include $(BUILD_SHARED_LIBRARY)
