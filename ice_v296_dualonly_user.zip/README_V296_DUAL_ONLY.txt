ICE Dual v2.9.6 — User

Perubahan utama:
- Seluruh userscript/Tampermonkey dan bridge.js dihapus.
- Panel input scanner, kirim kode, foto QR, dan antrean QR dihapus.
- JavaScript interface khusus scanner tidak lagi dipasang ke WebView.
- Dependency ZXing dan activity kamera QR tambahan dihapus.
- Tombol volume tidak lagi dipakai untuk membuka panel scanner.
- Fitur dual jaringan tetap dipertahankan:
  * LP4M / alamat perusahaan diarahkan melalui Wi-Fi perusahaan.
  * Login, lisensi, dan web umum diarahkan melalui data seluler.
  * Wi-Fi kerja dapat disimpan dan disambungkan kembali.
- Kamera dan lokasi WebView tetap tersedia untuk kebutuhan halaman perusahaan.
- Paket aplikasi tetap com.mimar.iceinject agar dapat memperbarui versi lama.
- Nama aplikasi tampil sebagai ICE Dual.

Build:
  chmod +x build_user.sh
  ./build_user.sh

Output:
  ice_v296_user.apk
