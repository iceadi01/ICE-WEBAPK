ICE Inject v2.8.13 USER

Perubahan routing dinamis:
- Dibangun dari source asli v2.8.9 agar perilaku penangkapan Wi-Fi tetap ringan.
- Halaman lokal tidak lagi selalu memaksa seluruh proses ke Wi-Fi biasa; Android memilih route subnet seperti Chrome.
- Route/prefix Wi-Fi dibaca langsung dari LinkProperties Android.
- Seluruh alamat privat/internal tetap didukung sebagai fallback: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, link-local, CGNAT, dan IPv6 ULA.
- Alamat report 172.30.2.40:8081 otomatis dianggap jaringan perusahaan.
- Jika route otomatis gagal, ICE mencoba ulang satu kali dengan binding langsung ke Wi-Fi.
- Wi-Fi khusus dari WifiNetworkSpecifier tetap memakai binding langsung karena network itu bukan default Android.
- Internet umum serta login/lisensi tetap memakai data seluler.

Catatan pengujian:
APK perlu dibuild dan diuji langsung pada Wi-Fi perusahaan karena jaringan tersebut tidak tersedia di lingkungan build.
