package com.mimar.iceinject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.VpnService;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class MainActivity extends Activity {
    // Diganti otomatis saat build admin/user.
    private static final boolean ADMIN_BUILD = false;

    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_URL = "company_url";
    private static final String PREF_LICENSE_SERVER = "license_server";
    private static final String PREF_LICENSE_KEY = "license_key";
    private static final String PREF_LICENSE_TOKEN = "license_token";
    private static final String PREF_LICENSE_EXPIRY = "license_expiry_ms";
    private static final String PREF_LICENSE_CREATED = "license_created_ms";
    private static final String PREF_LICENSE_DURATION_LABEL = "license_duration_label";
    private static final String PREF_LAST_SERVER_TIME = "last_server_time_ms";
    private static final String PREF_LAST_SERVER_ELAPSED = "last_server_elapsed_ms";
    private static final String PREF_LAST_CHECK = "last_license_check_ms";
    private static final String PREF_DEVICE_ID = "device_id_fallback";
    private static final String PREF_BOOKMARKS = "browser_bookmarks";
    private static final String PREF_DESKTOP_MODE = "desktop_mode";
    private static final String PREF_BATCH_QUEUE = "batch_queue_json";
    private static final String PREF_BATCH_SEEN = "batch_seen_json";
    private static final String PREF_BATCH_SENT = "batch_sent";
    private static final String PREF_BATCH_FAILED = "batch_failed";
    private static final String PREF_BATCH_DUPLICATES = "batch_duplicates";
    private static final String PREF_BATCH_DELAY = "batch_delay_ms";
    private static final String PREF_WORK_WIFI_SSID = "work_wifi_ssid";
    private static final String PREF_WORK_WIFI_PASSWORD = "work_wifi_password";
    private static final String PREF_WORK_WIFI_AUTO = "work_wifi_auto";

    private static final String DEFAULT_URL = "https://lp4m-lpw.liebrapermana.com";
    private static final String DEFAULT_LICENSE_SERVER = "https://accuracy.fwh.is";
    private static final String APP_VERSION = "2.8.21";
    // Mode kerja: boleh tetap masuk di WiFi lokal tanpa internet jika lisensi sudah pernah valid online.
    // Batas ini tidak memperpanjang masa key; tetap mengikuti expired dari server.
    private static final long OFFLINE_WORK_GRACE_MS = 18L * 60L * 60L * 1000L;
    private static final long LICENSE_CHECK_INTERVAL_MS = 15000L;
    private static final int CAMERA_PERMISSION_REQUEST = 42;
    private static final int LOCATION_PERMISSION_REQUEST = 43;
    private static final int PHOTO_QR_REQUEST = 44;
    private static final int MULTI_PHOTO_QR_REQUEST = 45;
    private static final int IN_APP_PHOTO_QR_REQUEST = 46;
    private static final int SYSTEM_VPN_REQUEST = 47;

    private SharedPreferences preferences;
    private String bridgeScript = "";
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private LinearLayout tabBar;
    private EditText addressInput;
    private TextView securityIcon;
    private Button reloadButton;
    private Button bookmarkButton;
    private Button tabsButton;
    private Button scanToggleButton;
    private ProgressBar pageProgress;
    private boolean pageLoading = false;
    private FrameLayout webContainer;
    private LinearLayout toolsPanel;
    private LinearLayout showToolsBar;
    private EditText codeInput;
    private TextView statusText;
    private TextView callbackBadge;
    private TextView licenseBadge;
    private TextView networkBadge;
    private Button batchManualSendButton;
    private Button batchQueueButton;
    private Dialog batchDialog;
    private EditText batchPasteInput;
    private EditText batchDelayInput;
    private TextView batchStatsText;
    private Button batchStartButton;

    private final List<String> batchQueue = new ArrayList<String>();
    private final LinkedHashMap<String, Boolean> batchSeen = new LinkedHashMap<String, Boolean>();
    private int batchSent = 0;
    private int batchFailed = 0;
    private int batchDuplicates = 0;
    private int batchDelayMs = 800;
    private boolean batchRunning = false;
    private boolean batchPaused = false;
    private boolean batchAwaitingResult = false;
    private boolean batchManualSingleMode = false;
    private boolean batchRestorePausedAfterManual = false;
    private int batchRetryCount = 0;
    private int batchSendToken = 0;

    private final Runnable batchRunnable = new Runnable() {
        @Override
        public void run() {
            processNextBatchCode();
        }
    };

    private final List<TabState> tabs = new ArrayList<TabState>();
    private TabState currentTab;
    private int nextTabNumber = 1;
    private boolean toolsVisible = false;
    private boolean browserStarted = false;
    private boolean licenseUnlocked = ADMIN_BUILD;
    private boolean licenseCheckInProgress = false;

    // Dual network: LP4M memakai Wi-Fi perusahaan, sedangkan login/lisensi dan web umum memakai data seluler.
    private ConnectivityManager connectivityManager;
    private Network wifiNetwork;
    private Network observedWifiNetwork;
    private Network localOnlyWifiNetwork;
    private Network cellularNetwork;
    private Network boundNetwork;
    private ConnectivityManager.NetworkCallback wifiNetworkCallback;
    private ConnectivityManager.NetworkCallback cellularNetworkCallback;
    private ConnectivityManager.NetworkCallback localOnlyWifiCallback;
    private boolean networkCallbacksRegistered = false;
    private boolean localOnlyWifiRequestActive = false;
    private boolean pendingWorkWifiPermission = false;
    private boolean pendingSystemVpnStart = false;
    private boolean systemVpnRunning = false;
    private String systemVpnMessage = "Dual jaringan sistem belum aktif";
    private boolean dualVpnReceiverRegistered = false;
    private int internetRouteDepth = 0;
    private boolean lastCompanyWifiMissing = false;
    private String runtimeUsername = "";
    private String runtimeSessionToken = "";
    private long runtimeSessionExpiry = 0L;
    private final Runnable licenseWatchdog = new Runnable() {
        @Override
        public void run() {
            if (!ADMIN_BUILD) {
                if (licenseUnlocked) {
                    // Mode kerja: saat aplikasi dipakai tetap cek server berkala jika internet tersedia.
                    // Jika sedang WiFi lokal tanpa internet, cache aktif diberi toleransi terbatas.
                    validateLicenseAsync(false);
                } else {
                    // sedang terkunci, jangan munculkan dialog berulang.
                }
                handler.postDelayed(this, LICENSE_CHECK_INTERVAL_MS);
            }
        }
    };
    private PermissionRequest pendingPermissionRequest;
    private GeolocationPermissions.Callback pendingGeolocationCallback;
    private String pendingGeolocationOrigin;
    private boolean pendingPhotoCaptureAfterPermission = false;
    private boolean multiPhotoCaptureMode = false;
    private int multiPhotoAdded = 0;
    private int multiPhotoDuplicates = 0;
    private int multiPhotoFailed = 0;
    private File pendingQrPhotoFile;
    private Uri pendingQrPhotoUri;
    private boolean multiPhotoReceiverRegistered = false;

    private final BroadcastReceiver dualVpnStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !DualNetworkVpnService.ACTION_STATE.equals(intent.getAction())) return;
            systemVpnRunning = intent.getBooleanExtra(DualNetworkVpnService.EXTRA_STATE, false);
            String message = intent.getStringExtra(DualNetworkVpnService.EXTRA_MESSAGE);
            if (message != null && message.trim().length() > 0) systemVpnMessage = message.trim();
            updateNetworkBadge();
            if (!systemVpnRunning) {
                String lower = systemVpnMessage.toLowerCase(Locale.US);
                if (lower.contains("gagal") || lower.contains("berhenti") || lower.contains("mendadak")) {
                    setStatus(systemVpnMessage);
                }
            }
        }
    };

    private final BroadcastReceiver multiPhotoResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !MultiPhotoCameraActivity.ACTION_RESULT.equals(intent.getAction())) return;
            String kind = intent.getStringExtra(MultiPhotoCameraActivity.EXTRA_KIND);
            if ("failed".equals(kind)) {
                multiPhotoFailed++;
                return;
            }
            if (!"code".equals(kind)) return;
            String code = intent.getStringExtra(MultiPhotoCameraActivity.EXTRA_CODE);
            code = code == null ? "" : code.trim();
            if (code.length() == 0) return;

            boolean added = addPhotoCodeToBatch(code);
            if (added) multiPhotoAdded++;
            else multiPhotoDuplicates++;

            Intent feedback = new Intent(MultiPhotoCameraActivity.ACTION_FEEDBACK);
            feedback.setPackage(getPackageName());
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_CODE, code);
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_ADDED, added);
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_QUEUE_SIZE, batchQueue.size());
            sendBroadcast(feedback);
        }
    };

    private static class TabState {
        int number;
        WebView webView;
        Button button;
        String title;
        String currentUrl;
        int callbackCount;
        int loadToken;
        boolean destroyed;
    }

    private static class BookmarkItem {
        String name;
        String url;

        BookmarkItem(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    private interface ApiCallback {
        void onResult(boolean success, JSONObject data, String error);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method status = Window.class.getMethod("setStatusBarColor", int.class);
                status.invoke(getWindow(), Color.rgb(32, 33, 36));
                Method navigation = Window.class.getMethod("setNavigationBarColor", int.class);
                navigation.invoke(getWindow(), Color.rgb(32, 33, 36));
            } catch (Throwable ignored) {}
        }

        preferences = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        bridgeScript = readAsset("bridge.js");
        loadBatchState();
        registerMultiPhotoReceiver();
        registerDualVpnReceiver();

        buildInterface();
        initializeDualNetworkRouting();
        requestCameraPermissionIfNeeded();

        if (ADMIN_BUILD) {
            licenseUnlocked = true;
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            startBrowserIfNeeded();
        } else {
            // v2.8.0: mode login user/password.
            // Setiap aplikasi dibuka dari awal harus login online lagi. Sesi hanya disimpan di memori saat APK masih hidup.
            licenseUnlocked = false;
            runtimeUsername = "";
            runtimeSessionToken = "";
            runtimeSessionExpiry = 0L;
            setLicenseBadge("LOGIN", Color.rgb(202, 138, 4));
            if (preferences.getString(PREF_LICENSE_SERVER, "").length() == 0) {
                preferences.edit().putString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER).apply();
            }
            preferences.edit()
                    .remove(PREF_LICENSE_TOKEN)
                    .remove(PREF_LICENSE_EXPIRY)
                    .remove(PREF_LICENSE_CREATED)
                    .putLong(PREF_LAST_CHECK, 0L)
                    .apply();
            showActivationDialog(true);
        }
        startLicenseWatchdog();
    }

    private void buildInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248, 249, 250));

        // Bilah atas bergaya Chrome.
        LinearLayout browserBar = new LinearLayout(this);
        browserBar.setOrientation(LinearLayout.HORIZONTAL);
        browserBar.setGravity(Gravity.CENTER_VERTICAL);
        browserBar.setPadding(dp(8), dp(7), dp(8), dp(7));
        browserBar.setBackgroundColor(Color.rgb(32, 33, 36));

        Button homeTop = toolbarButton("⌂");
        homeTop.setContentDescription("Beranda");
        homeTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        browserBar.addView(homeTop, new LinearLayout.LayoutParams(dp(40), dp(44)));

        LinearLayout addressCapsule = new LinearLayout(this);
        addressCapsule.setOrientation(LinearLayout.HORIZONTAL);
        addressCapsule.setGravity(Gravity.CENTER_VERTICAL);
        addressCapsule.setPadding(dp(10), 0, dp(3), 0);
        addressCapsule.setBackground(makeRounded(Color.rgb(48, 49, 52), dp(24)));

        securityIcon = new TextView(this);
        securityIcon.setText("●");
        securityIcon.setTextColor(Color.rgb(129, 201, 149));
        securityIcon.setTextSize(10);
        securityIcon.setGravity(Gravity.CENTER);
        securityIcon.setContentDescription("Keamanan halaman");
        securityIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPageInfo();
            }
        });
        addressCapsule.addView(securityIcon, new LinearLayout.LayoutParams(dp(24), dp(44)));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextColor(Color.WHITE);
        addressInput.setHintTextColor(Color.rgb(189, 193, 198));
        addressInput.setTextSize(14);
        addressInput.setHint("Cari atau ketik alamat");
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setPadding(dp(2), 0, dp(3), 0);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                navigateAddressBar();
                return true;
            }
        });
        addressCapsule.addView(addressInput, new LinearLayout.LayoutParams(0, dp(44), 1));

        reloadButton = toolbarButton("↻");
        reloadButton.setContentDescription("Muat ulang");
        reloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab == null) return;
                if (pageLoading) {
                    currentTab.webView.stopLoading();
                } else {
                    injectBridge(currentTab);
                    reloadCurrentTabRouted();
                }
            }
        });
        addressCapsule.addView(reloadButton, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout.LayoutParams capsuleParams = new LinearLayout.LayoutParams(0, dp(44), 1);
        capsuleParams.setMargins(dp(6), 0, dp(5), 0);
        browserBar.addView(addressCapsule, capsuleParams);

        bookmarkButton = toolbarButton("☆");
        bookmarkButton.setTextSize(20);
        bookmarkButton.setContentDescription("Bookmark");
        bookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleCurrentBookmark();
            }
        });
        browserBar.addView(bookmarkButton, new LinearLayout.LayoutParams(dp(40), dp(44)));

        tabsButton = toolbarButton("1");
        tabsButton.setTextSize(12);
        tabsButton.setBackground(makeRoundedStroke(
                Color.TRANSPARENT, dp(7), Color.rgb(218, 220, 224), dp(1)));
        tabsButton.setContentDescription("Daftar tab");
        tabsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTabsDialog();
            }
        });
        LinearLayout.LayoutParams tabsParams = new LinearLayout.LayoutParams(dp(38), dp(34));
        tabsParams.setMargins(dp(4), 0, 0, 0);
        browserBar.addView(tabsButton, tabsParams);

        Button menuButton = toolbarButton("⋮");
        menuButton.setTextSize(24);
        menuButton.setContentDescription("Menu browser");
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBrowserMenu();
            }
        });
        browserBar.addView(menuButton, new LinearLayout.LayoutParams(dp(40), dp(44)));

        root.addView(browserBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        pageProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100);
        pageProgress.setProgress(0);
        pageProgress.setVisibility(View.GONE);
        try {
            pageProgress.getProgressDrawable().setColorFilter(
                    Color.rgb(26, 115, 232), PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {}
        root.addView(pageProgress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(2)));

        // Dipertahankan secara internal untuk kompatibilitas, tetapi tab dibuka lewat tombol jumlah tab.
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setVisibility(View.GONE);

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        root.addView(webContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        // Panel alat scan yang bisa disembunyikan tanpa kehilangan tombol untuk membukanya lagi.
        toolsPanel = new LinearLayout(this);
        toolsPanel.setOrientation(LinearLayout.VERTICAL);
        toolsPanel.setPadding(dp(10), dp(8), dp(10), dp(9));
        toolsPanel.setBackground(makeRounded(Color.rgb(15, 23, 42), dp(16)));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        statusText = new TextView(this);
        statusText.setText("ICE Inject siap");
        statusText.setTextColor(Color.rgb(203, 213, 225));
        statusText.setTextSize(12);
        statusText.setSingleLine(true);
        statusRow.addView(statusText, new LinearLayout.LayoutParams(0, dp(34), 1));

        networkBadge = new TextView(this);
        networkBadge.setText("JARINGAN");
        networkBadge.setTextColor(Color.WHITE);
        networkBadge.setTextSize(10);
        networkBadge.setGravity(Gravity.CENTER);
        networkBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        networkBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        networkBadge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleNetworkBadgeClick();
            }
        });
        networkBadge.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showDualNetworkInfo();
                return true;
            }
        });
        LinearLayout.LayoutParams networkParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        networkParams.setMargins(0, 0, dp(5), 0);
        statusRow.addView(networkBadge, networkParams);

        licenseBadge = new TextView(this);
        licenseBadge.setText("LISENSI");
        licenseBadge.setTextColor(Color.WHITE);
        licenseBadge.setTextSize(10);
        licenseBadge.setGravity(Gravity.CENTER);
        licenseBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        licenseBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        statusRow.addView(licenseBadge);

        callbackBadge = new TextView(this);
        callbackBadge.setText("CB: 0");
        callbackBadge.setTextColor(Color.WHITE);
        callbackBadge.setTextSize(10);
        callbackBadge.setGravity(Gravity.CENTER);
        callbackBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        callbackBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        LinearLayout.LayoutParams callbackParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        callbackParams.setMargins(dp(5), 0, 0, 0);
        statusRow.addView(callbackBadge, callbackParams);

        Button hideButton = smallButton("Tutup");
        hideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideTools();
            }
        });
        statusRow.addView(hideButton);
        toolsPanel.addView(statusRow);

        codeInput = new EditText(this);
        codeInput.setHint("Ketik isi QR / barcode");
        codeInput.setSingleLine(true);
        codeInput.setTextSize(17);
        codeInput.setTextColor(Color.WHITE);
        codeInput.setHintTextColor(Color.rgb(148, 163, 184));
        codeInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        codeInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        codeInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(10)));
        codeInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                sendCode(true);
                return true;
            }
        });
        toolsPanel.addView(codeInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setOrientation(LinearLayout.HORIZONTAL);
        sendRow.setPadding(0, dp(7), 0, 0);

        Button sendButton = actionButton("Kirim", Color.rgb(37, 99, 235));
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode(false);
            }
        });
        sendRow.addView(sendButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button sendClearButton = actionButton("Kirim + Kosongkan", Color.rgb(13, 148, 136));
        sendClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode(true);
            }
        });
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(0, dp(46), 1.45f);
        clearParams.setMargins(dp(7), 0, 0, 0);
        sendRow.addView(sendClearButton, clearParams);

        Button checkButton = actionButton("Cek", Color.rgb(71, 85, 105));
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkScanner();
            }
        });
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(0, dp(46), 0.65f);
        checkParams.setMargins(dp(7), 0, 0, 0);
        sendRow.addView(checkButton, checkParams);

        toolsPanel.addView(sendRow);

        Button photoQrButton = actionButton("📷 Foto QR lalu scan", Color.rgb(124, 58, 237));
        photoQrButton.setContentDescription("Buka kamera, foto QR, lalu kirim hasil ke scanner");
        photoQrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQrPhotoCapture();
            }
        });
        LinearLayout.LayoutParams photoQrParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        photoQrParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(photoQrButton, photoQrParams);

        Button multiPhotoQrButton = actionButton("📸 Jepret Banyak → Antrean", Color.rgb(147, 51, 234));
        multiPhotoQrButton.setContentDescription("Jepret QR berulang, kumpulkan ke antrean, lalu kirim bertahap");
        multiPhotoQrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMultiQrPhotoCapture();
            }
        });
        LinearLayout.LayoutParams multiPhotoQrParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        multiPhotoQrParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(multiPhotoQrButton, multiPhotoQrParams);

        batchManualSendButton = actionButton("Kirim 1 dari antrean", Color.rgb(22, 163, 74));
        batchManualSendButton.setContentDescription("Kirim satu kode pertama dari antrean QR");
        batchManualSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendNextBatchCodeManually();
            }
        });
        LinearLayout.LayoutParams manualBatchParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        manualBatchParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(batchManualSendButton, manualBatchParams);

        batchQueueButton = actionButton("Antrean QR", Color.rgb(234, 88, 12));
        batchQueueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBatchQueueDialog();
            }
        });
        LinearLayout.LayoutParams batchButtonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        batchButtonParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(batchQueueButton, batchButtonParams);
        updateBatchUi();

        toolsPanel.setVisibility(View.GONE);
        root.addView(toolsPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // Navigasi bawah: selalu terlihat sehingga panel input bisa dimunculkan lagi kapan saja.
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(5), dp(4), dp(5), dp(4));
        bottomBar.setBackgroundColor(Color.rgb(32, 33, 36));

        Button backButton = bottomButton("‹", "Kembali");
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoBack()) currentTab.webView.goBack();
            }
        });
        bottomBar.addView(backButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button forwardButton = bottomButton("›", "Maju");
        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoForward()) currentTab.webView.goForward();
            }
        });
        bottomBar.addView(forwardButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button homeButton = bottomButton("⌂", "Beranda");
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        bottomBar.addView(homeButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button newTabButton = bottomButton("＋", "Tab baru");
        newTabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!licenseUnlocked) {
                    showActivationDialog(true);
                    return;
                }
                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            }
        });
        bottomBar.addView(newTabButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        scanToggleButton = bottomButton("⌨", "Input scanner");
        scanToggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toolsVisible) hideTools(); else showTools();
            }
        });
        bottomBar.addView(scanToggleButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        root.addView(bottomBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        // Kompatibilitas field lama; tombol pemuncul kini selalu ada di navigasi bawah.
        showToolsBar = new LinearLayout(this);
        showToolsBar.setVisibility(View.GONE);

        setContentView(root);
    }



    private void initializeDualNetworkRouting() {
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) {
                updateNetworkBadge();
                return;
            }

            discoverExistingNetworks();

            // Hanya memantau Wi-Fi biasa. Jangan request Wi-Fi generik karena itu dapat
            // membuat Wi-Fi perusahaan tetap menjadi jalur utama seluruh HP.
            NetworkRequest wifiRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            wifiNetworkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    observedWifiNetwork = network;
                    if (localOnlyWifiNetwork == null) wifiNetwork = network;
                    lastCompanyWifiMissing = false;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(observedWifiNetwork)) observedWifiNetwork = null;
                    if (localOnlyWifiNetwork == null && network != null && network.equals(wifiNetwork)) {
                        wifiNetwork = null;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        observedWifiNetwork = network;
                        if (localOnlyWifiNetwork == null) wifiNetwork = network;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshNetworkRoute();
                            }
                        });
                    }
                }
            };

            NetworkRequest cellularRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            cellularNetworkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    cellularNetwork = network;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(cellularNetwork)) cellularNetwork = null;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        cellularNetwork = network;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshNetworkRoute();
                            }
                        });
                    }
                }
            };

            connectivityManager.registerNetworkCallback(wifiRequest, wifiNetworkCallback);
            // Menahan radio seluler untuk proses ICE. Ini tidak mengubah jalur aplikasi lain,
            // tetapi membantu data tetap siap saat koneksi Wi-Fi khusus aktif.
            connectivityManager.requestNetwork(cellularRequest, cellularNetworkCallback);
            networkCallbacksRegistered = true;
        } catch (Throwable error) {
            networkCallbacksRegistered = false;
            setStatus("Dual jaringan belum siap: " + safeMessage(error));
        }
        refreshNetworkRoute();
    }

    private void discoverExistingNetworks() {
        if (connectivityManager == null) return;
        try {
            Network[] networks = connectivityManager.getAllNetworks();
            if (networks == null) return;
            for (Network network : networks) {
                NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
                if (capabilities == null) continue;
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    observedWifiNetwork = network;
                    if (localOnlyWifiNetwork == null) wifiNetwork = network;
                }
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    cellularNetwork = network;
                }
            }
        } catch (Throwable ignored) {}
    }

    private void beginInternetRoute() {
        internetRouteDepth++;
        refreshNetworkRoute();
    }

    private void endInternetRoute() {
        if (internetRouteDepth > 0) internetRouteDepth--;
        refreshNetworkRoute();
    }

    private ApiCallback beginInternetRouteForCallback(final ApiCallback callback) {
        beginInternetRoute();
        return new ApiCallback() {
            private boolean completed = false;

            @Override
            public synchronized void onResult(boolean success, JSONObject data, String error) {
                if (completed) return;
                completed = true;
                endInternetRoute();
                if (callback != null) callback.onResult(success, data, error);
            }
        };
    }

    private void finishLicenseCheckRoute() {
        licenseCheckInProgress = false;
        refreshNetworkRoute();
    }

    private void refreshNetworkRoute() {
        if (connectivityManager == null) {
            updateNetworkBadge();
            return;
        }

        boolean needsInternet = !licenseUnlocked || licenseCheckInProgress || internetRouteDepth > 0;
        String activeUrl = currentTab == null ? preferences.getString(PREF_URL, DEFAULT_URL) : currentTab.currentUrl;
        boolean companyPage = isCompanyUrl(activeUrl);

        Network desired;
        if (needsInternet || !companyPage) {
            desired = cellularNetwork;
        } else {
            desired = wifiNetwork;
        }

        if (desired == null) {
            clearProcessNetworkBinding();
        } else {
            bindProcessNetwork(desired);
        }

        if (!needsInternet && companyPage && wifiNetwork == null) {
            if (!lastCompanyWifiMissing) {
                lastCompanyWifiMissing = true;
                setStatus("Sambungkan Wi-Fi perusahaan agar LP4M dapat dibuka.");
            }
        } else {
            lastCompanyWifiMissing = false;
        }
        updateNetworkBadge();
    }

    private void bindProcessNetwork(Network network) {
        if (connectivityManager == null || network == null) return;
        if (network.equals(boundNetwork)) return;
        try {
            boolean ok;
            if (Build.VERSION.SDK_INT >= 23) {
                ok = connectivityManager.bindProcessToNetwork(network);
            } else {
                ok = ConnectivityManager.setProcessDefaultNetwork(network);
            }
            if (ok) boundNetwork = network;
        } catch (Throwable error) {
            setStatus("Gagal memilih jalur jaringan: " + safeMessage(error));
        }
    }

    private void clearProcessNetworkBinding() {
        if (connectivityManager == null) return;
        if (boundNetwork == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                connectivityManager.bindProcessToNetwork(null);
            } else {
                ConnectivityManager.setProcessDefaultNetwork(null);
            }
        } catch (Throwable ignored) {}
        boundNetwork = null;
    }

    private boolean isCompanyUrl(String value) {
        if (value == null || value.length() == 0) return true;
        if (value.startsWith("javascript:") || value.startsWith("about:")
                || value.startsWith("data:") || value.startsWith("blob:")
                || value.startsWith("file:")) return true;
        try {
            Uri uri = Uri.parse(normalizeUrl(value));
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.US);
            if ("lp4m-lpw.liebrapermana.com".equals(host)) return true;

            String home = preferences == null ? DEFAULT_URL : preferences.getString(PREF_URL, DEFAULT_URL);
            String homeHost = Uri.parse(normalizeUrl(home)).getHost();
            if (homeHost != null && host.equals(homeHost.toLowerCase(Locale.US))) return true;

            String[] parts = host.split("\\.");
            if (parts.length == 4) {
                int a = Integer.parseInt(parts[0]);
                int b = Integer.parseInt(parts[1]);
                int c = Integer.parseInt(parts[2]);
                return a == 172 && b == 30 && c >= 16 && c <= 31;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void loadUrlRouted(final TabState tab, final String rawUrl) {
        if (tab == null || tab.destroyed || tab.webView == null) return;
        final String url = rawUrl == null ? DEFAULT_URL : normalizeUrl(rawUrl);
        tab.currentUrl = url;
        if (tab == currentTab) refreshNetworkRoute();
        tab.webView.loadUrl(url);
    }

    private void reloadCurrentTabRouted() {
        if (currentTab == null || currentTab.destroyed || currentTab.webView == null) return;
        refreshNetworkRoute();
        try {
            currentTab.webView.reload();
        } catch (Throwable ignored) {}
    }

    private void updateNetworkBadge() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (networkBadge == null) return;
                boolean systemDual = systemVpnRunning;
                boolean wifi = wifiNetwork != null;
                boolean cell = cellularNetwork != null;
                boolean defaultCell = isDefaultNetworkCellular();
                boolean special = localOnlyWifiNetwork != null;
                String text;
                int color;
                if (systemDual) {
                    text = "DUAL SISTEM";
                    color = Color.rgb(22, 163, 74);
                } else if (special && defaultCell && cell) {
                    text = "DUAL ICE";
                    color = Color.rgb(37, 99, 235);
                } else if (wifi && cell && !defaultCell) {
                    text = "WIFI DOMINAN";
                    color = Color.rgb(202, 138, 4);
                } else if (wifi && cell) {
                    text = "WIFI+DATA";
                    color = Color.rgb(37, 99, 235);
                } else if (wifi) {
                    text = "WIFI";
                    color = Color.rgb(202, 138, 4);
                } else if (cell) {
                    text = "DATA";
                    color = Color.rgb(37, 99, 235);
                } else {
                    text = "PUTUS";
                    color = Color.rgb(185, 28, 28);
                }
                networkBadge.setText(text);
                networkBadge.setBackground(makeRounded(color, dp(14)));
            }
        });
    }

    private boolean isDefaultNetworkCellular() {
        if (connectivityManager == null || Build.VERSION.SDK_INT < 23) return false;
        try {
            Network active = connectivityManager.getActiveNetwork();
            NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(active);
            return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private String currentWifiSsid() {
        try {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (manager == null) return "";
            WifiInfo info = manager.getConnectionInfo();
            if (info == null) return "";
            String ssid = info.getSSID();
            if (ssid == null || "<unknown ssid>".equalsIgnoreCase(ssid)) return "";
            if (ssid.length() >= 2 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                ssid = ssid.substring(1, ssid.length() - 1);
            }
            return ssid;
        } catch (Throwable ignored) {
            return "";
        }
    }


    private void handleNetworkBadgeClick() {
        if (Build.VERSION.SDK_INT < 29) {
            showDualNetworkInfo();
            return;
        }
        if (systemVpnRunning) {
            setStatus(systemVpnMessage);
            showDualNetworkInfo();
            return;
        }
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            pendingSystemVpnStart = true;
            requestLocationPermissionIfNeeded();
            setStatus("Izinkan lokasi agar Android dapat memilih Wi-Fi kerja.");
            return;
        }
        pendingSystemVpnStart = true;
        if (localOnlyWifiNetwork != null) {
            beginSystemVpnPermission();
            return;
        }
        String savedSsid = preferences.getString(PREF_WORK_WIFI_SSID, "").trim();
        String savedPassword = preferences.getString(PREF_WORK_WIFI_PASSWORD, "");
        if (savedSsid.length() > 0) {
            preferences.edit().putBoolean(PREF_WORK_WIFI_AUTO, true).apply();
            setStatus("Menyambungkan Wi-Fi " + savedSsid + " sebelum mengaktifkan dual sistem…");
            connectWorkWifiLocalOnly(savedSsid, savedPassword, true);
            return;
        }
        showDualNetworkInfo();
    }

    private void beginSystemVpnPermission() {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) {
                startActivityForResult(prepare, SYSTEM_VPN_REQUEST);
            } else {
                startSystemDualService();
            }
        } catch (Throwable error) {
            pendingSystemVpnStart = false;
            setStatus("Gagal meminta izin VPN: " + safeMessage(error));
        }
    }

    private void startSystemDualService() {
        try {
            Intent service = new Intent(this, DualNetworkVpnService.class);
            service.setAction(DualNetworkVpnService.ACTION_CONNECT);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            pendingSystemVpnStart = false;
            setStatus("Mengaktifkan dual jaringan sistem untuk Chrome dan browser lain…");
            handler.postDelayed(new Runnable() {
                @Override public void run() { updateNetworkBadge(); }
            }, 1200L);
        } catch (Throwable error) {
            pendingSystemVpnStart = false;
            setStatus("Gagal memulai dual jaringan sistem: " + safeMessage(error));
        }
    }

    private void stopSystemDualService() {
        try {
            Intent service = new Intent(this, DualNetworkVpnService.class);
            service.setAction(DualNetworkVpnService.ACTION_DISCONNECT);
            startService(service);
            disconnectWorkWifiLocalOnlyInternal(false);
            preferences.edit().putBoolean(PREF_WORK_WIFI_AUTO, false).apply();
            setStatus("Dual jaringan sistem dimatikan. ICE tetap memakai mode v2.8.9.");
            handler.postDelayed(new Runnable() {
                @Override public void run() { updateNetworkBadge(); }
            }, 500L);
        } catch (Throwable error) {
            setStatus("Gagal mematikan dual jaringan sistem: " + safeMessage(error));
        }
    }

    private void showDualNetworkInfo() {
        if (Build.VERSION.SDK_INT < 29) {
            new AlertDialog.Builder(this)
                    .setTitle("Dual jaringan sistem")
                    .setMessage("Mode non-root untuk browser lain membutuhkan Android 10 atau lebih baru.")
                    .setPositiveButton("Tutup", null)
                    .show();
            return;
        }
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            requestLocationPermissionIfNeeded();
            setStatus("Izinkan lokasi agar Android dapat memilih Wi-Fi kerja.");
            return;
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(8), dp(18), 0);

        TextView info = new TextView(this);
        info.setText("Mode sistem non-root membuat LP4M dan seluruh subnet lokal dapat dibuka dari ICE, Chrome, Edge, Firefox, dan browser lain. Internet publik tetap melalui data seluler.\n\nAndroid akan menampilkan ikon VPN karena routing dilakukan oleh VPN lokal di HP, bukan server luar.");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(45, 55, 72));
        layout.addView(info, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        EditText ssidInput = new EditText(this);
        ssidInput.setHint("Nama Wi-Fi / SSID perusahaan");
        String savedSsid = preferences.getString(PREF_WORK_WIFI_SSID, "");
        if (savedSsid.length() == 0) savedSsid = currentWifiSsid();
        ssidInput.setText(savedSsid);
        layout.addView(ssidInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        EditText passwordInput = new EditText(this);
        passwordInput.setHint("Password Wi-Fi (disimpan di ICE)");
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setText(preferences.getString(PREF_WORK_WIFI_PASSWORD, ""));
        layout.addView(passwordInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        TextView state = new TextView(this);
        state.setText("Wi-Fi khusus: " + (localOnlyWifiNetwork != null ? "AKTIF" : "BELUM AKTIF")
                + "\nDual sistem: " + (systemVpnRunning ? "AKTIF" : "MATI")
                + "\nStatus: " + systemVpnMessage);
        state.setTextSize(12);
        state.setTextColor(Color.rgb(71, 85, 105));
        state.setPadding(0, dp(8), 0, 0);
        layout.addView(state);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Dual jaringan sistem non-root")
                .setView(layout)
                .setPositiveButton("Aktifkan Sistem", null)
                .setNeutralButton("Matikan Sistem", null)
                .setNegativeButton("Pengaturan Wi-Fi", null)
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface ignored) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String ssid = ssidInput.getText().toString().trim();
                        String password = passwordInput.getText().toString();
                        if (ssid.length() == 0) {
                            ssidInput.setError("Isi nama Wi-Fi perusahaan");
                            return;
                        }
                        if (password.length() > 0 && password.length() < 8) {
                            passwordInput.setError("Password WPA minimal 8 karakter");
                            return;
                        }
                        preferences.edit()
                                .putString(PREF_WORK_WIFI_SSID, ssid)
                                .putString(PREF_WORK_WIFI_PASSWORD, password)
                                .putBoolean(PREF_WORK_WIFI_AUTO, true)
                                .apply();
                        pendingSystemVpnStart = true;
                        if (localOnlyWifiNetwork != null) beginSystemVpnPermission();
                        else connectWorkWifiLocalOnly(ssid, password, true);
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        stopSystemDualService();
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                        } catch (Throwable error) {
                            setStatus("Tidak dapat membuka Pengaturan Wi-Fi: " + safeMessage(error));
                        }
                        dialog.dismiss();
                    }
                });
            }
        });
        dialog.show();
    }

    private void connectWorkWifiLocalOnly(final String ssid, final String password, final boolean userInitiated) {
        if (Build.VERSION.SDK_INT < 29 || connectivityManager == null) return;
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            requestLocationPermissionIfNeeded();
            return;
        }
        disconnectWorkWifiLocalOnlyInternal(false);
        try {
            WifiNetworkSpecifier.Builder specifierBuilder = new WifiNetworkSpecifier.Builder()
                    .setSsid(ssid);
            if (password != null && password.length() > 0) {
                specifierBuilder.setWpa2Passphrase(password);
            }
            WifiNetworkSpecifier specifier = specifierBuilder.build();
            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(specifier)
                    .build();

            localOnlyWifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    localOnlyWifiRequestActive = true;
                    localOnlyWifiNetwork = network;
                    wifiNetwork = network;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            if (isDefaultNetworkCellular()) {
                                setStatus("Dual jaringan berhasil: ICE lewat Wi-Fi, aplikasi lain lewat data.");
                            } else {
                                setStatus("Wi-Fi khusus tersambung, tetapi Wi-Fi biasa masih dominan. Lupakan Wi-Fi perusahaan dari Pengaturan lalu coba lagi.");
                            }
                            if (browserStarted && currentTab != null && isCompanyUrl(currentTab.currentUrl)) {
                                reloadCurrentTabRouted();
                            }
                            if (pendingSystemVpnStart) beginSystemVpnPermission();
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(localOnlyWifiNetwork)) {
                        localOnlyWifiNetwork = null;
                        wifiNetwork = observedWifiNetwork;
                    }
                    localOnlyWifiRequestActive = false;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            setStatus("Wi-Fi kerja khusus terputus.");
                        }
                    });
                }

                @Override
                public void onUnavailable() {
                    localOnlyWifiRequestActive = false;
                    localOnlyWifiNetwork = null;
                    wifiNetwork = observedWifiNetwork;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            setStatus("Gagal menyambungkan Wi-Fi khusus. Pastikan SSID/password benar dan Wi-Fi perusahaan sudah dilupakan dari Pengaturan.");
                        }
                    });
                }
            };
            localOnlyWifiRequestActive = true;
            connectivityManager.requestNetwork(request, localOnlyWifiCallback);
            if (userInitiated) setStatus("Pilih/izinkan Wi-Fi perusahaan pada dialog Android…");
        } catch (Throwable error) {
            localOnlyWifiRequestActive = false;
            setStatus("Gagal meminta Wi-Fi kerja khusus: " + safeMessage(error));
        }
    }

    private void disconnectWorkWifiLocalOnly() {
        preferences.edit().putBoolean(PREF_WORK_WIFI_AUTO, false).apply();
        disconnectWorkWifiLocalOnlyInternal(true);
    }

    private void disconnectWorkWifiLocalOnlyInternal(boolean showStatus) {
        if (connectivityManager != null && localOnlyWifiCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(localOnlyWifiCallback);
            } catch (Throwable ignored) {}
        }
        localOnlyWifiCallback = null;
        localOnlyWifiRequestActive = false;
        localOnlyWifiNetwork = null;
        wifiNetwork = observedWifiNetwork;
        refreshNetworkRoute();
        if (showStatus) setStatus("Wi-Fi kerja khusus dimatikan.");
    }

    private void maybeAutoConnectWorkWifi() {
        if (Build.VERSION.SDK_INT < 29 || localOnlyWifiRequestActive || localOnlyWifiNetwork != null) return;
        if (!preferences.getBoolean(PREF_WORK_WIFI_AUTO, false)) return;
        if (!hasLocationPermission()) return;
        String ssid = preferences.getString(PREF_WORK_WIFI_SSID, "");
        if (ssid.length() == 0) return;
        String password = preferences.getString(PREF_WORK_WIFI_PASSWORD, "");
        setStatus("Menyambungkan otomatis ke Wi-Fi " + ssid + "…");
        connectWorkWifiLocalOnly(ssid, password, false);
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        return message == null || message.length() == 0 ? error.getClass().getSimpleName() : message;
    }

    private void startBrowserIfNeeded() {
        if (browserStarted) return;
        browserStarted = true;
        createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
        maybeAutoConnectWorkWifi();
    }

    private void createNewTab(String url, boolean switchNow) {
        final TabState tab = new TabState();
        tab.number = nextTabNumber++;
        tab.title = "Tab " + tab.number;
        tab.currentUrl = normalizeUrl(url);

        tab.webView = new WebView(this);
        tab.webView.setVisibility(View.GONE);
        configureWebView(tab);
        webContainer.addView(tab.webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        tab.button = null;
        tabs.add(tab);
        updateTabCount();

        // Tampilkan tab lebih dulu supaya sentuhan terasa langsung, baru mulai memuat halaman.
        if (switchNow) switchToTab(tab);
        loadUrlRouted(tab, tab.currentUrl);
    }


    private void switchToTab(TabState tab) {
        if (tab == null || tab.destroyed) return;

        for (TabState item : tabs) {
            boolean active = item == tab;
            item.webView.setVisibility(active ? View.VISIBLE : View.GONE);
            try {
                if (active) {
                    item.webView.onResume();
                    item.webView.resumeTimers();
                } else {
                    item.webView.onPause();
                    item.webView.pauseTimers();
                }
            } catch (Throwable ignored) {}
        }

        currentTab = tab;
        refreshNetworkRoute();
        updateCallbackBadge(tab.callbackCount);
        updateBrowserUi(tab);
        setStatus("Tab " + tab.number + ": " + shortUrl(tab.currentUrl));
    }


    private void closeCurrentTab() {
        if (currentTab == null) return;
        if (tabs.size() <= 1) {
            loadUrlRouted(currentTab, preferences.getString(PREF_URL, DEFAULT_URL));
            return;
        }
        closeTab(currentTab);
    }

    private void closeTab(TabState tab) {
        int index = tabs.indexOf(tab);
        if (index < 0) return;

        tabs.remove(tab);
        webContainer.removeView(tab.webView);
        tab.destroyed = true;
        try { tab.webView.stopLoading(); } catch (Throwable ignored) {}
        try { tab.webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
        try { tab.webView.removeJavascriptInterface("AndroidBridge"); } catch (Throwable ignored) {}
        try { tab.webView.destroy(); } catch (Throwable ignored) {}
        updateTabCount();

        if (tabs.size() == 0) {
            createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            return;
        }

        int nextIndex = Math.min(index, tabs.size() - 1);
        switchToTab(tabs.get(nextIndex));
    }


    private void configureWebView(final TabState tab) {
        WebSettings settings = tab.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(true);
        settings.setSupportZoom(true);
        try { settings.setDisplayZoomControls(false); } catch (Throwable ignored) {}
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        try { settings.setGeolocationEnabled(true); } catch (Throwable ignored) {}
        applyDesktopMode(settings);

        tab.webView.setBackgroundColor(Color.WHITE);
        tab.webView.addJavascriptInterface(new AndroidBridge(tab), "AndroidBridge");

        tab.webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null || url.length() == 0) return false;
                loadUrlRouted(tab, url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.currentUrl = url;
                if (tab == currentTab) refreshNetworkRoute();
                tab.loadToken++;
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(5, true);
                    setStatus("Membuka " + shortUrl(url) + "…");
                }
                scheduleBridgeInjection(tab, tab.loadToken);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                tab.currentUrl = url;
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(100, false);
                    setStatus("Halaman siap");
                }
                injectBridge(tab);
                scheduleBridgeInjection(tab, tab.loadToken);
            }

            @Override
            public void onLoadResource(WebView view, String url) {
                if (url != null && (url.contains("html5-qrcode") || url.contains("scanner") || url.contains("qrcode"))) {
                    scheduleBridgeInjection(tab, tab.loadToken);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (tab == currentTab) {
                    setPageProgress(100, false);
                    setStatus("Gagal membuka web: " + description);
                }
            }
        });

        tab.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasCameraPermission()) {
                            request.grant(request.getResources());
                        } else {
                            pendingPermissionRequest = request;
                            requestCameraPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin,
                                                           final GeolocationPermissions.Callback callback) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasLocationPermission()) {
                            callback.invoke(origin, true, false);
                            setStatus("Izin lokasi diberikan.");
                        } else {
                            pendingGeolocationOrigin = origin;
                            pendingGeolocationCallback = callback;
                            requestLocationPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (tab == currentTab) {
                    setPageProgress(newProgress, newProgress < 100);
                    if (newProgress < 100) setStatus("Memuat halaman " + newProgress + "%");
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && title.trim().length() > 0) {
                    updateTabTitle(tab, title.trim());
                    if (tab == currentTab) updateBrowserUi(tab);
                }
            }
        });
    }


    private void updateTabTitle(final TabState tab, final String value) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String shortValue = value == null ? "Tab " + tab.number : value;
                if (shortValue.length() > 32) shortValue = shortValue.substring(0, 32) + "…";
                tab.title = shortValue;
                if (tab.button != null) tab.button.setText(shortValue);
                updateTabCount();
            }
        });
    }


    private void scheduleBridgeInjection(final TabState tab, final int token) {
        int[] delays = new int[] { 120, 350, 800, 1600, 3200, 6000 };
        for (final int delay : delays) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (tab == null || tab.destroyed || tab.loadToken != token) return;
                    injectBridge(tab);
                }
            }, delay);
        }
    }

    private void injectBridge(TabState tab) {
        if (tab == null || tab.destroyed || tab.webView == null || bridgeScript.length() == 0) return;
        runJavascript(tab.webView, bridgeScript);
    }

    private void sendCode(boolean clearAfter) {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        String code = codeInput == null ? "" : codeInput.getText().toString().trim();
        if (code.length() == 0) {
            Toast.makeText(this, "Isi kode terlebih dahulu", Toast.LENGTH_SHORT).show();
            if (codeInput != null) codeInput.requestFocus();
            return;
        }
        sendCodeValue(code, clearAfter);
    }

    private void sendCodeValue(String code, boolean clearInput) {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null || currentTab.webView == null) {
            setStatus("Tab scanner belum tersedia.");
            return;
        }
        code = code == null ? "" : code.trim();
        if (code.length() == 0) return;

        injectBridge(currentTab);
        String js = "(function(){return window.__LPWScannerBridge?window.__LPWScannerBridge.send(" +
                quoteJs(code) + "):JSON.stringify({ok:false,reason:'bridge_missing'});})();";
        runJavascript(currentTab.webView, js);

        if (codeInput != null) {
            if (clearInput) codeInput.setText("");
            else codeInput.setText(code);
        }
    }


    private void showBatchQueueDialog() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchDialog != null && batchDialog.isShowing()) {
            updateBatchUi();
            return;
        }

        final Dialog dialog = new Dialog(this);
        batchDialog = dialog;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(16));
        body.setBackgroundColor(Color.rgb(15, 23, 42));
        scroll.addView(body, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Antrean QR massal");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        Button close = smallButton("Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        titleRow.addView(close);
        body.addView(titleRow);

        TextView help = new TextView(this);
        help.setText("Tempel atau scan banyak kode. Satu kode per baris. Kode dikirim bertahap agar WebView tidak freeze.");
        help.setTextColor(Color.rgb(203, 213, 225));
        help.setTextSize(12);
        help.setPadding(0, 0, 0, dp(9));
        body.addView(help);

        batchPasteInput = new EditText(this);
        batchPasteInput.setHint("HU001\nHU002\nHU003");
        batchPasteInput.setTextColor(Color.WHITE);
        batchPasteInput.setHintTextColor(Color.rgb(100, 116, 139));
        batchPasteInput.setTextSize(15);
        batchPasteInput.setGravity(Gravity.TOP | Gravity.LEFT);
        batchPasteInput.setSingleLine(false);
        batchPasteInput.setMinLines(7);
        batchPasteInput.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        batchPasteInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        batchPasteInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(10)));
        body.addView(batchPasteInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(170)));

        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        addRow.setPadding(0, dp(8), 0, 0);

        Button addButton = actionButton("Tambah ke antrean", Color.rgb(37, 99, 235));
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBatchCodes(batchPasteInput == null ? "" : batchPasteInput.getText().toString());
            }
        });
        addRow.addView(addButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button pasteButton = actionButton("Tempel", Color.rgb(71, 85, 105));
        pasteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null && clipboard.hasPrimaryClip()) {
                        ClipData clip = clipboard.getPrimaryClip();
                        if (clip != null && clip.getItemCount() > 0) {
                            CharSequence text = clip.getItemAt(0).coerceToText(MainActivity.this);
                            batchPasteInput.setText(text == null ? "" : text.toString());
                        }
                    }
                } catch (Throwable ignored) {}
            }
        });
        LinearLayout.LayoutParams pasteParams = new LinearLayout.LayoutParams(0, dp(46), 0.55f);
        pasteParams.setMargins(dp(7), 0, 0, 0);
        addRow.addView(pasteButton, pasteParams);
        body.addView(addRow);

        batchStatsText = new TextView(this);
        batchStatsText.setTextColor(Color.WHITE);
        batchStatsText.setTextSize(14);
        batchStatsText.setGravity(Gravity.CENTER);
        batchStatsText.setPadding(dp(8), dp(12), dp(8), dp(12));
        batchStatsText.setBackground(makeRounded(Color.rgb(30, 41, 59), dp(10)));
        LinearLayout.LayoutParams statsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        statsParams.setMargins(0, dp(10), 0, 0);
        body.addView(batchStatsText, statsParams);

        LinearLayout delayRow = new LinearLayout(this);
        delayRow.setOrientation(LinearLayout.HORIZONTAL);
        delayRow.setGravity(Gravity.CENTER_VERTICAL);
        delayRow.setPadding(0, dp(10), 0, 0);

        TextView delayLabel = new TextView(this);
        delayLabel.setText("Jeda tiap kode (ms)");
        delayLabel.setTextColor(Color.rgb(203, 213, 225));
        delayLabel.setTextSize(13);
        delayRow.addView(delayLabel, new LinearLayout.LayoutParams(0, dp(44), 1));

        batchDelayInput = new EditText(this);
        batchDelayInput.setSingleLine(true);
        batchDelayInput.setText(String.valueOf(batchDelayMs));
        batchDelayInput.setTextColor(Color.WHITE);
        batchDelayInput.setGravity(Gravity.CENTER);
        batchDelayInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        batchDelayInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(9)));
        delayRow.addView(batchDelayInput, new LinearLayout.LayoutParams(dp(105), dp(44)));
        body.addView(delayRow);

        LinearLayout controlRow = new LinearLayout(this);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);
        controlRow.setPadding(0, dp(8), 0, 0);

        batchStartButton = actionButton("Mulai", Color.rgb(22, 163, 74));
        batchStartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startOrPauseBatch();
            }
        });
        controlRow.addView(batchStartButton, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button resetButton = actionButton("Hapus semua", Color.rgb(220, 38, 38));
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Hapus seluruh antrean?")
                        .setMessage("Daftar, jumlah terkirim, gagal, dan duplikat akan direset.")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                resetBatchQueue();
                            }
                        })
                        .show();
            }
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(0, dp(48), 0.75f);
        resetParams.setMargins(dp(7), 0, 0, 0);
        controlRow.addView(resetButton, resetParams);
        body.addView(controlRow);

        TextView note = new TextView(this);
        note.setText("Saran: gunakan 800–1500 ms untuk 500 kode. Saat halaman reload, antrean otomatis menunggu sampai halaman siap.");
        note.setTextColor(Color.rgb(148, 163, 184));
        note.setTextSize(11);
        note.setPadding(0, dp(10), 0, 0);
        body.addView(note);

        dialog.setContentView(scroll);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                batchDialog = null;
                batchPasteInput = null;
                batchDelayInput = null;
                batchStatsText = null;
                batchStartButton = null;
            }
        });
        dialog.show();
        try {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                window.setBackgroundDrawable(makeRounded(Color.TRANSPARENT, dp(12)));
            }
        } catch (Throwable ignored) {}
        updateBatchUi();
    }

    private void addBatchCodes(String raw) {
        if (raw == null) raw = "";
        String[] lines = raw.split("\\r?\\n");
        int added = 0;
        int duplicates = 0;
        for (String line : lines) {
            String code = line == null ? "" : line.trim();
            if (code.length() == 0) continue;
            if (batchSeen.containsKey(code)) {
                duplicates++;
                continue;
            }
            batchSeen.put(code, true);
            batchQueue.add(code);
            added++;
        }
        batchDuplicates += duplicates;
        persistBatchState();
        if (batchPasteInput != null) batchPasteInput.setText("");
        updateBatchUi();
        Toast.makeText(this,
                "Ditambah " + added + " kode" + (duplicates > 0 ? ", duplikat " + duplicates : ""),
                Toast.LENGTH_SHORT).show();
    }

    private void sendNextBatchCodeManually() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchQueue.size() == 0) {
            Toast.makeText(this, "Antrean masih kosong", Toast.LENGTH_SHORT).show();
            updateBatchUi();
            return;
        }
        if (batchManualSingleMode || batchAwaitingResult) {
            Toast.makeText(this, "Satu QR masih sedang dikirim", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchRunning && !batchPaused) {
            Toast.makeText(this, "Jeda antrean otomatis terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        // Jika antrean otomatis sedang dijeda, setelah satu kiriman manual selesai
        // status jeda dipulihkan dan kode berikutnya tidak ikut terkirim otomatis.
        batchRestorePausedAfterManual = batchRunning && batchPaused;
        batchManualSingleMode = true;
        batchRunning = true;
        batchPaused = false;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Mengirim 1 QR dari antrean… sisa " + batchQueue.size() + ".");
        handler.removeCallbacks(batchRunnable);
        handler.postDelayed(batchRunnable, 60);
    }

    private void finishManualBatchAttempt(boolean success, String code, String reason) {
        boolean restorePaused = batchRestorePausedAfterManual && batchQueue.size() > 0;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRunning = restorePaused;
        batchPaused = restorePaused;
        batchAwaitingResult = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();

        if (success) {
            setStatus("1 QR terkirim manual. Sisa " + batchQueue.size() + ".");
            Toast.makeText(this, "1 QR terkirim", Toast.LENGTH_SHORT).show();
        } else {
            String detail = reason == null || reason.length() == 0 ? "gagal diproses" : reason;
            setStatus("Kirim manual gagal (" + detail + "). Kode tetap di antrean.");
            Toast.makeText(this, "Gagal dikirim, kode tetap di antrean", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelManualBatchSend(String message) {
        if (!batchManualSingleMode) return;
        batchSendToken++;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();
        if (message != null && message.length() > 0) setStatus(message);
    }

    private void startOrPauseBatch() {
        if (batchManualSingleMode) {
            Toast.makeText(this, "Tunggu kirim manual selesai", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
            setStatus("Antrean QR dijeda. Sisa " + batchQueue.size() + ".");
            return;
        }
        if (batchQueue.size() == 0) {
            Toast.makeText(this, "Antrean masih kosong", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchDelayInput != null) {
            try {
                batchDelayMs = Integer.parseInt(batchDelayInput.getText().toString().trim());
            } catch (Throwable ignored) {
                batchDelayMs = 800;
            }
        }
        batchDelayMs = Math.max(250, Math.min(10000, batchDelayMs));
        if (batchDelayInput != null) batchDelayInput.setText(String.valueOf(batchDelayMs));
        batchRunning = true;
        batchPaused = false;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR berjalan. Sisa " + batchQueue.size() + ".");
        handler.removeCallbacks(batchRunnable);
        handler.postDelayed(batchRunnable, 80);
    }

    private void processNextBatchCode() {
        if (!batchRunning || batchPaused || batchAwaitingResult) return;
        if (batchQueue.size() == 0) {
            finishBatchQueue();
            return;
        }
        if (currentTab == null || currentTab.destroyed || currentTab.webView == null) {
            setStatus("Menunggu tab web aktif…");
            handler.postDelayed(batchRunnable, 700);
            return;
        }
        if (pageLoading) {
            setStatus("Antrean menunggu halaman selesai dimuat…");
            handler.postDelayed(batchRunnable, 500);
            return;
        }

        final String code = batchQueue.get(0);
        final int token = ++batchSendToken;
        batchAwaitingResult = true;
        injectBridge(currentTab);

        final String requestId = "batch:" + token;
        final String js = "(function(){try{" +
                "if(!window.__LPWScannerBridge)return {ok:false,reason:'bridge_missing'};" +
                "var r=window.__LPWScannerBridge.send(" + quoteJs(code) + "," + quoteJs(requestId) + ");" +
                "return typeof r==='string'?JSON.parse(r):r;" +
                "}catch(e){return {ok:false,reason:'js_error'};}})();";

        try {
            currentTab.webView.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    handleBatchEnqueueResult(token, code, value);
                }
            });
        } catch (Throwable error) {
            batchAwaitingResult = false;
            handleBatchFailure(token, code, "evaluate_error");
            return;
        }

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (batchAwaitingResult && token == batchSendToken) {
                    batchAwaitingResult = false;
                    handleBatchFailure(token, code, "delivery_timeout");
                }
            }
        }, 5000);
    }

    private void handleBatchEnqueueResult(int token, String code, String value) {
        if (token != batchSendToken || !batchAwaitingResult) return;
        boolean accepted = false;
        String reason = "unknown";
        try {
            JSONObject result = new JSONObject(value == null ? "{}" : value);
            accepted = result.optBoolean("ok", false);
            reason = result.optString("reason", reason);
        } catch (Throwable ignored) {}
        if (!accepted) {
            batchAwaitingResult = false;
            handleBatchFailure(token, code, reason);
        }
        // Jika diterima bridge, tunggu laporan proses asli dari AndroidBridge.onSendReport().
    }

    private void handleBatchDeliveryReport(int token, String code, boolean ok, String reason) {
        if (token != batchSendToken || !batchAwaitingResult) return;
        batchAwaitingResult = false;
        if (!ok) {
            handleBatchFailure(token, code, reason == null ? "delivery_failed" : reason);
            return;
        }
        if (batchQueue.size() > 0 && code.equals(batchQueue.get(0))) batchQueue.remove(0);
        else batchQueue.remove(code);
        batchSent++;
        batchRetryCount = 0;

        if (batchManualSingleMode) {
            finishManualBatchAttempt(true, code, "");
            return;
        }

        persistBatchState();
        updateBatchUi();
        setStatus("QR terkirim " + batchSent + ". Sisa " + batchQueue.size() + ".");
        if (batchQueue.size() == 0) {
            finishBatchQueue();
        } else if (batchRunning && !batchPaused) {
            handler.postDelayed(batchRunnable, batchDelayMs);
        }
    }

    private void handleBatchFailure(int token, String code, String reason) {
        if (token != batchSendToken) return;
        if (batchManualSingleMode) {
            batchFailed++;
            finishManualBatchAttempt(false, code, reason);
            return;
        }
        if (batchPaused || !batchRunning) {
            batchAwaitingResult = false;
            batchRetryCount = 0;
            persistBatchState();
            updateBatchUi();
            setStatus("Antrean QR dijeda. Kode akan dicoba lagi saat dilanjutkan.");
            return;
        }
        batchRetryCount++;
        boolean retryable = "bridge_missing".equals(reason)
                || "queue_full".equals(reason)
                || "duplicate".equals(reason)
                || "timeout".equals(reason)
                || "delivery_timeout".equals(reason)
                || "delivery_failed".equals(reason)
                || "scanner_not_ready".equals(reason)
                || "evaluate_error".equals(reason)
                || "unknown".equals(reason);

        if (retryable && batchRetryCount <= 8 && batchRunning && !batchPaused) {
            if (currentTab != null) injectBridge(currentTab);
            setStatus("Menunggu scanner siap… percobaan " + batchRetryCount + "/8");
            long retryDelay = "queue_full".equals(reason) ? 450
                    : ("duplicate".equals(reason) ? 1250 : 800);
            handler.postDelayed(batchRunnable, retryDelay);
            return;
        }

        if (batchQueue.size() > 0 && code.equals(batchQueue.get(0))) batchQueue.remove(0);
        else batchQueue.remove(code);
        batchFailed++;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Satu kode gagal dilewati. Gagal " + batchFailed + ", sisa " + batchQueue.size() + ".");
        if (batchQueue.size() == 0) finishBatchQueue();
        else if (batchRunning && !batchPaused) handler.postDelayed(batchRunnable, batchDelayMs);
    }

    private void finishBatchQueue() {
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR selesai. Terkirim " + batchSent + ", gagal " + batchFailed + ".");
        Toast.makeText(this,
                "Antrean selesai: " + batchSent + " terkirim, " + batchFailed + " gagal",
                Toast.LENGTH_LONG).show();
    }

    private void resetBatchQueue() {
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRetryCount = 0;
        batchSendToken++;
        handler.removeCallbacks(batchRunnable);
        batchQueue.clear();
        batchSeen.clear();
        batchSent = 0;
        batchFailed = 0;
        batchDuplicates = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR sudah dihapus.");
    }

    private void loadBatchState() {
        batchQueue.clear();
        batchSeen.clear();
        batchSent = preferences.getInt(PREF_BATCH_SENT, 0);
        batchFailed = preferences.getInt(PREF_BATCH_FAILED, 0);
        batchDuplicates = preferences.getInt(PREF_BATCH_DUPLICATES, 0);
        batchDelayMs = Math.max(250, preferences.getInt(PREF_BATCH_DELAY, 800));
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BATCH_QUEUE, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String code = array.optString(i, "").trim();
                if (code.length() > 0) batchQueue.add(code);
            }
        } catch (Throwable ignored) {}
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BATCH_SEEN, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String code = array.optString(i, "").trim();
                if (code.length() > 0) batchSeen.put(code, true);
            }
        } catch (Throwable ignored) {}
        for (String code : batchQueue) batchSeen.put(code, true);
    }

    private void persistBatchState() {
        JSONArray queueJson = new JSONArray();
        for (String code : batchQueue) queueJson.put(code);
        JSONArray seenJson = new JSONArray();
        for (String code : batchSeen.keySet()) seenJson.put(code);
        preferences.edit()
                .putString(PREF_BATCH_QUEUE, queueJson.toString())
                .putString(PREF_BATCH_SEEN, seenJson.toString())
                .putInt(PREF_BATCH_SENT, batchSent)
                .putInt(PREF_BATCH_FAILED, batchFailed)
                .putInt(PREF_BATCH_DUPLICATES, batchDuplicates)
                .putInt(PREF_BATCH_DELAY, batchDelayMs)
                .apply();
    }

    private void updateBatchUi() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (batchManualSendButton != null) {
                    boolean autoBusy = batchRunning && !batchPaused && !batchManualSingleMode;
                    boolean canSendOne = batchQueue.size() > 0
                            && !batchManualSingleMode
                            && !batchAwaitingResult
                            && !autoBusy;
                    if (batchManualSingleMode || batchAwaitingResult) {
                        batchManualSendButton.setText("Mengirim 1 QR…");
                    } else if (batchQueue.size() > 0) {
                        batchManualSendButton.setText("Kirim 1 dari antrean • sisa " + batchQueue.size());
                    } else {
                        batchManualSendButton.setText("Kirim 1 • antrean kosong");
                    }
                    batchManualSendButton.setEnabled(canSendOne);
                    batchManualSendButton.setAlpha(canSendOne ? 1.0f : 0.55f);
                }
                if (batchQueueButton != null) {
                    batchQueueButton.setText(batchQueue.size() > 0
                            ? "Antrean QR • sisa " + batchQueue.size()
                            : "Antrean QR");
                }
                if (batchStatsText != null) {
                    batchStatsText.setText("Sisa: " + batchQueue.size()
                            + "   •   Terkirim: " + batchSent
                            + "\nGagal: " + batchFailed
                            + "   •   Duplikat: " + batchDuplicates);
                }
                if (batchStartButton != null) {
                    if (batchRunning && !batchPaused) batchStartButton.setText("Jeda");
                    else if (batchRunning && batchPaused) batchStartButton.setText("Lanjutkan");
                    else batchStartButton.setText("Mulai");
                }
            }
        });
    }

    private void checkScanner() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null) return;

        injectBridge(currentTab);
        runJavascript(currentTab.webView,
                "(function(){return window.__LPWScannerBridge?window.__LPWScannerBridge.status():JSON.stringify({bridge:false});})();");
        setStatus("Memeriksa scanner pada tab ini…");
    }

    private void runJavascript(WebView view, String script) {
        if (view == null) return;
        try {
            Method method = WebView.class.getMethod(
                    "evaluateJavascript",
                    String.class,
                    Class.forName("android.webkit.ValueCallback"));
            method.invoke(view, script, null);
        } catch (Throwable ignored) {
            view.loadUrl("javascript:" + script);
        }
    }

    private void hideTools() {
        toolsVisible = false;
        if (toolsPanel != null) toolsPanel.setVisibility(View.GONE);
        if (showToolsBar != null) showToolsBar.setVisibility(View.GONE);
        if (scanToggleButton != null) {
            scanToggleButton.setText("⌨");
            scanToggleButton.setTextColor(Color.WHITE);
        }
    }


    private void showTools() {
        toolsVisible = true;
        if (toolsPanel != null) toolsPanel.setVisibility(View.VISIBLE);
        if (showToolsBar != null) showToolsBar.setVisibility(View.GONE);
        if (scanToggleButton != null) {
            scanToggleButton.setText("⌨");
            scanToggleButton.setTextColor(Color.rgb(138, 180, 248));
        }
        if (codeInput != null) codeInput.requestFocus();
    }


    private void showUrlDialog() {
        showHomeUrlDialog();
    }



    private Button toolbarButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.rgb(232, 234, 237));
        button.setTextSize(18);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private Button bottomButton(String text, String description) {
        Button button = toolbarButton(text);
        button.setTextSize(24);
        button.setContentDescription(description);
        return button;
    }

    private GradientDrawable makeRoundedStroke(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = makeRounded(color, radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private void navigateAddressBar() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null || addressInput == null) return;

        String value = addressInput.getText().toString().trim();
        if (value.length() == 0) return;

        String url;
        if (value.indexOf(' ') >= 0 && value.indexOf('.') < 0) {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8");
            } catch (Throwable ignored) {
                url = normalizeUrl(value);
            }
        } else {
            url = normalizeUrl(value);
        }

        addressInput.clearFocus();
        loadUrlRouted(currentTab, url);
    }

    private void goHome() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        String home = preferences.getString(PREF_URL, DEFAULT_URL);
        if (currentTab == null) createNewTab(home, true);
        else loadUrlRouted(currentTab, home);
    }

    private void updateBrowserUi(final TabState tab) {
        if (tab == null) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String url = tab.currentUrl == null ? "" : tab.currentUrl;
                if (addressInput != null && !addressInput.hasFocus()) addressInput.setText(url);
                if (securityIcon != null) {
                    if (url.startsWith("https://")) {
                        securityIcon.setText("●");
                        securityIcon.setTextColor(Color.rgb(129, 201, 149));
                    } else {
                        securityIcon.setText("!");
                        securityIcon.setTextColor(Color.rgb(242, 139, 130));
                    }
                }
                if (bookmarkButton != null) {
                    bookmarkButton.setText(isBookmarked(url) ? "★" : "☆");
                    bookmarkButton.setTextColor(isBookmarked(url)
                            ? Color.rgb(251, 188, 4)
                            : Color.rgb(232, 234, 237));
                }
                updateTabCount();
            }
        });
    }

    private void setPageProgress(final int progress, final boolean loading) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pageLoading = loading;
                if (pageProgress != null) {
                    pageProgress.setProgress(Math.max(0, Math.min(100, progress)));
                    pageProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
                }
                if (reloadButton != null) reloadButton.setText(loading ? "×" : "↻");
            }
        });
    }

    private void updateTabCount() {
        if (tabsButton != null) tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
    }

    private List<BookmarkItem> loadBookmarks() {
        List<BookmarkItem> list = new ArrayList<BookmarkItem>();
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BOOKMARKS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "Bookmark").trim();
                String url = normalizeUrl(item.optString("url", ""));
                if (url.length() == 0) continue;
                if (name.length() == 0) name = shortUrl(url);
                // Hindari bookmark ganda akibat garis miring atau fragment URL.
                boolean duplicate = false;
                for (BookmarkItem saved : list) {
                    if (bookmarkKey(saved.url).equals(bookmarkKey(url))) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) list.add(new BookmarkItem(name, url));
            }
        } catch (Throwable ignored) {}
        return list;
    }

    private void saveBookmarks(List<BookmarkItem> list) {
        JSONArray array = new JSONArray();
        try {
            for (BookmarkItem item : list) {
                JSONObject object = new JSONObject();
                object.put("name", item.name == null ? "Bookmark" : item.name.trim());
                object.put("url", normalizeUrl(item.url));
                array.put(object);
            }
        } catch (Throwable ignored) {}
        preferences.edit().putString(PREF_BOOKMARKS, array.toString()).apply();
    }

    private String bookmarkKey(String url) {
        if (url == null) return "";
        String value = normalizeUrl(url).trim();
        int hash = value.indexOf('#');
        if (hash >= 0) value = value.substring(0, hash);
        while (value.endsWith("/") && value.length() > 9) {
            value = value.substring(0, value.length() - 1);
        }
        return value.toLowerCase(Locale.US);
    }

    private int bookmarkIndex(String url) {
        String key = bookmarkKey(url);
        List<BookmarkItem> list = loadBookmarks();
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) return i;
        }
        return -1;
    }

    private boolean isBookmarked(String url) {
        return bookmarkIndex(url) >= 0;
    }

    private void toggleCurrentBookmark() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        List<BookmarkItem> list = loadBookmarks();
        String key = bookmarkKey(currentTab.currentUrl);
        int index = -1;
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) {
                index = i;
                break;
            }
        }

        if (index >= 0) {
            list.remove(index);
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark dihapus", Toast.LENGTH_SHORT).show();
        } else {
            String name = currentTab.title == null || currentTab.title.trim().length() == 0
                    ? shortUrl(currentTab.currentUrl)
                    : currentTab.title.trim();
            list.add(new BookmarkItem(name, normalizeUrl(currentTab.currentUrl)));
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark disimpan", Toast.LENGTH_SHORT).show();
        }
        updateBrowserUi(currentTab);
    }

    private void showBookmarksDialog() {
        final List<BookmarkItem> bookmarks = loadBookmarks();
        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(12));

        final AlertDialog[] dialogRef = new AlertDialog[1];

        Button addCurrent = actionButton("＋ Simpan halaman aktif", Color.rgb(37, 99, 235));
        addCurrent.setEnabled(currentTab != null && currentTab.currentUrl != null);
        addCurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null) toggleCurrentBookmark();
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                handler.postDelayed(new Runnable() {
                    @Override public void run() { showBookmarksDialog(); }
                }, 80);
            }
        });
        content.addView(addCurrent, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        if (bookmarks.size() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada bookmark. Tekan tombol di atas untuk menyimpan halaman aktif.");
            empty.setTextColor(Color.rgb(71, 85, 105));
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(28), dp(12), dp(28));
            content.addView(empty);
        } else {
            for (int i = 0; i < bookmarks.size(); i++) {
                final int index = i;
                final BookmarkItem item = bookmarks.get(i);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                card.setBackground(makeRounded(Color.rgb(241, 245, 249), dp(12)));
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                cardParams.setMargins(0, dp(10), 0, 0);

                TextView name = new TextView(this);
                name.setText(item.name);
                name.setTextColor(Color.rgb(15, 23, 42));
                name.setTextSize(15);
                name.setSingleLine(true);
                name.setPadding(dp(2), 0, dp(2), 0);
                card.addView(name, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));

                TextView url = new TextView(this);
                url.setText(shortUrl(item.url));
                url.setTextColor(Color.rgb(100, 116, 139));
                url.setTextSize(12);
                url.setSingleLine(true);
                url.setPadding(dp(2), 0, dp(2), dp(6));
                card.addView(url, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(30)));

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);

                Button open = actionButton("Buka", Color.rgb(37, 99, 235));
                open.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        if (currentTab == null) createNewTab(item.url, true);
                        else loadUrlRouted(currentTab, item.url);
                    }
                });
                actions.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1));

                Button newTab = actionButton("Tab baru", Color.rgb(13, 148, 136));
                newTab.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        createNewTab(item.url, true);
                    }
                });
                LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, dp(46), 1);
                actionParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(newTab, actionParams);

                Button edit = actionButton("Edit", Color.rgb(71, 85, 105));
                edit.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        showBookmarkEditor(index);
                    }
                });
                LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, dp(46), .78f);
                editParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(edit, editParams);

                Button delete = actionButton("Hapus", Color.rgb(185, 28, 28));
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        List<BookmarkItem> latest = loadBookmarks();
                        if (index >= 0 && index < latest.size()) {
                            latest.remove(index);
                            saveBookmarks(latest);
                        }
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        updateBrowserUi(currentTab);
                        handler.postDelayed(new Runnable() {
                            @Override public void run() { showBookmarksDialog(); }
                        }, 80);
                    }
                });
                LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(0, dp(46), .9f);
                deleteParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(delete, deleteParams);

                card.addView(actions);
                content.addView(card, cardParams);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Bookmark (" + bookmarks.size() + ")")
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private void showBookmarkEditor(final int index) {
        final List<BookmarkItem> bookmarks = loadBookmarks();
        if (index < 0 || index >= bookmarks.size()) return;
        final BookmarkItem item = bookmarks.get(index);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(6), dp(20), 0);

        final EditText name = new EditText(this);
        name.setHint("Nama bookmark");
        name.setSingleLine(true);
        name.setText(item.name);
        layout.addView(name);

        final EditText url = new EditText(this);
        url.setHint("URL");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(item.url);
        layout.addView(url);

        new AlertDialog.Builder(this)
                .setTitle("Edit bookmark")
                .setView(layout)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newUrl = normalizeUrl(url.getText().toString());
                        String newName = name.getText().toString().trim();
                        if (newName.length() == 0) newName = shortUrl(newUrl);
                        item.name = newName;
                        item.url = newUrl;
                        bookmarks.set(index, item);
                        saveBookmarks(bookmarks);
                        updateBrowserUi(currentTab);
                        handler.postDelayed(new Runnable() {
                            @Override public void run() { showBookmarksDialog(); }
                        }, 80);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showTabsDialog() {
        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(12));
        final AlertDialog[] dialogRef = new AlertDialog[1];

        Button add = actionButton("＋ Tab baru", Color.rgb(37, 99, 235));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            }
        });
        content.addView(add, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));

        for (final TabState tab : new ArrayList<TabState>(tabs)) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(10), dp(8), dp(8), dp(8));
            card.setBackground(makeRounded(
                    tab == currentTab ? Color.rgb(219, 234, 254) : Color.rgb(241, 245, 249),
                    dp(12)));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(78));
            cardParams.setMargins(0, dp(9), 0, 0);

            LinearLayout textArea = new LinearLayout(this);
            textArea.setOrientation(LinearLayout.VERTICAL);
            textArea.setGravity(Gravity.CENTER_VERTICAL);
            textArea.setPadding(dp(4), 0, dp(8), 0);

            TextView title = new TextView(this);
            title.setText((tab == currentTab ? "● " : "") + tab.title);
            title.setTextColor(Color.rgb(15, 23, 42));
            title.setTextSize(15);
            title.setSingleLine(true);
            textArea.addView(title, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(30)));

            TextView url = new TextView(this);
            url.setText(shortUrl(tab.currentUrl));
            url.setTextColor(Color.rgb(100, 116, 139));
            url.setTextSize(12);
            url.setSingleLine(true);
            textArea.addView(url, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));

            textArea.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    switchToTab(tab);
                }
            });
            card.addView(textArea, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));

            Button close = actionButton("×", Color.rgb(185, 28, 28));
            close.setTextSize(22);
            close.setEnabled(tabs.size() > 1);
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (tabs.size() <= 1) return;
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    closeTab(tab);
                }
            });
            LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(58), dp(58));
            closeParams.setMargins(dp(6), 0, 0, 0);
            card.addView(close, closeParams);
            content.addView(card, cardParams);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Tab terbuka: " + tabs.size())
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private void showBrowserMenu() {
        final String bookmarkAction = currentTab != null && isBookmarked(currentTab.currentUrl)
                ? "Hapus bookmark halaman"
                : "Bookmark halaman";
        final String desktopAction = isDesktopModeEnabled()
                ? "Mode desktop: ON"
                : "Mode desktop: OFF";

        final String[] items = new String[] {
                "Tab baru",
                "Daftar tab",
                "Bookmark",
                bookmarkAction,
                "Beranda",
                "Muat ulang",
                "Salin URL",
                "Bagikan halaman",
                desktopAction,
                "Atur URL beranda",
                ADMIN_BUILD ? "Panel KEY admin" : "Info lisensi"
        };

        new AlertDialog.Builder(this)
                .setTitle("Menu ICE Inject")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
                                break;
                            case 1:
                                showTabsDialog();
                                break;
                            case 2:
                                showBookmarksDialog();
                                break;
                            case 3:
                                toggleCurrentBookmark();
                                break;
                            case 4:
                                goHome();
                                break;
                            case 5:
                                if (currentTab != null) reloadCurrentTabRouted();
                                break;
                            case 6:
                                copyCurrentUrl();
                                break;
                            case 7:
                                shareCurrentPage();
                                break;
                            case 8:
                                toggleDesktopMode();
                                break;
                            case 9:
                                showHomeUrlDialog();
                                break;
                            case 10:
                                if (ADMIN_BUILD) openAdminPanel(); else showLicenseInfoDialog();
                                break;
                        }
                    }
                })
                .show();
    }

    private boolean isDesktopModeEnabled() {
        return preferences.getBoolean(PREF_DESKTOP_MODE, false);
    }

    private void applyDesktopMode(WebSettings settings) {
        if (settings == null) return;
        boolean desktop = isDesktopModeEnabled();
        String mobileUa = null;
        try {
            mobileUa = new WebView(this).getSettings().getUserAgentString();
        } catch (Throwable ignored) {}
        if (mobileUa == null || mobileUa.length() == 0) {
            mobileUa = "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36";
        }
        String desktopUa = mobileUa.replace(" Mobile ", " ").replace(" Android ", " X11; Linux x86_64 ");
        if (desktopUa.indexOf("Windows NT 10.0; Win64; x64") < 0) {
            desktopUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";
        }
        settings.setUserAgentString(desktop ? desktopUa : mobileUa);
        settings.setUseWideViewPort(desktop);
        settings.setLoadWithOverviewMode(desktop);
    }

    private void toggleDesktopMode() {
        boolean next = !isDesktopModeEnabled();
        preferences.edit().putBoolean(PREF_DESKTOP_MODE, next).apply();
        for (TabState item : tabs) {
            if (item == null || item.destroyed || item.webView == null) continue;
            applyDesktopMode(item.webView.getSettings());
        }
        if (currentTab != null) reloadCurrentTabRouted();
        Toast.makeText(this,
                next ? "Mode desktop diaktifkan" : "Mode desktop dimatikan",
                Toast.LENGTH_SHORT).show();
    }

    private void showHomeUrlDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(preferences.getString(PREF_URL, DEFAULT_URL));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this)
                .setTitle("URL beranda")
                .setMessage("URL ini dibuka saat aplikasi atau tab baru dibuat.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String url = normalizeUrl(input.getText().toString());
                        preferences.edit().putString(PREF_URL, url).apply();
                        Toast.makeText(MainActivity.this, "URL beranda disimpan", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton("Pakai halaman ini", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (currentTab != null) {
                            preferences.edit().putString(PREF_URL, currentTab.currentUrl).apply();
                            Toast.makeText(MainActivity.this, "Halaman aktif dijadikan beranda", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void copyCurrentUrl() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentTab.currentUrl));
            Toast.makeText(this, "URL disalin", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    private void shareCurrentPage() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, currentTab.currentUrl);
            startActivity(Intent.createChooser(intent, "Bagikan halaman"));
        } catch (Throwable ignored) {
            copyCurrentUrl();
        }
    }

    private void showPageInfo() {
        String url = currentTab == null ? "" : currentTab.currentUrl;
        String message = url.startsWith("https://")
                ? "Sambungan HTTPS.\n\n" + url
                : "Sambungan tidak menggunakan HTTPS.\n\n" + url;
        new AlertDialog.Builder(this)
                .setTitle("Info halaman")
                .setMessage(message)
                .setPositiveButton("Salin URL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        copyCurrentUrl();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showLicenseServerDialog(final boolean openAdminAfter) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://domain.com/ice-license");
        input.setText(preferences.getString(PREF_LICENSE_SERVER, ""));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this)
                .setTitle("Server lisensi ICE")
                .setMessage("Masukkan folder tempat paket server lisensi di-upload.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String server = normalizeServerUrl(input.getText().toString());
                        preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
                        if (openAdminAfter) openAdminPanel();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void openAdminPanel() {
        String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, ""));
        if (server.length() == 0) {
            showLicenseServerDialog(true);
            return;
        }
        createNewTab(server + "/admin.php", true);
    }

    private void showActivationDialog(final boolean required) {
        if (ADMIN_BUILD) return;

        final LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText serverInput = new EditText(this);
        serverInput.setHint("https://domain.com/ice-login");
        serverInput.setSingleLine(true);
        serverInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverInput.setText(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        layout.addView(serverInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        final EditText userInput = new EditText(this);
        userInput.setHint("Username");
        userInput.setSingleLine(true);
        userInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        userInput.setText(preferences.getString(PREF_LICENSE_KEY, ""));
        userInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        LinearLayout.LayoutParams userParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        userParams.setMargins(0, dp(10), 0, 0);
        layout.addView(userInput, userParams);

        final EditText passInput = new EditText(this);
        passInput.setHint("Password");
        passInput.setSingleLine(true);
        passInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        passParams.setMargins(0, dp(10), 0, 0);
        layout.addView(passInput, passParams);

        final TextView message = new TextView(this);
        message.setText("Login wajib pakai internet/data. Setelah berhasil masuk, aplikasi bisa dipakai di WiFi perusahaan tanpa internet selama APK masih terbuka. Jika APK ditutup, harus login ulang.");
        message.setTextColor(Color.rgb(71, 85, 105));
        message.setTextSize(12);
        message.setPadding(0, dp(12), 0, 0);
        layout.addView(message);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Login ICE Inject")
                .setView(layout)
                .setCancelable(!required)
                .setPositiveButton("Login", null)
                .setNegativeButton(required ? "Keluar" : "Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        if (required) finish();
                    }
                })
                .create();

        dialog.setCanceledOnTouchOutside(!required);
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                final Button login = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String server = normalizeServerUrl(serverInput.getText().toString());
                        final String username = normalizeUsernameLocal(userInput.getText().toString());
                        final String password = passInput.getText().toString();
                        if (server.length() == 0) {
                            message.setText("URL server harus diisi dengan benar.");
                            message.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        if (username.length() < 3 || password.length() == 0) {
                            message.setText("Username/password belum diisi.");
                            message.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }

                        preferences.edit().putString(PREF_LICENSE_SERVER, server).putString(PREF_LICENSE_KEY, username).apply();
                        login.setEnabled(false);
                        message.setText("Login ke server…");
                        message.setTextColor(Color.rgb(71, 85, 105));

                        loginAccount(server, username, password, new ApiCallback() {
                            @Override
                            public void onResult(boolean success, JSONObject data, String error) {
                                if (success) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            licenseUnlocked = true;
                                            updateLicenseBadgeFromCache();
                                            try { dialog.dismiss(); } catch (Throwable ignored) {}
                                            startBrowserIfNeeded();
                                            Toast.makeText(MainActivity.this, "Login berhasil", Toast.LENGTH_LONG).show();
                                        }
                                    });
                                    return;
                                }
                                final String msg = error == null || error.length() == 0 ? "Login gagal. Cek username/password/server." : error;
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        login.setEnabled(true);
                                        message.setText(msg);
                                        message.setTextColor(Color.rgb(185, 28, 28));
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

        dialog.show();
    }

    private void openBrowserActivation(final String server, final boolean required) {
        final Dialog browserDialog = new Dialog(this);
        browserDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        browserDialog.setCancelable(!required);
        browserDialog.setCanceledOnTouchOutside(false);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.rgb(245, 247, 250));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(Color.rgb(15, 45, 64));

        TextView title = new TextView(this);
        title.setText("Aktivasi Browser");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        final TextView status = new TextView(this);
        status.setText("Memuat halaman aktivasi…");
        status.setTextColor(Color.rgb(71, 85, 105));
        status.setTextSize(12);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button close = smallButton(required ? "Keluar" : "Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                status.setText("Mengecek hasil aktivasi…");
                verifyActivationFromBrowser(server, browserDialog, status, required);
            }
        });
        bar.addView(close);
        container.addView(bar);
        container.addView(status);

        final WebView activationWeb = new WebView(this);
        WebSettings settings = activationWeb.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method method = android.webkit.CookieManager.class.getMethod(
                        "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                method.invoke(cookieManager, activationWeb, true);
            } catch (Exception ignored) {
            }
        }

        ActivationBridge activationBridge = new ActivationBridge(server, browserDialog, status);
        try {
            activationWeb.addJavascriptInterface(activationBridge, "Android");
            activationWeb.addJavascriptInterface(activationBridge, "IceApp");
        } catch (Throwable ignored) {}

        activationWeb.setWebChromeClient(new WebChromeClient());
        activationWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (handleActivationCallback(url, server, browserDialog, status)) {
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Membuka halaman aktivasi…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Masukkan key pada halaman di bawah.");
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            verifyActivationFromBrowser(server, browserDialog, status, false);
                        }
                    }, 900L);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                status.setText("Gagal memuat halaman: " + description + ". Pastikan internet aktif dan URL server benar.");
                status.setTextColor(Color.rgb(185, 28, 28));
            }
        });

        container.addView(activationWeb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        browserDialog.setContentView(container);
        browserDialog.show();
        Window window = browserDialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        try {
            String url = server + "/activate.php"
                    + "?device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                    + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                    + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
            activationWeb.loadUrl(url);
        } catch (Exception error) {
            status.setText("Tidak dapat membuat URL aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
        }
    }

    private boolean handleActivationCallback(String url, String server, Dialog dialog, TextView status) {
        if (url == null || !url.startsWith("iceinject://activated")) return false;

        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String message = uri.getQueryParameter("message");

            if (!"1".equals(ok)) {
                status.setText(message == null ? "Aktivasi gagal." : message);
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            String key = normalizeKey(uri.getQueryParameter("key"));
            String token = uri.getQueryParameter("token");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if (key.length() < 8 || expiryMillis <= 0) {
                status.setText("Data aktivasi dari server tidak lengkap.");
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

            preferences.edit()
                    .putString(PREF_LICENSE_SERVER, server)
                    .putString(PREF_LICENSE_KEY, key)
                    .putString(PREF_LICENSE_TOKEN, token == null ? "" : token)
                    .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                    .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                    .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                    .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                    .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                    .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                    .apply();

            dialog.dismiss();
            licenseUnlocked = true;
            updateLicenseBadgeFromCache();
            startBrowserIfNeeded();
            Toast.makeText(MainActivity.this,
                    message == null ? "Aktivasi berhasil" : message,
                    Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception error) {
            status.setText("Gagal membaca hasil aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
            return true;
        }
    }

    private long parseLongSafe(String value) {
        try {
            return Long.parseLong(value == null ? "0" : value);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private long parseServerMillis(String value) {
        if (value == null) return 0L;
        String v = value.trim();
        if (v.length() == 0) return 0L;
        try {
            if (v.matches("^[0-9]+$")) {
                long n = Long.parseLong(v);
                return n < 100000000000L ? n * 1000L : n;
            }
        } catch (Exception ignored) {}
        try {
            v = v.replace('T', ' ');
            if (v.endsWith("Z")) v = v.substring(0, v.length() - 1);
            int plus = v.indexOf('+', 10);
            if (plus > 0) v = v.substring(0, plus).trim();
            int dot = v.indexOf('.');
            if (dot > 0) v = v.substring(0, dot);
            if (v.length() >= 19) v = v.substring(0, 19);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
            Date parsed = format.parse(v);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void showLicenseInfoDialog() {
        if (ADMIN_BUILD) return;

        String key = preferences.getString(PREF_LICENSE_KEY, "-");
        long created = preferences.getLong(PREF_LICENSE_CREATED, 0L);
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        String duration = preferences.getString(PREF_LICENSE_DURATION_LABEL, "");
        String server = preferences.getString(PREF_LICENSE_SERVER, "-");
        long remaining = Math.max(0L, expiry - trustedNowMillis());

        StringBuilder message = new StringBuilder();
        message.append("Key: ").append(maskKey(key));
        if (duration != null && duration.length() > 0) {
            message.append("\nDurasi key: ").append(duration);
        }
        if (created > 0) message.append("\nDibuat: ").append(formatDate(created));
        message.append("\nBerakhir: ").append(expiry > 0 ? formatDate(expiry) : "belum aktif");
        if (expiry > 0) message.append("\nSisa waktu: ").append(longRemaining(remaining));
        message.append("\nServer: ").append(server);
        message.append("\n\nSemua waktu ditampilkan dalam WIB dan mengikuti waktu server lisensi.");

        new AlertDialog.Builder(this)
                .setTitle("Lisensi ICE Inject")
                .setMessage(message.toString())
                .setPositiveButton("Ganti / Aktivasi", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showActivationDialog(false);
                    }
                })
                .setNeutralButton("Cek Sekarang", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        validateLicenseAsync(true);
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void loginAccount(final String server, final String username, final String password, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView loginWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = loginWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, loginWeb, true);
                        } catch (Exception ignored) {}
                    }

                    loginWeb.setAlpha(0.01f);
                    loginWeb.setWebChromeClient(new WebChromeClient());
                    loginWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLoginResultFromWebView(view, server, username, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(loginWeb, params);
                    } else {
                        root.addView(loginWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/login-app.php"
                            + "?username=" + URLEncoder.encode(username, "UTF-8")
                            + "&password=" + URLEncoder.encode(password, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    loginWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(loginWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal login" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Timeout login. Cek koneksi internet/server.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLoginResultFromWebView(final WebView view, final String server, final String username,
                                            final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLoginWebText(view, server, username, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil login.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLoginWebText(WebView view, String server, String username,
                                    ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. " + small);
                return;
            }
            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Login ditolak."));
                return;
            }
            if (data.optString("username", "").length() == 0) {
                try { data.put("username", username); } catch (Throwable ignored) {}
            }
            boolean saved = saveLoginSessionFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired/token kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private void activateLicense(final String server, final String key, final ApiCallback callback) {
        // v2.7.6: free hosting sering membalas HttpURLConnection dengan HTML/JS,
        // sehingga JSONObject gagal. Aktivasi sekarang memakai WebView mini supaya
        // cookie/JS hosting tetap jalan, lalu body JSON dibaca dari halaman.
        activateLicenseViaWebView(server, key, callback);
    }

    private void activateLicenseViaWebView(final String server, final String key, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView activationWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = activationWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, activationWeb, true);
                        } catch (Exception ignored) {}
                    }

                    activationWeb.setAlpha(0.01f);
                    activationWeb.setWebChromeClient(new WebChromeClient());
                    activationWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readActivationResultFromWebView(view, server, key, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(activationWeb, params);
                    } else {
                        root.addView(activationWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/activate.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    activationWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(activationWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal aktivasi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Timeout aktivasi. Coba tombol Buka Web.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readActivationResultFromWebView(final WebView view, final String server, final String key,
                                                 final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleActivationWebText(view, server, key, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                // Semua perangkat target Android 15, tapi ini fallback aman.
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil aktivasi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleActivationWebText(WebView view, String server, String key,
                                         ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. Pakai tombol Buka Web. " + small);
                return;
            }

            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Key tidak valid."));
                return;
            }

            if (data.optString("key", "").length() == 0) {
                try { data.put("key", key); } catch (Throwable ignored) {}
            }
            boolean saved = saveLicenseFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private JSONObject jsonFromText(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (t.startsWith("\uFEFF")) t = t.substring(1).trim();
        int first = t.indexOf('{');
        int last = t.lastIndexOf('}');
        if (first < 0 || last <= first) return null;
        try {
            return new JSONObject(t.substring(first, last + 1));
        } catch (Throwable ignored) {
            return null;
        }
    }

    private String decodeJsString(String value) {
        if (value == null) return "";
        try {
            JSONArray arr = new JSONArray("[" + value + "]");
            return arr.optString(0, value);
        } catch (Throwable ignored) {
            return value;
        }
    }

    private class ActivationBridge {
        private final String server;
        private final Dialog dialog;
        private final TextView status;

        ActivationBridge(String server, Dialog dialog, TextView status) {
            this.server = server;
            this.dialog = dialog;
            this.status = status;
        }

        @JavascriptInterface
        public String getDeviceId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getAndroidId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getDeviceName() {
            return Build.MANUFACTURER + " " + Build.MODEL;
        }

        @JavascriptInterface
        public void onLicenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void licenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void activationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void onActivationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void saveLicense(String key, String token, String expiresAt, String deviceId) {
            try {
                JSONObject data = new JSONObject();
                data.put("ok", 1);
                data.put("status", "active");
                data.put("key", key == null ? "" : key);
                data.put("token", token == null ? "" : token);
                data.put("expires_at", expiresAt == null ? "" : expiresAt);
                data.put("device_id", deviceId == null ? getInstallDeviceId() : deviceId);
                data.put("server_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
                handleBridgePayload(data.toString());
            } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void setLicense(String key, String token, String expiresAt, String deviceId) {
            saveLicense(key, token, expiresAt, deviceId);
        }

        @JavascriptInterface
        public void setActivated(boolean active) {
            if (active) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        status.setText("Aktivasi diterima. Tekan Tutup/Keluar jika belum terbuka otomatis.");
                        status.setTextColor(Color.rgb(22, 101, 52));
                    }
                });
            }
        }

        private void handleBridgePayload(final String payload) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject data = jsonFromText(payload);
                        if (data == null || !jsonSaysActive(data)) {
                            status.setText("Data aktivasi tidak lengkap.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        boolean saved = saveLicenseFromJson(server, data);
                        if (!saved) {
                            status.setText("Aktivasi berhasil tapi expired tidak terbaca.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        licenseUnlocked = true;
                        updateLicenseBadgeFromCache();
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        startBrowserIfNeeded();
                        Toast.makeText(MainActivity.this, "Aktivasi berhasil", Toast.LENGTH_LONG).show();
                    } catch (Throwable error) {
                        status.setText("Gagal menyimpan aktivasi: " + error.getMessage());
                        status.setTextColor(Color.rgb(185, 28, 28));
                    }
                }
            });
        }
    }

    private void startLicenseWatchdog() {
        if (ADMIN_BUILD) return;
        handler.removeCallbacks(licenseWatchdog);
        handler.postDelayed(licenseWatchdog, LICENSE_CHECK_INTERVAL_MS);
    }

    private void validateLicenseAsync(final boolean showToast) {
        if (ADMIN_BUILD) return;

        final String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        if (server.length() == 0) {
            lockLicense("URL server lisensi belum diisi.");
            return;
        }
        if (!server.equals(preferences.getString(PREF_LICENSE_SERVER, ""))) {
            preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
        }

        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        if (licenseUnlocked && !showToast && System.currentTimeMillis() - lastCheck < LICENSE_CHECK_INTERVAL_MS) return;
        if (licenseCheckInProgress) return;

        checkLicenseDirect(server, showToast, true, null);
    }

    private void verifyActivationFromBrowser(final String server, final Dialog dialog,
                                             final TextView status, final boolean closeIfFail) {
        checkLicenseDirect(server, false, false, new ApiCallback() {
            @Override
            public void onResult(boolean success, JSONObject data, String error) {
                if (success) {
                    status.setText("Aktivasi berhasil. Aplikasi dibuka…");
                    status.setTextColor(Color.rgb(22, 101, 52));
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    startBrowserIfNeeded();
                    return;
                }
                if (closeIfFail) {
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    finish();
                } else if (error != null && error.length() > 0) {
                    status.setText("Masukkan key pada halaman di bawah. " + error);
                    status.setTextColor(Color.rgb(71, 85, 105));
                }
            }
        });
    }

    private void checkLicenseDirect(final String server, final boolean showToast,
                                    final boolean lockOnFail, final ApiCallback callback) {
        if (licenseCheckInProgress) return;
        licenseCheckInProgress = true;
        refreshNetworkRoute();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = checkWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, checkWeb, true);
                        } catch (Exception ignored) {}
                    }

                    checkWeb.setAlpha(0.01f);
                    checkWeb.setWebChromeClient(new WebChromeClient());
                    checkWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLicenseCheckFromWebView(view, server, showToast, lockOnFail, callback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, description == null ? "Server tidak tersambung" : description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(checkWeb, params);
                    } else {
                        root.addView(checkWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) {
                        finished[0] = true;
                        finishLicenseCheckRoute();
                        removeCheckWebView(checkWeb);
                        if (lockOnFail) lockLicense("Sesi login hilang. Login ulang pakai internet.");
                        if (callback != null) callback.onResult(false, null, "Sesi login hilang");
                        return;
                    }
                    StringBuilder url = new StringBuilder(server).append("/check-session.php")
                            .append("?username=").append(URLEncoder.encode(runtimeUsername, "UTF-8"))
                            .append("&session_token=").append(URLEncoder.encode(runtimeSessionToken, "UTF-8"))
                            .append("&device_id=").append(URLEncoder.encode(getInstallDeviceId(), "UTF-8"))
                            .append("&device_name=").append(URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8"))
                            .append("&app_version=").append(URLEncoder.encode(APP_VERSION, "UTF-8"))
                            .append("&api=1&format=json&_t=").append(System.currentTimeMillis());
                    checkWeb.loadUrl(url.toString());
                } catch (Throwable error) {
                    finished[0] = true;
                    finishLicenseCheckRoute();
                    try { removeCheckWebView(checkWeb); } catch (Throwable ignored) {}
                    if (lockOnFail) handleLicenseServerUnavailable(showToast);
                    if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal cek lisensi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, "Timeout cek lisensi");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLicenseCheckFromWebView(final WebView view, final String server, final boolean showToast,
                                             final boolean lockOnFail, final ApiCallback callback,
                                             final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLicenseCheckText(view, server, showToast, lockOnFail, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                finishLicenseCheckRoute();
                removeCheckWebView(view);
                if (lockOnFail) handleLicenseServerUnavailable(showToast);
                if (callback != null) callback.onResult(false, null, "Android terlalu lama untuk cek lisensi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            finishLicenseCheckRoute();
            removeCheckWebView(view);
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
            if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLicenseCheckText(WebView view, String server, boolean showToast,
                                        boolean lockOnFail, ApiCallback callback,
                                        boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        finishLicenseCheckRoute();
        removeCheckWebView(view);

        JSONObject data = jsonFromText(text);
        if (data != null && jsonSaysActive(data)) {
            boolean saved = saveLoginSessionFromJson(server, data);
            if (saved) {
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                startBrowserIfNeeded();
                if (showToast) Toast.makeText(MainActivity.this,
                        data.optString("message", "Lisensi aktif"),
                        Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onResult(true, data, null);
                return;
            }
        }

        String message = data != null ? data.optString("message", "Lisensi belum aktif.") : "Server tidak memberi JSON valid.";
        if (message == null || message.length() == 0) message = "Lisensi belum aktif.";

        if (data == null) {
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
        } else if (lockOnFail) {
            lockLicense(message);
        }
        if (callback != null) callback.onResult(false, data, message);
    }

    private boolean jsonSaysActive(JSONObject data) {
        if (data == null) return false;
        if (data.optBoolean("ok", false) || data.optInt("ok", 0) == 1) return true;
        if (data.optBoolean("success", false) || data.optInt("success", 0) == 1) return true;
        if (data.optBoolean("valid", false) || data.optInt("valid", 0) == 1) return true;
        if (data.optBoolean("active", false) || data.optInt("active", 0) == 1) return true;
        if (data.optBoolean("is_valid", false) || data.optInt("is_valid", 0) == 1) return true;
        if (data.optBoolean("license_valid", false) || data.optInt("license_valid", 0) == 1) return true;
        return "active".equalsIgnoreCase(data.optString("status", ""));
    }

    private boolean saveLoginSessionFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        String username = normalizeUsernameLocal(data.optString("username", runtimeUsername.length() > 0 ? runtimeUsername : preferences.getString(PREF_LICENSE_KEY, "")));
        String token = data.optString("session_token", data.optString("token", runtimeSessionToken));
        if (username.length() < 3 || token.length() == 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

        runtimeUsername = username;
        runtimeSessionToken = token;
        runtimeSessionExpiry = expiryMillis;
        preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putString(PREF_LICENSE_KEY, username)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, "Login user")
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                .remove(PREF_LICENSE_TOKEN)
                .apply();
        return true;
    }

    private boolean saveLicenseFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
        long createdMillis = extractCreatedMillis(data);
        String oldKey = preferences.getString(PREF_LICENSE_KEY, "");
        String oldToken = preferences.getString(PREF_LICENSE_TOKEN, "");
        String key = normalizeKey(data.optString("key", oldKey));
        String token = data.optString("token", oldToken);
        String durationLabel = data.optString("duration_label", preferences.getString(PREF_LICENSE_DURATION_LABEL, ""));

        SharedPreferences.Editor editor = preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis());
        if (key.length() > 0) editor.putString(PREF_LICENSE_KEY, key);
        if (token != null) editor.putString(PREF_LICENSE_TOKEN, token);
        editor.apply();
        return true;
    }

    private long extractExpiryMillis(JSONObject data) {
        if (data == null) return 0L;
        String[] keys = new String[]{"expires_at", "expires", "expiry", "expire_at", "expire_date", "expired_at"};
        for (String k : keys) {
            long v = parseServerMillis(data.optString(k, ""));
            if (v > 0) return v;
        }
        return 0L;
    }

    private long extractServerMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("server_time", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("server_timestamp", ""));
    }

    private long extractCreatedMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("created_at", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("activated_at", ""));
    }

    private void checkLicenseThroughBrowser(final String server, final String key,
                                            final String token, final boolean showToast) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                WebSettings settings = checkWeb.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setDatabaseEnabled(true);

                android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                cookieManager.setAcceptCookie(true);
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        Method method = android.webkit.CookieManager.class.getMethod(
                                "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                        method.invoke(cookieManager, checkWeb, true);
                    } catch (Exception ignored) {
                    }
                }

                checkWeb.setAlpha(0.01f);
                checkWeb.setWebChromeClient(new WebChromeClient());
                checkWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        if (url != null && url.startsWith("iceinject://checked")) {
                            if (!finished[0]) {
                                finished[0] = true;
                                handleBrowserLicenseCheck(url, checkWeb, showToast);
                            }
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                });

                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                webContainer.addView(checkWeb, params);

                try {
                    String url = server + "/check-app.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&token=" + URLEncoder.encode(token, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
                    checkWeb.loadUrl(url);
                } catch (Exception error) {
                    finished[0] = true;
                    removeCheckWebView(checkWeb);
                    handleLicenseServerUnavailable(showToast);
                    return;
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                }, 20000L);
            }
        });
    }

    private void handleBrowserLicenseCheck(String url, WebView checkWeb, boolean showToast) {
        removeCheckWebView(checkWeb);
        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String code = uri.getQueryParameter("code");
            String message = uri.getQueryParameter("message");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if ("1".equals(ok) && expiryMillis > 0) {
                if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
                preferences.edit()
                        .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                        .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : preferences.getLong(PREF_LICENSE_CREATED, 0L))
                        .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? preferences.getString(PREF_LICENSE_DURATION_LABEL, "") : durationLabel)
                        .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                        .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                        .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                        .apply();
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                if (showToast) Toast.makeText(MainActivity.this,
                        message == null ? "Lisensi masih aktif" : message,
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if ("revoked".equals(code) || "expired".equals(code)
                    || "invalid".equals(code) || "not_found".equals(code)) {
                lockLicense(message == null ? "Lisensi tidak aktif." : message);
                return;
            }

            handleLicenseServerUnavailable(showToast);
        } catch (Exception error) {
            handleLicenseServerUnavailable(showToast);
        }
    }

    private void removeCheckWebView(final WebView view) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (view.getParent() instanceof ViewGroup) {
                        ((ViewGroup)view.getParent()).removeView(view);
                    }
                    view.stopLoading();
                    view.destroy();
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void handleLicenseServerUnavailable(boolean showToast) {
        // Mode kerja untuk WiFi perusahaan: kalau server tidak bisa dicek karena tidak ada internet,
        // APK tetap boleh masuk hanya jika lisensi pernah valid online, belum expired, dan masih dalam batas toleransi.
        if (canUseOfflineWorkMode()) {
            licenseUnlocked = true;
            setLicenseBadge("OFFLINE", Color.rgb(202, 138, 4));
            setStatus("Mode kerja offline aktif. Server lisensi tidak terjangkau, tapi key masih dalam batas toleransi dan belum expired.");
            startBrowserIfNeeded();
            if (showToast) {
                Toast.makeText(MainActivity.this,
                        "Mode kerja offline aktif. Nanti saat internet tersedia lisensi dicek ulang.",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }

        lockLicense("Server lisensi tidak bisa dicek dan batas mode kerja offline habis / key belum aktif / sudah expired.");
        if (showToast) {
            Toast.makeText(MainActivity.this,
                    "Hubungkan internet untuk cek lisensi ulang.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void lockLicense(final String reason) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                licenseUnlocked = false;
                runtimeSessionToken = "";
                runtimeUsername = "";
                runtimeSessionExpiry = 0L;
                setLicenseBadge("TERKUNCI", Color.rgb(185, 28, 28));
                setStatus(reason);
                showActivationDialog(true);
            }
        });
    }

    private boolean canUseOfflineWorkMode() {
        if (ADMIN_BUILD) return true;
        if (!licenseUnlocked) return false;
        if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) return false;
        if (!isCachedLicenseValid()) return false;
        long elapsedAtLastSuccess = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);
        if (elapsedAtLastSuccess > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtLastSuccess;
            return delta >= 0 && delta <= OFFLINE_WORK_GRACE_MS;
        }
        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        return lastCheck > 0 && System.currentTimeMillis() - lastCheck <= OFFLINE_WORK_GRACE_MS;
    }

    private boolean isCachedLicenseValid() {
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry <= 0) return false;
        return trustedNowMillis() < expiry;
    }

    private long trustedNowMillis() {
        long wall = System.currentTimeMillis();
        long server = preferences.getLong(PREF_LAST_SERVER_TIME, 0L);
        long elapsedAtServer = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);

        if (server > 0 && elapsedAtServer > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtServer;
            if (delta >= 0) {
                // Gunakan waktu server yang berjalan dengan elapsedRealtime, bukan jam HP.
                return server + delta;
            }
        }
        return wall;
    }

    private void updateLicenseBadgeFromCache() {
        if (ADMIN_BUILD) {
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            return;
        }
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry > trustedNowMillis()) {
            long remaining = expiry - trustedNowMillis();
            setLicenseBadge(shortRemaining(remaining), Color.rgb(22, 163, 74));
        } else {
            setLicenseBadge("HABIS", Color.rgb(185, 28, 28));
        }
    }

    private void setLicenseBadge(final String text, final int color) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (licenseBadge != null) {
                    licenseBadge.setText(text);
                    licenseBadge.setBackground(makeRounded(color, dp(14)));
                }
            }
        });
    }

    private String shortRemaining(long millis) {
        long minutes = Math.max(0, millis / 60000L);
        if (minutes < 60) return minutes + "m";
        long hours = minutes / 60;
        if (hours < 24) return hours + "j";
        long days = hours / 24;
        if (days < 365) return days + "h";
        return (days / 365) + "th";
    }

    private String longRemaining(long millis) {
        long totalMinutes = Math.max(0L, millis / 60000L);
        long days = totalMinutes / 1440L;
        long hours = (totalMinutes % 1440L) / 60L;
        long minutes = totalMinutes % 60L;
        StringBuilder out = new StringBuilder();
        if (days > 0) out.append(days).append(" hari ");
        if (hours > 0 || days > 0) out.append(hours).append(" jam ");
        out.append(minutes).append(" menit");
        return out.toString().trim();
    }

    private String formatDate(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID"));
        format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
        return format.format(new Date(millis));
    }

    private void postApi(final String endpoint, final Map<String, String> params, final ApiCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                JSONObject data = null;
                String error = null;
                boolean success = false;

                try {
                    StringBuilder body = new StringBuilder();
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        if (body.length() > 0) body.append('&');
                        body.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                        body.append('=');
                        body.append(URLEncoder.encode(entry.getValue() == null ? "" : entry.getValue(), "UTF-8"));
                    }

                    URL targetUrl = new URL(endpoint);
                    connection = (HttpURLConnection) (cellularNetwork != null
                            ? cellularNetwork.openConnection(targetUrl)
                            : targetUrl.openConnection());
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(12000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "ICE-Inject/2.3 Android");

                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
                    writer.write(body.toString());
                    writer.flush();
                    writer.close();

                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 400
                            ? connection.getInputStream()
                            : connection.getErrorStream();
                    String response = readStream(stream);
                    if (response.length() > 0) data = jsonFromText(response);
                    success = code >= 200 && code < 300 && data != null;
                    if (data == null && response != null && response.trim().startsWith("<")) {
                        error = "Server membalas HTML, bukan JSON. Gunakan metode WebView/Buka Web.";
                    } else if (data == null) {
                        error = "Respons server kosong atau bukan JSON.";
                    } else if (!success) {
                        error = data.optString("message", "HTTP " + code);
                    }
                } catch (Throwable throwable) {
                    error = throwable.getMessage();
                    if (error == null || error.length() == 0) error = throwable.getClass().getSimpleName();
                } finally {
                    if (connection != null) connection.disconnect();
                }

                final boolean finalSuccess = success;
                final JSONObject finalData = data;
                final String finalError = error;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onResult(finalSuccess, finalData, finalError);
                    }
                });
            }
        }).start();
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) output.append(line);
        reader.close();
        return output.toString();
    }

    private String getInstallDeviceId() {
        String id = null;
        try {
            id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Throwable ignored) {}

        if (id == null || id.length() < 6) {
            id = preferences.getString(PREF_DEVICE_ID, "");
            if (id.length() < 6) {
                id = "ICE-" + Long.toHexString(System.currentTimeMillis()) + "-" + Integer.toHexString((int) (Math.random() * Integer.MAX_VALUE));
                preferences.edit().putString(PREF_DEVICE_ID, id).apply();
            }
        }
        return id;
    }

    private String normalizeKey(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US).replace(' ', '-');
    }

    private String normalizeUsernameLocal(String value) {
        if (value == null) return "";
        String v = value.trim().toLowerCase(Locale.US);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') {
                out.append(c);
            }
        }
        return out.toString();
    }

    private String normalizeServerUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return "";
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private String normalizeUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return DEFAULT_URL;
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        return url;
    }

    private String shortUrl(String url) {
        if (url == null) return "website";
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return host == null ? url : host;
        } catch (Throwable ignored) {
            return url;
        }
    }

    private String maskKey(String key) {
        if (key == null || key.length() < 8) return "-";
        return key.substring(0, Math.min(7, key.length())) + "••••" + key.substring(Math.max(0, key.length() - 4));
    }

    private String quoteJs(String value) {
        if (value == null) return "\"\"";
        StringBuilder out = new StringBuilder(value.length() + 16);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                default:
                    if (c < 32 || c > 126) {
                        String hex = Integer.toHexString(c);
                        out.append("\\u");
                        for (int j = hex.length(); j < 4; j++) out.append('0');
                        out.append(hex);
                    } else {
                        out.append(c);
                    }
            }
        }
        out.append('"');
        return out.toString();
    }

    private String readAsset(String name) {
        StringBuilder output = new StringBuilder();
        try {
            InputStream stream = getAssets().open(name);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) output.append(line).append('\n');
            reader.close();
        } catch (Throwable ignored) {
            return "";
        }
        return output.toString();
    }

    private void setStatus(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusText != null) statusText.setText(message == null ? "" : message);
            }
        });
    }

    private void updateCallbackBadge(final int count) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (callbackBadge != null) {
                    callbackBadge.setText("CB: " + count);
                    callbackBadge.setBackground(makeRounded(
                            count > 0 ? Color.rgb(22, 163, 74) : Color.rgb(71, 85, 105),
                            dp(14)));
                }
            }
        });
    }

    private void startQrPhotoCapture() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        multiPhotoCaptureMode = false;
        if (!hasCameraPermission()) {
            pendingPhotoCaptureAfterPermission = true;
            requestPermissionsCompat(
                    new String[] { "android.permission.CAMERA" },
                    CAMERA_PERMISSION_REQUEST,
                    "Berikan izin kamera untuk Foto QR.");
            return;
        }
        launchSinglePhotoCamera();
    }

    private void startMultiQrPhotoCapture() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchManualSingleMode || batchAwaitingResult) {
            Toast.makeText(this, "Tunggu kirim manual selesai", Toast.LENGTH_SHORT).show();
            return;
        }

        // Foto banyak dimaksudkan untuk mengumpulkan kode terlebih dahulu,
        // jadi antrean aktif dijeda agar tidak ikut terkirim saat kamera terbuka.
        if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
        }

        multiPhotoCaptureMode = true;
        multiPhotoAdded = 0;
        multiPhotoDuplicates = 0;
        multiPhotoFailed = 0;

        if (!hasCameraPermission()) {
            pendingPhotoCaptureAfterPermission = true;
            requestPermissionsCompat(
                    new String[] { "android.permission.CAMERA" },
                    CAMERA_PERMISSION_REQUEST,
                    "Berikan izin kamera untuk mode Foto Banyak.");
            return;
        }
        launchMultiPhotoCamera();
    }

    private void launchMultiPhotoCamera() {
        try {
            Intent intent = new Intent(this, MultiPhotoCameraActivity.class);
            intent.putExtra(MultiPhotoCameraActivity.EXTRA_MODE, MultiPhotoCameraActivity.MODE_QUEUE);
            startActivityForResult(intent, MULTI_PHOTO_QR_REQUEST);
            setStatus("Mode foto banyak aktif. Hasil langsung masuk antrean tanpa mengisi kolom.");
        } catch (Throwable error) {
            multiPhotoFailed++;
            finishMultiPhotoCapture();
            setStatus("Kamera foto banyak gagal dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera foto banyak gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private void launchSinglePhotoCamera() {
        try {
            Intent intent = new Intent(this, MultiPhotoCameraActivity.class);
            intent.putExtra(MultiPhotoCameraActivity.EXTRA_MODE, MultiPhotoCameraActivity.MODE_SINGLE);
            startActivityForResult(intent, IN_APP_PHOTO_QR_REQUEST);
            setStatus("Kamera QR dalam aplikasi dibuka. Jepret satu QR.");
        } catch (Throwable error) {
            setStatus("Kamera QR gagal dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera QR gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private void launchQrCamera() {
        cleanupPendingQrPhoto();
        try {
            File photoDir = new File(getCacheDir(), "qr_photos");
            if (!photoDir.exists() && !photoDir.mkdirs()) {
                throw new IllegalStateException("Folder cache kamera tidak dapat dibuat");
            }
            pendingQrPhotoFile = File.createTempFile("qr_", ".jpg", photoDir);
            pendingQrPhotoUri = QrPhotoProvider.getUriForFile(this, pendingQrPhotoFile);

            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingQrPhotoUri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 16) {
                cameraIntent.setClipData(ClipData.newRawUri("Foto QR", pendingQrPhotoUri));
            }
            startActivityForResult(cameraIntent, PHOTO_QR_REQUEST);
            if (multiPhotoCaptureMode) {
                setStatus("Mode foto banyak: jepret QR. Kamera terbuka lagi otomatis; tekan Kembali jika selesai.");
            } else {
                setStatus("Arahkan kamera ke QR lalu jepret.");
            }
        } catch (Throwable error) {
            cleanupPendingQrPhoto();
            if (multiPhotoCaptureMode) {
                multiPhotoFailed++;
                finishMultiPhotoCapture();
            }
            setStatus("Kamera tidak dapat dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera tidak dapat dibuka", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SYSTEM_VPN_REQUEST) {
            if (resultCode == RESULT_OK) startSystemDualService();
            else {
                pendingSystemVpnStart = false;
                setStatus("Izin VPN dibatalkan. Dual sistem belum aktif.");
            }
            return;
        }
        if (requestCode == IN_APP_PHOTO_QR_REQUEST) {
            if (resultCode != RESULT_OK || data == null) {
                setStatus("Foto QR dibatalkan.");
                return;
            }
            String result = data.getStringExtra(MultiPhotoCameraActivity.EXTRA_CODE);
            result = result == null ? "" : result.trim();
            if (result.length() == 0) {
                setStatus("Hasil foto QR kosong.");
                Toast.makeText(this, "QR tidak terbaca", Toast.LENGTH_SHORT).show();
                return;
            }
            if (codeInput != null) codeInput.setText(result);
            setStatus("Hasil foto: " + result + " • mengirim ke scanner…");
            Toast.makeText(this, "Terbaca: " + result, Toast.LENGTH_LONG).show();
            sendCodeValue(result, true);
            return;
        }
        if (requestCode == MULTI_PHOTO_QR_REQUEST) {
            // Cadangan jika broadcast sempat terlewat: pastikan seluruh kode hasil sesi
            // tetap masuk ke antrean, tanpa pernah mengisi kolom ketik.
            if (data != null) {
                ArrayList<String> codes = data.getStringArrayListExtra("codes");
                if (codes != null) {
                    for (String raw : codes) {
                        String code = raw == null ? "" : raw.trim();
                        if (code.length() == 0 || batchSeen.containsKey(code)) continue;
                        if (addPhotoCodeToBatch(code)) multiPhotoAdded++;
                    }
                }
                multiPhotoFailed = Math.max(multiPhotoFailed, data.getIntExtra("failed", 0));
            }
            finishMultiPhotoCapture();
            return;
        }
        if (requestCode != PHOTO_QR_REQUEST) return;

        if (resultCode != RESULT_OK) {
            cleanupPendingQrPhoto();
            if (multiPhotoCaptureMode) {
                finishMultiPhotoCapture();
            } else {
                setStatus("Foto QR dibatalkan.");
            }
            return;
        }

        final boolean batchPhoto = multiPhotoCaptureMode;
        final File photoFile = pendingQrPhotoFile;
        final Bitmap fallbackBitmap = extractCameraThumbnail(data);
        pendingQrPhotoFile = null;
        pendingQrPhotoUri = null;
        setStatus(batchPhoto ? "Membaca foto lalu menambahkannya ke antrean…" : "Membaca QR dari foto…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                String decoded = "";
                String errorText = "QR tidak ditemukan. Jepret lebih dekat dan pastikan tidak buram.";
                Bitmap bitmap = null;
                try {
                    if (photoFile != null && photoFile.exists() && photoFile.length() > 0) {
                        bitmap = decodeScaledBitmap(photoFile, 2600);
                    }
                    if (bitmap == null) bitmap = fallbackBitmap;
                    if (bitmap == null) {
                        errorText = "Hasil foto kamera kosong.";
                    } else {
                        decoded = decodeBarcodeFromBitmap(bitmap);
                    }
                } catch (NotFoundException ignored) {
                    // Gunakan pesan panduan default agar pengguna dapat langsung mencoba ulang.
                } catch (Throwable error) {
                    errorText = "Gagal membaca foto: " + safeError(error);
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) {
                        try { bitmap.recycle(); } catch (Throwable ignored) {}
                    }
                    if (fallbackBitmap != null && fallbackBitmap != bitmap && !fallbackBitmap.isRecycled()) {
                        try { fallbackBitmap.recycle(); } catch (Throwable ignored) {}
                    }
                    if (photoFile != null) {
                        try { photoFile.delete(); } catch (Throwable ignored) {}
                    }
                }

                final String result = decoded == null ? "" : decoded.trim();
                final String finalError = errorText;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!batchPhoto) {
                            if (result.length() == 0) {
                                setStatus(finalError);
                                Toast.makeText(MainActivity.this, finalError, Toast.LENGTH_LONG).show();
                                return;
                            }
                            if (codeInput != null) codeInput.setText(result);
                            setStatus("QR foto terbaca. Mengirim ke scanner…");
                            sendCodeValue(result, true);
                            Toast.makeText(MainActivity.this,
                                    "QR terbaca dan langsung dikirim",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (!multiPhotoCaptureMode) return;

                        if (result.length() == 0) {
                            multiPhotoFailed++;
                            setStatus(finalError + " Gagal: " + multiPhotoFailed
                                    + ". Kamera dibuka lagi; tekan Kembali jika selesai.");
                            Toast.makeText(MainActivity.this,
                                    "QR tidak terbaca, silakan jepret ulang",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            boolean added = addPhotoCodeToBatch(result);
                            if (added) {
                                multiPhotoAdded++;
                                setStatus("Masuk antrean: " + result + " • sesi " + multiPhotoAdded
                                        + " • total antrean " + batchQueue.size());
                            } else {
                                multiPhotoDuplicates++;
                                setStatus("Duplikat dilewati: " + result + " • duplikat sesi "
                                        + multiPhotoDuplicates);
                            }
                        }

                        // Foto telah diubah menjadi teks dan file cache telah dihapus.
                        // Buka kamera lagi agar pengguna bisa terus menjepret tanpa batas tetap.
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (multiPhotoCaptureMode && !isFinishing()
                                        && (Build.VERSION.SDK_INT < 17 || !isDestroyed())) {
                                    launchQrCamera();
                                }
                            }
                        }, 350L);
                    }
                });
            }
        }, batchPhoto ? "ice-photo-queue" : "ice-photo-qr").start();
    }

    private boolean addPhotoCodeToBatch(String rawCode) {
        String code = rawCode == null ? "" : rawCode.trim();
        if (code.length() == 0) return false;
        if (batchSeen.containsKey(code)) {
            batchDuplicates++;
            persistBatchState();
            updateBatchUi();
            return false;
        }
        batchSeen.put(code, true);
        batchQueue.add(code);
        persistBatchState();
        updateBatchUi();
        return true;
    }

    private void finishMultiPhotoCapture() {
        if (!multiPhotoCaptureMode) return;
        multiPhotoCaptureMode = false;
        cleanupPendingQrPhoto();

        final String summary = "Foto banyak selesai: " + multiPhotoAdded + " masuk antrean"
                + (multiPhotoDuplicates > 0 ? ", " + multiPhotoDuplicates + " duplikat" : "")
                + (multiPhotoFailed > 0 ? ", " + multiPhotoFailed + " gagal dibaca" : "")
                + ". Total antrean " + batchQueue.size() + ".";
        setStatus(summary);
        Toast.makeText(this, summary, Toast.LENGTH_LONG).show();

        // Tidak membuka kolom atau dialog secara paksa. Kode sudah langsung berada
        // di Antrean QR dan pengguna dapat menekan tombol antrean saat siap mengirim.
        updateBatchUi();
    }

    private Bitmap extractCameraThumbnail(Intent data) {
        if (data == null || data.getExtras() == null) return null;
        try {
            Object value = data.getExtras().get("data");
            return value instanceof Bitmap ? (Bitmap) value : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Bitmap decodeScaledBitmap(File file, int maxSide) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int sample = 1;
        while ((bounds.outWidth / sample) > maxSide || (bounds.outHeight / sample) > maxSide) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sample);
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    }

    private String decodeBarcodeFromBitmap(Bitmap bitmap) throws Exception {
        int[] rotations = new int[] { 0, 90, 180, 270 };
        Exception lastError = null;
        for (int degrees : rotations) {
            Bitmap candidate = degrees == 0 ? bitmap : rotateBitmap(bitmap, degrees);
            try {
                String value = decodeBarcodeCandidate(candidate);
                if (value != null && value.trim().length() > 0) return value.trim();
            } catch (Exception error) {
                lastError = error;
            } finally {
                if (candidate != bitmap && candidate != null && !candidate.isRecycled()) {
                    candidate.recycle();
                }
            }
        }
        if (lastError != null) throw lastError;
        throw NotFoundException.getNotFoundInstance();
    }

    private Bitmap rotateBitmap(Bitmap source, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(source, 0, 0,
                source.getWidth(), source.getHeight(), matrix, true);
    }

    private String decodeBarcodeCandidate(Bitmap bitmap) throws Exception {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        LuminanceSource source = new RGBLuminanceSource(width, height, pixels);

        EnumMap<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.AZTEC,
                BarcodeFormat.PDF_417,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.ITF,
                BarcodeFormat.CODABAR));

        MultiFormatReader reader = new MultiFormatReader();
        reader.setHints(hints);
        try {
            Result result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source)));
            return result == null ? "" : result.getText();
        } catch (NotFoundException first) {
            reader.reset();
            try {
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new GlobalHistogramBinarizer(source)));
                return result == null ? "" : result.getText();
            } catch (NotFoundException second) {
                reader.reset();
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new HybridBinarizer(source.invert())));
                return result == null ? "" : result.getText();
            }
        } finally {
            reader.reset();
        }
    }

    private void cleanupPendingQrPhoto() {
        File oldFile = pendingQrPhotoFile;
        pendingQrPhotoFile = null;
        pendingQrPhotoUri = null;
        if (oldFile != null) {
            try { oldFile.delete(); } catch (Throwable ignored) {}
        }
    }

    private String safeError(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        if (message == null || message.trim().length() == 0) {
            message = error.getClass().getSimpleName();
        }
        return message;
    }

    private void registerDualVpnReceiver() {
        if (dualVpnReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(DualNetworkVpnService.ACTION_STATE);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(dualVpnStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(dualVpnStateReceiver, filter);
            }
            dualVpnReceiverRegistered = true;
        } catch (Throwable ignored) {}
    }

    private void querySystemVpnState() {
        try {
            Intent service = new Intent(this, DualNetworkVpnService.class);
            service.setAction(DualNetworkVpnService.ACTION_QUERY);
            startService(service);
        } catch (Throwable ignored) {}
    }

    private void registerMultiPhotoReceiver() {
        if (multiPhotoReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(MultiPhotoCameraActivity.ACTION_RESULT);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(multiPhotoResultReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(multiPhotoResultReceiver, filter);
            }
            multiPhotoReceiverRegistered = true;
        } catch (Throwable ignored) {}
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            Method method = Activity.class.getMethod("checkSelfPermission", String.class);
            Object result = method.invoke(this, permission);
            return result instanceof Integer && ((Integer) result) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean hasCameraPermission() {
        return hasPermission("android.permission.CAMERA");
    }

    private boolean hasLocationPermission() {
        return hasPermission("android.permission.ACCESS_FINE_LOCATION")
                || hasPermission("android.permission.ACCESS_COARSE_LOCATION");
    }

    private void requestPermissionsCompat(String[] permissions, int requestCode, String errorText) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            Method method = Activity.class.getMethod("requestPermissions", String[].class, int.class);
            method.invoke(this, new Object[] { permissions, requestCode });
        } catch (Throwable ignored) {
            setStatus(errorText);
        }
    }

    private void requestCameraPermissionIfNeeded() {
        if (hasCameraPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] { "android.permission.CAMERA" },
                CAMERA_PERMISSION_REQUEST,
                "Berikan izin kamera dari Pengaturan aplikasi.");
    }

    private void requestLocationPermissionIfNeeded() {
        if (hasLocationPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] {
                        "android.permission.ACCESS_FINE_LOCATION",
                        "android.permission.ACCESS_COARSE_LOCATION"
                },
                LOCATION_PERMISSION_REQUEST,
                "Berikan izin lokasi dari Pengaturan aplikasi.");
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean granted = grantResults != null && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (granted) {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera diberikan.");
                if (pendingPhotoCaptureAfterPermission) {
                    pendingPhotoCaptureAfterPermission = false;
                    if (multiPhotoCaptureMode) launchMultiPhotoCamera();
                    else launchSinglePhotoCamera();
                }
            } else {
                pendingPhotoCaptureAfterPermission = false;
                multiPhotoCaptureMode = false;
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.deny();
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            return;
        }

        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if ((granted || hasLocationPermission())
                    && pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, true, false);
                setStatus("Izin lokasi diberikan.");
            } else if (pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, false, false);
                setStatus("Izin lokasi ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            pendingGeolocationCallback = null;
            pendingGeolocationOrigin = null;
            if (pendingWorkWifiPermission) {
                pendingWorkWifiPermission = false;
                if (granted || hasLocationPermission()) {
                    if (pendingSystemVpnStart) handleNetworkBadgeClick();
                    else showDualNetworkInfo();
                } else {
                    pendingSystemVpnStart = false;
                    setStatus("Izin lokasi diperlukan untuk memilih Wi-Fi kerja.");
                }
            }
        }
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(makeRounded(Color.rgb(51, 65, 85), dp(9)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36));
        params.setMargins(dp(4), 0, 0, 0);
        button.setLayoutParams(params);
        return button;
    }


    private Button actionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(makeRounded(color, dp(10)));
        return button;
    }


    private GradientDrawable makeRounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (toolsVisible) hideTools(); else showTools();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_BACK && currentTab != null && currentTab.webView.canGoBack()) {
            currentTab.webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (batchManualSingleMode) {
            cancelManualBatchSend("Kirim manual dibatalkan karena aplikasi tidak aktif. Kode tetap di antrean.");
        } else if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
            setStatus("Antrean QR dijeda karena aplikasi tidak aktif.");
        }
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onPause();
                if (tab != currentTab) tab.webView.pauseTimers();
            } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        discoverExistingNetworks();
        refreshNetworkRoute();
        updateNetworkBadge();
        handler.postDelayed(new Runnable() {
            @Override public void run() { querySystemVpnState(); }
        }, 250L);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                maybeAutoConnectWorkWifi();
            }
        }, 800L);
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onResume();
                if (tab == currentTab) tab.webView.resumeTimers();
            } catch (Throwable ignored) {}
        }
        if (!ADMIN_BUILD) {
            // Jika sesi masih hidup, cek server saat kembali aktif. Jika proses APK mati, token memori hilang dan harus login ulang.
            if (licenseUnlocked && runtimeSessionToken.length() > 0) {
                preferences.edit().putLong(PREF_LAST_CHECK, 0L).apply();
                validateLicenseAsync(false);
                startLicenseWatchdog();
            }
        }
    }

    @Override
    protected void onDestroy() {
        runtimeSessionToken = "";
        runtimeUsername = "";
        runtimeSessionExpiry = 0L;
        preferences.edit().remove(PREF_LICENSE_TOKEN).remove(PREF_LICENSE_EXPIRY).apply();
        handler.removeCallbacksAndMessages(null);
        for (TabState tab : new ArrayList<TabState>(tabs)) {
            tab.destroyed = true;
            tab.webView.removeJavascriptInterface("AndroidBridge");
            tab.webView.destroy();
        }
        tabs.clear();
        try {
            if (connectivityManager != null && networkCallbacksRegistered) {
                if (wifiNetworkCallback != null) connectivityManager.unregisterNetworkCallback(wifiNetworkCallback);
                if (cellularNetworkCallback != null) connectivityManager.unregisterNetworkCallback(cellularNetworkCallback);
            }
        } catch (Throwable ignored) {}
        boolean keepWifiForSystemVpn = systemVpnRunning;
        if (!keepWifiForSystemVpn) {
            try {
                if (connectivityManager != null && localOnlyWifiCallback != null) {
                    connectivityManager.unregisterNetworkCallback(localOnlyWifiCallback);
                }
            } catch (Throwable ignored) {}
            clearProcessNetworkBinding();
        }
        if (dualVpnReceiverRegistered) {
            try { unregisterReceiver(dualVpnStateReceiver); } catch (Throwable ignored) {}
            dualVpnReceiverRegistered = false;
        }
        if (multiPhotoReceiverRegistered) {
            try { unregisterReceiver(multiPhotoResultReceiver); } catch (Throwable ignored) {}
            multiPhotoReceiverRegistered = false;
        }
        multiPhotoCaptureMode = false;
        cleanupPendingQrPhoto();
        super.onDestroy();
    }

    public class AndroidBridge {
        private final TabState tab;

        AndroidBridge(TabState tab) {
            this.tab = tab;
        }

        @JavascriptInterface
        public void onStatus(String message) {
            if (tab == currentTab) setStatus(message);
        }

        @JavascriptInterface
        public void onCallbackCount(final int count) {
            tab.callbackCount = count;
            if (tab == currentTab) updateCallbackBadge(count);
        }

        @JavascriptInterface
        public void onSendReport(final String report) {
            // Laporan tetap lokal di perangkat. Untuk antrean massal, ini menjadi
            // konfirmasi bahwa kode benar-benar sudah diproses bridge, bukan baru masuk antrean JS.
            try {
                final JSONObject data = new JSONObject(report == null ? "{}" : report);
                final String requestId = data.optString("requestId", "");
                if (!requestId.startsWith("batch:")) return;
                final int token = Integer.parseInt(requestId.substring(6));
                final String code = data.optString("text", "");
                final boolean ok = data.optBoolean("ok", false);
                final String reason = data.optString("reason", ok ? "" : "delivery_failed");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleBatchDeliveryReport(token, code, ok, reason);
                    }
                });
            } catch (Throwable ignored) {}
        }
    }
}
