(function () {
  'use strict';

  var w = window;
  var VERSION = 1;
  var existing = w.__ICEPhotoScanBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }

  var callbacks = [];
  var patchTimers = [];
  var observer = null;
  var lastCount = -1;
  var destroyed = false;
  var MAX_CALLBACKS = 4;

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount() {
    if (callbacks.length === lastCount) return;
    lastCount = callbacks.length;
    androidCall('onCallbackCount', [callbacks.length]);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source || 'scanner', mode: mode || 'html5' });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount();
  }

  function wrap(proto, name, factory) {
    try {
      if (!proto || typeof proto[name] !== 'function' || proto[name].__icePhotoWrapped) return;
      var original = proto[name];
      var wrapped = factory(original);
      wrapped.__icePhotoWrapped = true;
      proto[name] = wrapped;
    } catch (_) {}
  }

  function patch() {
    if (destroyed) return;
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrap(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, 'Html5Qrcode.start', 'html5');
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        });
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrap(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, 'Html5QrcodeScanner.render', 'html5');
            return original.call(this, successCallback, errorCallback);
          };
        });
      }
    } catch (_) {}

    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__icePhotoWrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__icePhotoWrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}
    reportCount();
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: { text: text, format: { formatName: 'QR_CODE', format: 'QR_CODE' } }
    };
  }

  function invoke(entry, text) {
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; }
      });
    }
    return entry.fn(text, decodedResult(text));
  }

  function invokeNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function send(text) {
    text = String(text == null ? '' : text).trim();
    if (!text) return JSON.stringify({ ok: false, reason: 'empty' });
    patch();

    for (var i = callbacks.length - 1; i >= 0; i--) {
      try {
        invoke(callbacks[i], text);
        report('Hasil foto dikirim ke scanner aktif.');
        return JSON.stringify({ ok: true, source: callbacks[i].source });
      } catch (_) {}
    }

    var named = invokeNamed(text);
    if (named) {
      report('Hasil foto dikirim lewat ' + named + '.');
      return JSON.stringify({ ok: true, source: named });
    }

    report('Scanner belum siap. Buka menu Scan QR pada halaman lalu foto ulang.');
    return JSON.stringify({ ok: false, reason: 'scanner_not_ready' });
  }

  function schedulePatch() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000];
    for (var j = 0; j < delays.length; j++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(patch, delay));
      })(delays[j]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function () {
      if (destroyed || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
  }

  w.__ICEPhotoScanBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    getCallbackCount: function () { return callbacks.length; }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
  } catch (_) {}

  patch();
  installObserver();
  schedulePatch();
})();
