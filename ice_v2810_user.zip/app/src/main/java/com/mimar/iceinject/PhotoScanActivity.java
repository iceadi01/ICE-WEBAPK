package com.mimar.iceinject;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressWarnings("deprecation")
public class PhotoScanActivity extends Activity implements SurfaceHolder.Callback {
    public static final String EXTRA_CODE = "photo_scan_code";

    private final ExecutorService decoder = Executors.newSingleThreadExecutor();
    private SurfaceHolder previewHolder;
    private Camera camera;
    private int cameraId = -1;
    private boolean surfaceReady = false;
    private boolean captureInProgress = false;
    private boolean flashEnabled = false;

    private TextView statusText;
    private Button captureButton;
    private Button flashButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Izin kamera belum diberikan", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildUi();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        SurfaceView preview = new SurfaceView(this);
        previewHolder = preview.getHolder();
        previewHolder.addCallback(this);
        root.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView guide = new TextView(this);
        guide.setText("FOTO SCAN 1×\nArahkan QR/barcode ke kotak lalu tekan JEPRET");
        guide.setTextColor(Color.WHITE);
        guide.setTextSize(15);
        guide.setGravity(Gravity.CENTER);
        guide.setPadding(dp(14), dp(10), dp(14), dp(10));
        guide.setBackground(rounded(Color.argb(210, 15, 23, 42), dp(14)));
        FrameLayout.LayoutParams guideParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        guideParams.setMargins(dp(14), dp(18), dp(14), 0);
        root.addView(guide, guideParams);

        View scanBox = new View(this);
        GradientDrawable box = new GradientDrawable();
        box.setColor(Color.TRANSPARENT);
        box.setStroke(dp(3), Color.rgb(34, 197, 94));
        box.setCornerRadius(dp(18));
        scanBox.setBackground(box);
        FrameLayout.LayoutParams boxParams = new FrameLayout.LayoutParams(
                dp(280), dp(220), Gravity.CENTER);
        root.addView(scanBox, boxParams);

        statusText = new TextView(this);
        statusText.setText("Kamera sedang disiapkan…");
        statusText.setTextColor(Color.WHITE);
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(9), dp(12), dp(9));
        statusText.setBackground(rounded(Color.argb(220, 30, 41, 59), dp(14)));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        statusParams.setMargins(dp(14), 0, dp(14), dp(86));
        root.addView(statusText, statusParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(10), dp(8), dp(10), dp(12));
        controls.setBackgroundColor(Color.argb(225, 2, 6, 23));

        Button cancelButton = button("BATAL", Color.rgb(71, 85, 105));
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setResult(RESULT_CANCELED); finish(); }
        });
        controls.addView(cancelButton, new LinearLayout.LayoutParams(0, dp(56), 1));

        captureButton = button("JEPRET", Color.rgb(22, 163, 74));
        captureButton.setEnabled(false);
        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { takePhoto(); }
        });
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(0, dp(56), 1.5f);
        captureParams.setMargins(dp(8), 0, dp(8), 0);
        controls.addView(captureButton, captureParams);

        flashButton = button("FLASH", Color.rgb(71, 85, 105));
        flashButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFlash(); }
        });
        controls.addView(flashButton, new LinearLayout.LayoutParams(0, dp(56), 1));

        FrameLayout.LayoutParams controlsParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        root.addView(controls, controlsParams);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (surfaceReady && camera == null) openCamera();
    }

    @Override protected void onPause() {
        releaseCamera();
        super.onPause();
    }

    @Override protected void onDestroy() {
        decoder.shutdownNow();
        super.onDestroy();
    }

    @Override public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        openCamera();
    }

    @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (camera == null) return;
        try { camera.stopPreview(); } catch (Throwable ignored) {}
        startPreview();
    }

    @Override public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseCamera();
    }

    private void openCamera() {
        if (!surfaceReady || camera != null || isFinishing()) return;
        try {
            cameraId = findBackCamera();
            camera = cameraId >= 0 ? Camera.open(cameraId) : Camera.open();
            configureCamera();
            camera.setPreviewDisplay(previewHolder);
            startPreview();
            showStatus("Kamera siap. Pastikan gambar fokus lalu jepret.", true);
            setCaptureEnabled(true);
        } catch (Throwable error) {
            releaseCamera();
            showStatus("Kamera gagal dibuka: " + safeError(error), false);
            Toast.makeText(this, "Kamera gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private int findBackCamera() {
        try {
            Camera.CameraInfo info = new Camera.CameraInfo();
            for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
                Camera.getCameraInfo(i, info);
                if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) return i;
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    private void configureCamera() {
        Camera.Parameters parameters = camera.getParameters();
        List<String> focusModes = parameters.getSupportedFocusModes();
        if (focusModes != null) {
            if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }
        }
        List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
        if (sizes != null && !sizes.isEmpty()) {
            Camera.Size best = sizes.get(0);
            long bestScore = 0;
            for (Camera.Size size : sizes) {
                long pixels = (long) size.width * size.height;
                if (pixels <= 12_000_000L && pixels > bestScore) {
                    best = size;
                    bestScore = pixels;
                }
            }
            parameters.setPictureSize(best.width, best.height);
        }
        camera.setParameters(parameters);
        camera.setDisplayOrientation(calculateDisplayOrientation());
    }

    private int calculateDisplayOrientation() {
        if (cameraId < 0) return 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(cameraId, info);
        int degrees = rotationDegrees();
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            return (360 - ((info.orientation + degrees) % 360)) % 360;
        }
        return (info.orientation - degrees + 360) % 360;
    }

    private int calculateJpegRotation() {
        if (cameraId < 0) return 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(cameraId, info);
        int degrees = rotationDegrees();
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            return (info.orientation - degrees + 360) % 360;
        }
        return (info.orientation + degrees) % 360;
    }

    private int rotationDegrees() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        if (rotation == Surface.ROTATION_90) return 90;
        if (rotation == Surface.ROTATION_180) return 180;
        if (rotation == Surface.ROTATION_270) return 270;
        return 0;
    }

    private void startPreview() {
        if (camera == null) return;
        try {
            camera.startPreview();
            setCaptureEnabled(true);
        } catch (Throwable error) {
            showStatus("Preview kamera gagal: " + safeError(error), false);
        }
    }

    private void releaseCamera() {
        Camera old = camera;
        camera = null;
        if (old == null) return;
        try { old.setPreviewCallback(null); } catch (Throwable ignored) {}
        try { old.stopPreview(); } catch (Throwable ignored) {}
        try { old.release(); } catch (Throwable ignored) {}
    }

    private void takePhoto() {
        if (camera == null || captureInProgress) return;
        captureInProgress = true;
        setCaptureEnabled(false);
        showStatus("Mengambil foto…", false);
        try {
            Camera.Parameters parameters = camera.getParameters();
            parameters.setRotation(calculateJpegRotation());
            camera.setParameters(parameters);
            camera.takePicture(null, null, new Camera.PictureCallback() {
                @Override public void onPictureTaken(byte[] data, Camera source) {
                    decodePhoto(data);
                }
            });
        } catch (Throwable error) {
            captureInProgress = false;
            showStatus("Gagal mengambil foto: " + safeError(error), false);
            startPreview();
        }
    }

    private void decodePhoto(final byte[] jpegData) {
        decoder.execute(new Runnable() {
            @Override public void run() {
                String value = "";
                String error = "QR/barcode tidak ditemukan. Dekatkan kamera dan pastikan tidak buram.";
                Bitmap bitmap = null;
                try {
                    bitmap = decodeScaledBitmap(jpegData, 2600);
                    if (bitmap == null) error = "Hasil foto kamera kosong.";
                    else value = decodeBarcodeFromBitmap(bitmap);
                } catch (NotFoundException ignored) {
                    // Gunakan panduan default.
                } catch (Throwable throwable) {
                    error = "Gagal membaca foto: " + safeError(throwable);
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                }
                final String result = value == null ? "" : value.trim();
                final String finalError = error;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        captureInProgress = false;
                        if (result.length() == 0) {
                            showStatus(finalError, false);
                            Toast.makeText(PhotoScanActivity.this, finalError, Toast.LENGTH_LONG).show();
                            startPreview();
                            setCaptureEnabled(true);
                            return;
                        }
                        showStatus("Terbaca: " + result, true);
                        Intent output = new Intent();
                        output.putExtra(EXTRA_CODE, result);
                        setResult(RESULT_OK, output);
                        Toast.makeText(PhotoScanActivity.this, "Terbaca: " + result, Toast.LENGTH_LONG).show();
                        finish();
                    }
                });
            }
        });
    }

    private Bitmap decodeScaledBitmap(byte[] data, int maxSide) {
        if (data == null || data.length == 0) return null;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while ((bounds.outWidth / sample) > maxSide || (bounds.outHeight / sample) > maxSide) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sample);
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }

    private String decodeBarcodeFromBitmap(Bitmap bitmap) throws Exception {
        int[] rotations = new int[] {0, 90, 180, 270};
        Exception last = null;
        for (int degrees : rotations) {
            Bitmap candidate = degrees == 0 ? bitmap : rotateBitmap(bitmap, degrees);
            try {
                String value = decodeBarcodeCandidate(candidate);
                if (value != null && value.trim().length() > 0) return value.trim();
            } catch (Exception error) {
                last = error;
            } finally {
                if (candidate != bitmap && candidate != null && !candidate.isRecycled()) candidate.recycle();
            }
        }
        if (last != null) throw last;
        throw NotFoundException.getNotFoundInstance();
    }

    private Bitmap rotateBitmap(Bitmap source, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    private String decodeBarcodeCandidate(Bitmap bitmap) throws Exception {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        LuminanceSource source = new RGBLuminanceSource(width, height, pixels);

        EnumMap<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX, BarcodeFormat.AZTEC,
                BarcodeFormat.PDF_417, BarcodeFormat.CODE_128, BarcodeFormat.CODE_39,
                BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E, BarcodeFormat.ITF, BarcodeFormat.CODABAR));

        MultiFormatReader reader = new MultiFormatReader();
        reader.setHints(hints);
        try {
            Result result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source)));
            return result == null ? "" : result.getText();
        } catch (NotFoundException first) {
            reader.reset();
            try {
                Result result = reader.decodeWithState(new BinaryBitmap(new GlobalHistogramBinarizer(source)));
                return result == null ? "" : result.getText();
            } catch (NotFoundException second) {
                reader.reset();
                Result result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source.invert())));
                return result == null ? "" : result.getText();
            }
        } finally {
            reader.reset();
        }
    }

    private void toggleFlash() {
        if (camera == null) return;
        try {
            Camera.Parameters parameters = camera.getParameters();
            List<String> modes = parameters.getSupportedFlashModes();
            if (modes == null || !modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                Toast.makeText(this, "Flash tidak didukung kamera ini", Toast.LENGTH_SHORT).show();
                return;
            }
            flashEnabled = !flashEnabled;
            parameters.setFlashMode(flashEnabled
                    ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(parameters);
            flashButton.setText(flashEnabled ? "FLASH ON" : "FLASH");
            flashButton.setBackground(rounded(
                    flashEnabled ? Color.rgb(234, 179, 8) : Color.rgb(71, 85, 105), dp(14)));
        } catch (Throwable error) {
            Toast.makeText(this, "Flash gagal diubah", Toast.LENGTH_SHORT).show();
        }
    }

    private void setCaptureEnabled(boolean enabled) {
        if (captureButton == null) return;
        captureButton.setEnabled(enabled);
        captureButton.setAlpha(enabled ? 1f : 0.6f);
        captureButton.setText(enabled ? "JEPRET" : "...");
    }

    private void showStatus(String message, boolean success) {
        if (statusText == null) return;
        statusText.setText(message);
        statusText.setBackground(rounded(
                success ? Color.argb(225, 21, 128, 61) : Color.argb(225, 30, 41, 59), dp(14)));
    }

    private Button button(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(color, dp(14)));
        return button;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        return shape;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String safeError(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        if (message == null || message.trim().length() == 0) message = error.getClass().getSimpleName();
        return message;
    }
}
