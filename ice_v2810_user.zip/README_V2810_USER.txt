ICE Inject User v2.8.10

Perubahan jaringan lokal:
- Memperbaiki halaman Report/Realisasi SO yang sebelumnya gagal dengan net::ERR_INTERNET_DISCONNECTED.
- Tidak lagi membatasi Wi-Fi perusahaan hanya ke 172.30.16.0/20.
- Seluruh jaringan privat 172.16.0.0/12 didukung, sehingga seluruh 172.30.0.0/16 termasuk 172.30.2.40:8081 otomatis memakai Wi-Fi perusahaan.
- Jaringan privat 10.0.0.0/8 dan 192.168.0.0/16 juga diarahkan ke Wi-Fi perusahaan.
- Host internal tanpa domain, .local, .lan, IPv6 ULA/link-local, localhost, dan link-local IPv4 ikut didukung.
- Situs internet umum serta server login/lisensi tetap memakai data seluler.
- Tidak perlu menambahkan IP report satu per satu.

Build: jalankan build_user.sh melalui workflow GitHub Actions.
Output: ice_v2810_user.apk
