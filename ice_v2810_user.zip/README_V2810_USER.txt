ICE Inject User v2.8.10 — Foto Scan 1× + Dual Jaringan

Perubahan dari v2.8.9:
- Menghapus input scanner manual.
- Menghapus tombol Kirim/Kirim + Kosongkan/Cek.
- Menghapus antrean QR, kirim satu dari antrean, dan jepret banyak.
- Menghapus script Tampermonkey lama dan bridge antrean.
- Menghapus fungsi tombol volume untuk membuka panel scanner.
- Menyisakan Foto Scan 1×: jepret satu QR/barcode, baca lokal, lalu kirim ke scanner halaman.
- Dual jaringan Wi-Fi perusahaan + data seluler tetap dipertahankan.
- Browser, tab, bookmark, login/lisensi, kamera web, lokasi, dan desktop mode tetap dipertahankan.

Build:
  chmod +x build_user.sh
  ./build_user.sh

APK output:
  ice_v2810_user.apk
