(function () {
  'use strict';

  var w = window;
  var VERSION = 6;
  var existing = w.__LPWScannerBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }

  var callbacks = [];
  var patched = {};
  var patchTimers = [];
  var observer = null;
  var lastPatchAt = 0;
  var lastGuideAt = 0;
  var lastCount = -1;
  var recent = {};
  var queue = [];
  var processing = false;
  var destroyed = false;
  var prewarmRunning = false;
  var suppressNextScannerStart = false;
  var prewarmDone = false;
  var prewarmAttempts = 0;
  var prewarmTimer = 0;
  var namedHooksInstalled = false;
  var eventHookInstalled = false;
  var activeTarget = null;
  var activeTargetLabel = '';
  var activeTargetAuto = false;
  var scanTargets = [];
  var lastTargetState = '';
  var lastUrl = String(w.location && w.location.href || '');

  var MAX_CALLBACKS = 4;
  var MAX_QUEUE = 24;
  var CALLBACK_TTL = 12 * 60 * 60 * 1000;
  var DUPLICATE_MS = 1100;
  var SEND_GAP_MS = 140;

  function now() { return Date.now ? Date.now() : new Date().getTime(); }

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount(force) {
    var count = callbacks.length;
    if (!force && count === lastCount) return;
    lastCount = count;
    androidCall('onCallbackCount', [count]);
  }

  function callbackSources() {
    var out = [];
    for (var i = callbacks.length - 1; i >= 0; i--) {
      var source = callbacks[i] && callbacks[i].source;
      if (source && out.indexOf(source) < 0) out.push(source);
    }
    return out;
  }

  function cleanupRecent() {
    var cutoff = now() - Math.max(DUPLICATE_MS * 4, 10000);
    for (var key in recent) {
      if (Object.prototype.hasOwnProperty.call(recent, key) && recent[key] < cutoff) {
        delete recent[key];
      }
    }
  }

  function cleanupCallbacks() {
    var cutoff = now() - CALLBACK_TTL;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      if (entry.addedAt && entry.addedAt < cutoff) continue;
      next.push(entry);
    }
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    source = source || 'callback';
    mode = mode || 'html5';

    var stamp = now();
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source, mode: mode, addedAt: stamp });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
    report('Scanner siap. Jalur aktif: ' + source + '.');
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: {
        text: text,
        format: { formatName: 'QR_CODE', format: 'QR_CODE' }
      }
    };
  }

  function wrapMethod(proto, name, makeWrapper, key) {
    try {
      if (!proto || typeof proto[name] !== 'function') return false;
      if (proto[name].__iceBridgeV4) return true;
      var original = proto[name];
      var wrapped = makeWrapper(original);
      wrapped.__iceBridgeV4 = true;
      wrapped.__iceOriginal = original;
      proto[name] = wrapped;
      patched[key || name] = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  function patchHtml5Qrcode() {
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrapMethod(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, prewarmRunning ? 'ICE.prewarm.Html5Qrcode.start' : 'Html5Qrcode.start', 'html5');
            if (prewarmRunning || suppressNextScannerStart) {
              suppressNextScannerStart = false;
              prewarmDone = true;
              report('Callback scanner siap tanpa membuka kamera.');
              try { return w.Promise ? w.Promise.resolve(null) : null; } catch (_) { return null; }
            }
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        }, 'Html5Qrcode.start');
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrapMethod(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, prewarmRunning ? 'ICE.prewarm.Html5QrcodeScanner.render' : 'Html5QrcodeScanner.render', 'html5');
            if (prewarmRunning || suppressNextScannerStart) {
              suppressNextScannerStart = false;
              prewarmDone = true;
              report('Callback scanner siap tanpa membuka kamera.');
              return;
            }
            return original.call(this, successCallback, errorCallback);
          };
        }, 'Html5QrcodeScanner.render');
      }
    } catch (_) {}
  }

  function patchOtherLibraries() {
    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__iceBridgeV4Wrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__iceBridgeV4Wrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}

    try {
      var InstascanScanner = w.Instascan && w.Instascan.Scanner;
      if (typeof InstascanScanner === 'function' && InstascanScanner.prototype) {
        wrapMethod(InstascanScanner.prototype, 'addListener', function (original) {
          return function (eventName, callback) {
            if (String(eventName).toLowerCase() === 'scan') {
              addCallback(callback, 'Instascan.addListener', 'text');
            }
            return original.call(this, eventName, callback);
          };
        }, 'Instascan.addListener');
      }
    } catch (_) {}

    try {
      var Quagga = w.Quagga;
      if (Quagga && typeof Quagga.onDetected === 'function' && !Quagga.onDetected.__iceBridgeV4) {
        var originalOnDetected = Quagga.onDetected;
        var wrappedOnDetected = function (callback) {
          addCallback(callback, 'Quagga.onDetected', 'quagga');
          return originalOnDetected.call(this, callback);
        };
        wrappedOnDetected.__iceBridgeV4 = true;
        Quagga.onDetected = wrappedOnDetected;
      }
    } catch (_) {}
  }

  function tryContinuousFocus(video) {
    try {
      if (!video || !video.srcObject || !video.srcObject.getVideoTracks) return;
      var track = video.srcObject.getVideoTracks()[0];
      if (!track || track.__iceFocusV4) return;
      track.__iceFocusV4 = true;
      if (!track.getCapabilities || !track.applyConstraints) return;
      var caps = track.getCapabilities() || {};
      if (caps.focusMode && Array.prototype.indexOf.call(caps.focusMode, 'continuous') >= 0) {
        track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {});
      }
    } catch (_) {}
  }

  function directGuide(parent) {
    try {
      var children = parent.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i] && children[i].classList && children[i].classList.contains('ice-scan-guide')) {
          return children[i];
        }
      }
    } catch (_) {}
    return null;
  }

  function ensureScannerGuide() {
    if (document.hidden) return;
    var videos = [];
    try { videos = Array.prototype.slice.call(document.querySelectorAll('video')); } catch (_) {}
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      try {
        var rect = video.getBoundingClientRect();
        var style = w.getComputedStyle(video);
        if (rect.width < 160 || rect.height < 120 || style.display === 'none' || style.visibility === 'hidden') continue;
        tryContinuousFocus(video);
        var parent = video.parentElement;
        if (!parent || directGuide(parent)) continue;
        if (w.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

        var guide = document.createElement('div');
        guide.className = 'ice-scan-guide';
        guide.setAttribute('aria-hidden', 'true');
        guide.innerHTML = '<span>Pas-kan QR / barcode di dalam kotak</span><b></b>';
        guide.style.cssText = 'position:absolute;left:8%;right:8%;top:23%;height:48%;z-index:2147483000;pointer-events:none;border:2px solid rgba(34,197,94,.9);border-radius:14px;box-sizing:border-box;';
        var label = guide.querySelector('span');
        if (label) label.style.cssText = 'position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.82);color:#fff;border-radius:999px;padding:6px 10px;font:600 12px system-ui,sans-serif;';
        var line = guide.querySelector('b');
        if (line) line.style.cssText = 'position:absolute;left:7%;right:7%;top:50%;height:2px;background:#22c55e;box-shadow:0 0 8px #22c55e;';
        parent.appendChild(guide);
      } catch (_) {}
    }
  }


  function installNamedCallbackHooks() {
    if (namedHooksInstalled) return;
    namedHooksInstalled = true;
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      (function (name) {
        try {
          var descriptor = Object.getOwnPropertyDescriptor(w, name);
          if (descriptor && descriptor.configurable === false) {
            if (typeof w[name] === 'function') addCallback(w[name], 'window.' + name, 'html5');
            return;
          }
          var current = typeof w[name] === 'function' ? w[name] : null;
          if (current) addCallback(current, 'window.' + name, 'html5');
          Object.defineProperty(w, name, {
            configurable: true,
            enumerable: descriptor ? descriptor.enumerable : true,
            get: function () { return current; },
            set: function (value) {
              current = value;
              if (typeof value === 'function') addCallback(value, 'window.' + name, 'html5');
            }
          });
        } catch (_) {}
      })(names[i]);
    }
  }

  function installEventListenerHook() {
    if (eventHookInstalled) return;
    eventHookInstalled = true;
    try {
      var proto = w.EventTarget && w.EventTarget.prototype;
      if (!proto || typeof proto.addEventListener !== 'function' || proto.addEventListener.__iceBridgeV5) return;
      var original = proto.addEventListener;
      var wrapped = function (type, listener, options) {
        try {
          var key = String(type || '').toLowerCase();
          if (typeof listener === 'function' && /(scan|barcode|qrcode|qr-scanned)/.test(key)) {
            addCallback(listener, 'event:' + key, 'event');
          }
        } catch (_) {}
        return original.call(this, type, listener, options);
      };
      wrapped.__iceBridgeV5 = true;
      wrapped.__iceOriginal = original;
      proto.addEventListener = wrapped;
    } catch (_) {}
  }

  function elementText(el) {
    try {
      return [
        el.innerText, el.textContent, el.id, el.className, el.title,
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('data-testid')
      ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
    } catch (_) { return ''; }
  }

  function scannerTriggerScore(el) {
    var text = elementText(el);
    var score = 0;
    if (/scan\s*(qr|barcode)|(?:qr|barcode)\s*scan/.test(text)) score += 150;
    if (/buka\s*(kamera|camera)|kamera\s*scan|camera\s*scan/.test(text)) score += 120;
    if (/scanner|scan/.test(text)) score += 55;
    if (/qr|qrcode|barcode/.test(text)) score += 45;
    if (/kamera|camera/.test(text)) score += 30;
    if (/foto|photo|galeri|gallery|upload|lampiran/.test(text)) score -= 90;
    if (/tutup|close|batal|cancel|kembali|back|hapus|delete/.test(text)) score -= 160;
    try {
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') score -= 100;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 10;
      var style = w.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden') score -= 80;
    } catch (_) {}
    return score;
  }

  function findScannerTrigger() {
    var nodes = [];
    try { nodes = Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')); } catch (_) {}
    var best = null;
    var bestScore = 89;
    var limit = Math.min(nodes.length, 350);
    for (var i = 0; i < limit; i++) {
      var score = scannerTriggerScore(nodes[i]);
      if (score > bestScore) { best = nodes[i]; bestScore = score; }
    }
    return best;
  }

  function closePrewarmUi() {
    try {
      var nodes = Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"]'));
      var best = null;
      var score = 0;
      for (var i = 0; i < Math.min(nodes.length, 300); i++) {
        var text = elementText(nodes[i]);
        var current = 0;
        if (/^(×|x)$/.test(text)) current += 90;
        if (/tutup|close|batal|cancel|kembali|back/.test(text)) current += 70;
        try {
          var rect = nodes[i].getBoundingClientRect();
          if (rect.width > 15 && rect.height > 12) current += 10;
        } catch (_) {}
        if (current > score) { best = nodes[i]; score = current; }
      }
      if (best && score >= 70) best.click();
    } catch (_) {}
  }

  function shouldAutoPrewarm() {
    try {
      var host = String(w.location && w.location.hostname || '').toLowerCase();
      return host === 'lp4m-lpw.liebrapermana.com' || /(^|\.)liebrapermana\.com$/.test(host);
    } catch (_) { return false; }
  }

  function prewarmScanner() {
    if (destroyed || prewarmRunning || suppressNextScannerStart || prewarmDone || callbacks.length > 0) return;
    if (!shouldAutoPrewarm()) return;
    if (!document.body) return;
    if (prewarmAttempts >= 4) return;
    var trigger = findScannerTrigger();
    if (!trigger) return;

    prewarmAttempts++;
    prewarmRunning = true;
    suppressNextScannerStart = true;
    report('Menyiapkan callback scanner otomatis…');
    try { trigger.click(); } catch (_) { prewarmRunning = false; suppressNextScannerStart = false; return; }

    w.setTimeout(function () {
      prewarmRunning = false;
      if (callbacks.length > 0) {
        suppressNextScannerStart = false;
        prewarmDone = true;
        closePrewarmUi();
        report('Tampermonkey siap tanpa membuka kamera.');
      } else {
        closePrewarmUi();
      }
      reportCount(true);
    }, 900);

    w.setTimeout(function () {
      if (!prewarmDone) suppressNextScannerStart = false;
    }, 2400);
  }

  function schedulePrewarm() {
    if (prewarmTimer) {
      try { w.clearTimeout(prewarmTimer); } catch (_) {}
    }
    var delays = [250, 3000, 6500, 11000, 18000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        w.setTimeout(function () {
          patch();
          prewarmScanner();
        }, delay);
      })(delays[i]);
    }
  }

  function patch() {
    if (destroyed) return;
    var stamp = now();
    if (stamp - lastPatchAt < 220) return;
    lastPatchAt = stamp;
    var currentUrl = String(w.location && w.location.href || '');
    if (lastUrl && currentUrl && currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      scanTargets = [];
      clearActiveTarget('navigation', false);
    } else if (!lastUrl) lastUrl = currentUrl;
    cleanupCallbacks();
    cleanupRecent();
    installNamedCallbackHooks();
    installEventListenerHook();
    installTargetListenersDeep();
    patchHtml5Qrcode();
    patchOtherLibraries();
    refreshScanTargets(false);
    if (stamp - lastGuideAt > 1200) {
      lastGuideAt = stamp;
      ensureScannerGuide();
    }
    reportCount(false);
  }

  function clearPatchTimers() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
  }

  function schedulePatch() {
    clearPatchTimers();
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000, 22000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(function () {
          patch();
        }, delay));
      })(delays[i]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function (records) {
      if (destroyed || document.hidden) return;
      var useful = false;
      for (var i = 0; i < records.length && !useful; i++) {
        var added = records[i].addedNodes || [];
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          var tag = String(node.tagName || '').toLowerCase();
          if (tag === 'video' || tag === 'script' || tag === 'button' || tag === 'a' || tag === 'input' || tag === 'textarea' || tag === 'iframe' || (node.querySelector && node.querySelector('video,script,button,a,input,textarea,iframe,[contenteditable="true"],[role="button"]'))) {
            useful = true;
            break;
          }
        }
      }
      if (!useful || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
  }

  function invokeCallback(entry, text) {
    var detail = decodedResult(text);
    if (entry.mode === 'event') {
      var event;
      try { event = new CustomEvent('scan', { bubbles: true, detail: detail }); }
      catch (_) { event = { type: 'scan', detail: detail, data: text, text: text }; }
      return entry.fn.call(w, event);
    }
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; },
        valueOf: function () { return text; }
      });
    }
    if (entry.mode === 'quagga') {
      return entry.fn({
        codeResult: { code: text, format: 'code_128' },
        result: { code: text }
      });
    }
    return entry.fn(text, detail);
  }

  function invokeLatestCaptured(text) {
    cleanupCallbacks();
    var attempted = 0;
    for (var i = callbacks.length - 1; i >= 0 && attempted < 2; i--) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      attempted++;
      try {
        invokeCallback(entry, text);
        entry.addedAt = now();
        return { called: 1, source: entry.source, errors: 0 };
      } catch (_) {}
    }
    return { called: 0, source: '', errors: attempted };
  }

  function invokeOneNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function fieldScore(el) {
    var meta = targetMeta(el);
    var score = 0;
    if (/input barcode hu here/.test(meta)) score += 160;
    if (/barcode/.test(meta)) score += 70;
    if (/(^|\W)hu($|\W)/.test(meta)) score += 80;
    if (/carton|karton/.test(meta)) score += 52;
    if (/material/.test(meta)) score += 72;
    if (/qr|qrcode/.test(meta)) score += 58;
    if (/scan|scanner/.test(meta)) score += 38;
    if (/kode|code/.test(meta)) score += 28;
    if (/serial|nomor|number/.test(meta)) score += 12;
    if (/search|cari|username|password|email|login/.test(meta)) score -= 80;
    try {
      if (el.disabled || el.type === 'hidden') score -= 60;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 12;
    } catch (_) {}
    return score;
  }

  function collectDeepInputs(root, out, visited) {
    if (!root || visited.length > 1200) return;
    try {
      var fields = root.querySelectorAll('input,textarea,[contenteditable="true"]');
      for (var i = 0; i < fields.length && out.length < 100; i++) {
        if (out.indexOf(fields[i]) < 0) out.push(fields[i]);
      }
      var all = root.querySelectorAll('*');
      for (var j = 0; j < all.length && visited.length < 1200; j++) {
        var node = all[j];
        visited.push(node);
        if (node.shadowRoot) collectDeepInputs(node.shadowRoot, out, visited);
      }
    } catch (_) {}
  }



  function targetMeta(el) {
    var parts = [];
    try {
      parts.push(el.id, el.name, el.type, el.placeholder, el.title);
      if (el.getAttribute) {
        parts.push(el.getAttribute('aria-label'), el.getAttribute('data-testid'),
          el.getAttribute('data-name'), el.getAttribute('data-field'),
          el.getAttribute('autocomplete'));
      }
      var doc = el.ownerDocument || document;
      if (el.id && doc.querySelector) {
        try {
          var explicit = doc.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
          if (explicit) parts.push(explicit.innerText || explicit.textContent);
        } catch (_) {}
      }
      var label = el.closest && el.closest('label');
      if (label) parts.push(label.innerText || label.textContent);
      var parent = el.parentElement;
      for (var i = 0; parent && i < 2; i++, parent = parent.parentElement) {
        if (parent === doc.body || parent === doc.documentElement) break;
        var nearbyText = String(parent.innerText || parent.textContent || '').replace(/\s+/g, ' ').trim();
        var nearbyFields = 0;
        try { nearbyFields = parent.querySelectorAll('input,textarea,[contenteditable="true"]').length; } catch (_) {}
        if (nearbyText && nearbyText.length <= 260 && nearbyFields <= 1) parts.push(nearbyText);
      }
    } catch (_) {}
    return parts.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function describeTarget(el) {
    var meta = targetMeta(el);
    if (/\bhu\b.*\bcarton\b|\bcarton\b.*\bhu\b/.test(meta)) return 'HU Carton';
    if (/\bqr\b.*\bmaterial\b|\bmaterial\b.*\bqr\b/.test(meta)) return 'QR Material';
    if (/\bmaterial\b/.test(meta)) return 'QR Material';
    if (/\bhu\b/.test(meta)) return 'HU';
    if (/\bqr\b|qrcode/.test(meta)) return 'QR';
    if (/barcode/.test(meta)) return 'Barcode';
    if (/scan|scanner/.test(meta)) return 'Kolom Scan';
    var fallback = '';
    try {
      fallback = String(el.placeholder || el.getAttribute('aria-label') || el.name || el.id || 'Kolom Scan').trim();
    } catch (_) { fallback = 'Kolom Scan'; }
    if (fallback.length > 28) fallback = fallback.slice(0, 28) + '…';
    return fallback || 'Kolom Scan';
  }

  function isVisibleTarget(el) {
    try {
      if (!el || el.disabled || String(el.type || '').toLowerCase() === 'hidden') return false;
      var doc = el.ownerDocument || document;
      var view = doc.defaultView || w;
      var style = view.getComputedStyle ? view.getComputedStyle(el) : null;
      if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
      var rect = el.getBoundingClientRect();
      return rect.width > 20 && rect.height > 12;
    } catch (_) { return false; }
  }

  function isScanTarget(el) {
    if (!el || el.nodeType !== 1) return false;
    var tag = String(el.tagName || '').toLowerCase();
    if (tag !== 'input' && tag !== 'textarea' && !el.isContentEditable) return false;
    var type = String(el.type || '').toLowerCase();
    if (/password|email|search|date|time|number|checkbox|radio|file|submit|button/.test(type)) return false;
    return isVisibleTarget(el) && fieldScore(el) >= 28;
  }

  function collectScanTargets() {
    var nodes = [];
    collectDeepInputs(document, nodes, []);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { collectDeepInputs(w.frames[f].document, nodes, []); } catch (_) {}
      }
    } catch (_) {}
    var result = [];
    for (var i = 0; i < Math.min(nodes.length, 300); i++) {
      if (isScanTarget(nodes[i]) && result.indexOf(nodes[i]) < 0) result.push(nodes[i]);
    }
    return result;
  }

  function ensureTargetStyle(doc) {
    try {
      if (!doc || !doc.head || doc.getElementById('ice-scan-target-style-v6')) return;
      var style = doc.createElement('style');
      style.id = 'ice-scan-target-style-v6';
      style.textContent = '.ice-scan-target-active-v6{outline:3px solid #22c55e!important;outline-offset:2px!important;box-shadow:0 0 0 4px rgba(34,197,94,.20)!important;}';
      doc.head.appendChild(style);
    } catch (_) {}
  }

  function notifyTarget(force) {
    var state = scanTargets.length + '|' + (activeTarget ? activeTargetLabel : '') + '|' + (activeTarget ? '1' : '0');
    if (!force && state === lastTargetState) return;
    lastTargetState = state;
    androidCall('onTargetChanged', [activeTargetLabel || '', scanTargets.length, !!activeTarget]);
  }

  function removeTargetHighlight(el) {
    try { if (el && el.classList) el.classList.remove('ice-scan-target-active-v6'); } catch (_) {}
  }

  function setActiveTarget(el, automatic, silent) {
    if (!isScanTarget(el)) return false;
    var changed = activeTarget !== el || activeTargetAuto !== !!automatic;
    if (activeTarget && activeTarget !== el) removeTargetHighlight(activeTarget);
    activeTarget = el;
    activeTargetLabel = describeTarget(el);
    activeTargetAuto = !!automatic;
    ensureTargetStyle(el.ownerDocument || document);
    try { if (el.classList) el.classList.add('ice-scan-target-active-v6'); } catch (_) {}
    notifyTarget(changed);
    if (!silent && changed) {
      report((automatic ? 'Tujuan scan otomatis: ' : 'Tujuan scan: ') + activeTargetLabel + '.');
    }
    return true;
  }

  function clearActiveTarget(reason, silent) {
    var hadTarget = !!activeTarget;
    removeTargetHighlight(activeTarget);
    activeTarget = null;
    activeTargetLabel = '';
    activeTargetAuto = false;
    notifyTarget(hadTarget);
    if (!silent && reason === 'multiple') report('Sentuh kolom tujuan scan terlebih dahulu.');
    if (!silent && reason === 'navigation') report('Halaman berubah. Pilih kembali kolom tujuan scan.');
  }

  function refreshScanTargets(silent) {
    var next = collectScanTargets();
    scanTargets = next;

    if (activeTarget && next.indexOf(activeTarget) < 0) clearActiveTarget('removed', true);

    if (next.length === 1) {
      if (!activeTarget) setActiveTarget(next[0], true, !!silent);
    } else if (next.length > 1) {
      if (activeTarget && activeTargetAuto) clearActiveTarget('multiple', !!silent);
      if (!activeTarget) {
        notifyTarget(false);
        if (!silent) report('Sentuh kolom tujuan scan terlebih dahulu.');
      }
    } else {
      if (activeTarget) clearActiveTarget('removed', true);
      notifyTarget(false);
    }
    return next.length;
  }

  function eventPath(event) {
    try {
      if (event.composedPath) return event.composedPath();
    } catch (_) {}
    var out = [];
    var node = event.target;
    while (node) { out.push(node); node = node.parentNode || node.host; }
    return out;
  }

  function selectTargetFromEvent(event) {
    try { if (event && event.isTrusted === false) return; } catch (_) {}
    refreshScanTargets(true);
    if (!scanTargets.length) return;
    var path = eventPath(event || {});
    var selected = null;
    for (var i = 0; i < path.length && !selected; i++) {
      var node = path[i];
      if (scanTargets.indexOf(node) >= 0) selected = node;
      else if (node && String(node.tagName || '').toLowerCase() === 'label' && node.control && scanTargets.indexOf(node.control) >= 0) selected = node.control;
    }
    if (!selected && event && event.target && event.target.querySelector) {
      try {
        var child = event.target.querySelector('input,textarea,[contenteditable="true"]');
        if (scanTargets.indexOf(child) >= 0) selected = child;
      } catch (_) {}
    }
    if (selected) setActiveTarget(selected, false, false);
  }

  function installTargetListenersInDocument(doc) {
    try {
      if (!doc || doc.__iceTargetListenersV6) return;
      doc.__iceTargetListenersV6 = true;
      ensureTargetStyle(doc);
      var events = ['pointerdown', 'touchstart', 'mousedown', 'focusin', 'click'];
      for (var i = 0; i < events.length; i++) doc.addEventListener(events[i], selectTargetFromEvent, true);
    } catch (_) {}
  }

  function installTargetListenersDeep() {
    installTargetListenersInDocument(document);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { installTargetListenersInDocument(w.frames[f].document); } catch (_) {}
      }
    } catch (_) {}
  }

  function setNativeValue(el, text) {
    var tag = String(el.tagName || '').toLowerCase();
    var view = (el.ownerDocument && el.ownerDocument.defaultView) || w;
    if (tag === 'input') {
      var inputSetter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value');
      if (inputSetter && inputSetter.set) inputSetter.set.call(el, text); else el.value = text;
    } else if (tag === 'textarea') {
      var areaSetter = Object.getOwnPropertyDescriptor(view.HTMLTextAreaElement.prototype, 'value');
      if (areaSetter && areaSetter.set) areaSetter.set.call(el, text); else el.value = text;
    } else if (el.isContentEditable) {
      el.textContent = text;
    }
  }

  function dispatchInputAndEnter(el, text, pressEnter) {
    var view = (el.ownerDocument && el.ownerDocument.defaultView) || w;
    var EventCtor = view.Event || w.Event;
    var InputEventCtor = view.InputEvent || w.InputEvent;
    var KeyboardEventCtor = view.KeyboardEvent || w.KeyboardEvent;
    try { el.focus(); } catch (_) {}
    try { if (InputEventCtor) el.dispatchEvent(new InputEventCtor('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: text })); } catch (_) {}
    try { if (InputEventCtor) el.dispatchEvent(new InputEventCtor('input', { bubbles: true, inputType: 'insertText', data: text })); else throw new Error('no InputEvent'); }
    catch (_) { try { el.dispatchEvent(new EventCtor('input', { bubbles: true })); } catch (_) {} }
    try { el.dispatchEvent(new EventCtor('change', { bubbles: true })); } catch (_) {}
    if (pressEnter !== false) {
      var init = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keydown', init)); } catch (_) {}
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keypress', init)); } catch (_) {}
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keyup', init)); } catch (_) {}
      try {
        var form = el.closest && el.closest('form');
        if (form) {
          if (typeof form.requestSubmit === 'function') form.requestSubmit();
          else form.dispatchEvent(new EventCtor('submit', { bubbles: true, cancelable: true }));
        }
      } catch (_) {}
    }
  }

  function fillSpecificInput(el, text, pressEnter) {
    if (!el || !isScanTarget(el)) return false;
    try {
      el.disabled = false;
      el.readOnly = false;
      el.removeAttribute('disabled');
      el.removeAttribute('readonly');
      setNativeValue(el, text);
      dispatchInputAndEnter(el, text, pressEnter);
      return true;
    } catch (_) { return false; }
  }

  function fillBestInput(text, pressEnter) {
    var nodes = [];
    collectDeepInputs(document, nodes, []);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { collectDeepInputs(w.frames[f].document, nodes, []); } catch (_) {}
      }
    } catch (_) {}
    var best = null;
    var bestScore = 17;
    var limit = Math.min(nodes.length, 300);
    for (var i = 0; i < limit; i++) {
      var score = fieldScore(nodes[i]);
      if (score > bestScore) { best = nodes[i]; bestScore = score; }
    }
    if (!best) return false;
    return fillSpecificInput(best, text, pressEnter);
  }

  function dispatchFallbackEvents(text) {
    var detail = decodedResult(text);
    var names = ['scanSuccess', 'qr-scanned', 'barcode-scanned'];
    var count = 0;
    for (var i = 0; i < names.length; i++) {
      try {
        document.dispatchEvent(new CustomEvent(names[i], { bubbles: true, detail: detail }));
        count++;
      } catch (_) {}
    }
    return count;
  }

  function processOne(item) {
    patch();
    refreshScanTargets(true);

    var captured = { called: 0, source: '', errors: 0 };
    var named = '';
    var input = false;
    var events = 0;
    var reason = '';
    var selectedTarget = activeTarget;
    var selectedLabel = activeTargetLabel;
    var targetCount = scanTargets.length;

    if (targetCount > 1 && !selectedTarget) {
      reason = 'target_required';
    } else if (selectedTarget) {
      input = fillSpecificInput(selectedTarget, item.text, item.pressEnter);
      if (!input && targetCount > 1) reason = 'target_fill_failed';
    }

    if (!reason && !input) {
      captured = invokeLatestCaptured(item.text);
      if (!captured.called) named = invokeOneNamed(item.text);
      if (!captured.called && !named) input = fillBestInput(item.text, item.pressEnter);
      if (!captured.called && !named && !input) events = dispatchFallbackEvents(item.text);
    }

    var ok = !!(captured.called || named || input);
    if (!ok && !reason) reason = 'scanner_not_ready';
    var result = {
      ok: ok,
      callbacks: captured.called,
      source: captured.source,
      named: named,
      inputs: input ? 1 : 0,
      events: events,
      errors: captured.errors,
      captured: callbacks.length,
      queued: queue.length,
      sources: callbackSources(),
      requestId: item.requestId || '',
      text: item.text,
      target: selectedLabel || '',
      targetCount: targetCount,
      targetSelected: !!selectedTarget,
      reason: ok ? '' : reason
    };

    if (reason === 'target_required') report('Sentuh kolom tujuan scan terlebih dahulu.');
    else if (reason === 'target_fill_failed') report('Kolom tujuan tidak dapat diisi. Sentuh ulang kolom tujuan.');
    else if (input && selectedLabel) report('Kode dikirim ke ' + selectedLabel + '.');
    else if (captured.called) report('Kode terkirim ke scanner aktif.');
    else if (named) report('Kode terkirim lewat ' + named + '.');
    else if (input) report('Kode diisi ke kolom scan.');
    else report('Scanner belum siap. Buka ulang menu Scan QR.');

    androidCall('onSendReport', [JSON.stringify(result)]);
  }

  function processQueue() {
    if (processing || destroyed) return;
    processing = true;

    function next() {
      if (destroyed || !queue.length) {
        processing = false;
        return;
      }
      var item = queue.shift();
      try { processOne(item); } catch (_) {}
      w.setTimeout(next, SEND_GAP_MS);
    }

    next();
  }

  function send(text, requestId, pressEnter) {
    text = String(text == null ? '' : text).trim();
    if (!text) {
      report('Kode masih kosong.');
      return JSON.stringify({ ok: false, reason: 'empty' });
    }

    patch();
    refreshScanTargets(false);
    if (scanTargets.length > 1 && !activeTarget) {
      report('Sentuh kolom tujuan scan terlebih dahulu.');
      return JSON.stringify({ ok: false, reason: 'target_required', targetCount: scanTargets.length });
    }

    var stamp = now();
    if (recent[text] && stamp - recent[text] < DUPLICATE_MS) {
      report('Kode sama baru saja diproses.');
      return JSON.stringify({ ok: false, reason: 'duplicate' });
    }
    recent[text] = stamp;
    cleanupRecent();

    if (queue.length >= MAX_QUEUE) {
      report('Antrean scan penuh. Tunggu sebentar.');
      return JSON.stringify({ ok: false, reason: 'queue_full', queued: queue.length });
    }

    queue.push({ text: text, addedAt: stamp, requestId: String(requestId == null ? '' : requestId), pressEnter: pressEnter !== false });
    processQueue();
    return JSON.stringify({ ok: true, queued: queue.length, processing: processing });
  }

  function status() {
    patch();
    return JSON.stringify({
      version: VERSION,
      callbacks: callbacks.length,
      sources: callbackSources(),
      queued: queue.length,
      processing: processing,
      html5Qrcode: typeof w.Html5Qrcode === 'function',
      html5Scanner: typeof w.Html5QrcodeScanner === 'function',
      prewarmDone: prewarmDone,
      prewarmAttempts: prewarmAttempts,
      suppressNextScannerStart: suppressNextScannerStart,
      targetCount: scanTargets.length,
      targetSelected: !!activeTarget,
      target: activeTargetLabel || ''
    });
  }

  function destroy() {
    destroyed = true;
    clearPatchTimers();
    queue = [];
    callbacks = [];
    scanTargets = [];
    clearActiveTarget('destroy', true);
    try { if (observer) observer.disconnect(); } catch (_) {}
    observer = null;
    reportCount(true);
  }

  w.__LPWScannerBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    status: status,
    report: report,
    destroy: destroy,
    prewarm: prewarmScanner,
    getCallbackCount: function () { return callbacks.length; },
    getTarget: function () { return { label: activeTargetLabel || '', count: scanTargets.length, selected: !!activeTarget }; },
    clearTarget: function () { clearActiveTarget('manual', true); refreshScanTargets(false); }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
    w.addEventListener('pagehide', function () {
      clearPatchTimers();
      queue = [];
      clearActiveTarget('navigation', true);
    }, false);
  } catch (_) {}

  patch();
  installObserver();
  schedulePatch();
  schedulePrewarm();
  report('Tools siap. Jika ada banyak kolom scan, sentuh kolom tujuan terlebih dahulu.');
})();
