// ==UserScript==
// @name         ICE Inject v2.7.3 Target Ready (Anti-Freeze)
// @namespace    local.ice.inject
// @version      2.7.3
// @description  Input scanner langsung aktif; jika banyak kolom, sentuh kolom tujuan terlebih dahulu.
// @match        http://*/*
// @match        https://*/*
// @allFrames    true
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @inject-into  page
// ==/UserScript==

(() => {
  'use strict';

  const page = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
  const doc = page.document;
  const isTop = page.top === page.self;
  let statusEl;
  const CHANNEL = 'ice-inject-v271-stable';
  const INSTANCE_KEY = '__ICE_V273_TARGET_READY_INSTANCE__';
  if (page[INSTANCE_KEY]) return;
  page[INSTANCE_KEY] = { version: '2.7.3', startedAt: Date.now(), directReady: true, targetReady: true };

  const seenMessageIds = new Map();
  let messageSequence = 0;

  function nextMessageId() {
    messageSequence = (messageSequence + 1) % 1000000;
    return Date.now().toString(36) + '-' + messageSequence.toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  }

  function wasSeen(id) {
    if (!id) return false;
    const now = Date.now();
    const last = seenMessageIds.get(id);
    if (last) return true;
    seenMessageIds.set(id, now);
    if (seenMessageIds.size > 160) {
      for (const [key, time] of seenMessageIds) {
        if (now - time > 30000 || seenMessageIds.size > 120) seenMessageIds.delete(key);
      }
    }
    return false;
  }
  const STORAGE = {
    manualHistory: 'ice-v27-manual-history',
    galleryEnabled: 'ice-v27-gallery-enabled',
    galleryImage: 'ice-v27-gallery-image',
    galleryName: 'ice-v27-gallery-name',
    compact: 'ice-v27-compact'
  };

  const gmGet = (key, fallback) => {
    try {
      return typeof GM_getValue === 'function' ? GM_getValue(key, fallback) : fallback;
    } catch (_) {
      return fallback;
    }
  };

  const gmSet = (key, value) => {
    try {
      if (typeof GM_setValue === 'function') GM_setValue(key, value);
    } catch (_) {}
  };

  const galleryState = {
    enabled: Boolean(gmGet(STORAGE.galleryEnabled, false)),
    imageDataUrl: String(gmGet(STORAGE.galleryImage, '')),
    imageName: String(gmGet(STORAGE.galleryName, '')),
    sourceImage: null,
    virtualCanvas: null,
    virtualCtx: null,
    masterStream: null,
    drawTimer: 0,
    observer: null,
    mediaPatched: false,
    srcPatched: false,
    mediaReady: null,
    mediaResolve: null,
    mediaReject: null,
    originalGetUserMedia: null,
    cachedSrcObjectDescriptor: null
  };

  galleryState.mediaReady = new Promise((resolve, reject) => {
    galleryState.mediaResolve = resolve;
    galleryState.mediaReject = reject;
  });

  function sendTop(type, extra = {}) {
    try {
      page.top.postMessage({
        channel: CHANNEL,
        id: nextMessageId(),
        type,
        href: location.href,
        isTop,
        ...extra
      }, '*');
    } catch (_) {}
  }

  function forwardToFrames(message) {
    try {
      for (let i = 0; i < page.frames.length; i++) {
        try {
          page.frames[i].postMessage(message, '*');
        } catch (_) {}
      }
    } catch (_) {}
  }

  function allDeepElements(root = doc) {
    const out = [];
    const visited = new Set();
    const MAX_SCANNED_NODES = 1200;
    let scanned = 0;

    function walk(node) {
      if (!node || visited.has(node) || scanned >= MAX_SCANNED_NODES) return;
      visited.add(node);

      try {
        for (const target of node.querySelectorAll('input,textarea,[contenteditable="true"]')) {
          out.push(target);
          if (out.length >= 80) break;
        }
      } catch (_) {}

      let items = [];
      try { items = Array.from(node.querySelectorAll('*')); } catch (_) { return; }
      for (const item of items) {
        scanned++;
        if (item.shadowRoot) walk(item.shadowRoot);
        if (scanned >= MAX_SCANNED_NODES) break;
      }
    }

    walk(root);
    return Array.from(new Set(out));
  }

  function fieldMeta(element) {
    const parts = [
      element.id, element.name, element.type, element.placeholder,
      element.getAttribute?.('aria-label'), element.getAttribute?.('data-testid'),
      element.getAttribute?.('data-name'), element.getAttribute?.('title'),
      typeof element.className === 'string' ? element.className : ''
    ];
    try {
      if (element.id) {
        const label = element.ownerDocument?.querySelector?.(`label[for="${CSS.escape(element.id)}"]`);
        if (label) parts.push(label.innerText || label.textContent);
      }
      const closestLabel = element.closest?.('label');
      if (closestLabel) parts.push(closestLabel.innerText || closestLabel.textContent);
      let parent = element.parentElement;
      for (let i = 0; parent && i < 2; i++, parent = parent.parentElement) {
        const owner = element.ownerDocument;
        if (parent === owner?.body || parent === owner?.documentElement) break;
        const text = String(parent.innerText || parent.textContent || '').replace(/\s+/g, ' ').trim();
        const fields = parent.querySelectorAll?.('input,textarea,[contenteditable="true"]').length || 0;
        if (text && text.length <= 260 && fields <= 1) parts.push(text);
      }
    } catch (_) {}
    return parts.filter(Boolean).join(' ').toLowerCase();
  }

  function scoreField(element) {
    const text = fieldMeta(element);
    let score = 0;

    if (/input barcode hu here/.test(text)) score += 140;
    if (/barcode/.test(text)) score += 60;
    if (/\bhu\b/.test(text)) score += 72;
    if (/carton|karton/.test(text)) score += 48;
    if (/material/.test(text)) score += 68;
    if (/qr|qrcode/.test(text)) score += 50;
    if (/scan|scanner/.test(text)) score += 28;
    if (/kode|code/.test(text)) score += 22;
    if (/serial|nomor|number/.test(text)) score += 10;
    if (/search|cari|username|password|email|login/.test(text)) score -= 90;
    if (element.matches?.('input,textarea,[contenteditable="true"]')) score += 12;
    if (element.type === 'hidden') score -= 40;
    if (element.disabled) score -= 10;

    return score;
  }

  function findTargets() {
    return allDeepElements(doc)
      .filter((element) => element.matches?.('input,textarea,[contenteditable="true"]'))
      .map((element) => ({ element, score: scoreField(element) }))
      .filter((item) => item.score >= 18)
      .sort((a, b) => b.score - a.score);
  }



  let activeScanTarget = null;
  let activeScanTargetAuto = false;
  let activeScanTargetLabel = '';
  let lastTargetUrl = String(location.href);

  function describeScanTarget(element) {
    const meta = fieldMeta(element);
    if (/\bhu\b.*\bcarton\b|\bcarton\b.*\bhu\b/.test(meta)) return 'HU Carton';
    if (/\bqr\b.*\bmaterial\b|\bmaterial\b.*\bqr\b|\bmaterial\b/.test(meta)) return 'QR Material';
    if (/\bhu\b/.test(meta)) return 'HU';
    if (/\bqr\b|qrcode/.test(meta)) return 'QR';
    if (/barcode/.test(meta)) return 'Barcode';
    return 'Kolom Scan';
  }

  function clearScanTarget() {
    try { activeScanTarget?.classList?.remove('ice-tm-target-active-v273'); } catch (_) {}
    activeScanTarget = null;
    activeScanTargetAuto = false;
    activeScanTargetLabel = '';
  }

  function setScanTarget(element, automatic = false) {
    if (!element) return false;
    if (activeScanTarget && activeScanTarget !== element) {
      try { activeScanTarget.classList.remove('ice-tm-target-active-v273'); } catch (_) {}
    }
    activeScanTarget = element;
    activeScanTargetAuto = Boolean(automatic);
    activeScanTargetLabel = describeScanTarget(element);
    try { element.classList.add('ice-tm-target-active-v273'); } catch (_) {}
    if (isTop && typeof setStatus === 'function') {
      setStatus(`${automatic ? 'Tujuan otomatis' : 'Tujuan scan'}: ${activeScanTargetLabel}`);
    }
    return true;
  }

  function refreshScanTarget() {
    const targets = findTargets();
    const elements = targets.map((item) => item.element);
    if (activeScanTarget && !elements.includes(activeScanTarget)) clearScanTarget();
    if (targets.length === 1 && !activeScanTarget) setScanTarget(targets[0].element, true);
    if (targets.length > 1 && activeScanTargetAuto) clearScanTarget();
    return targets;
  }

  function installTargetSelection() {
    try {
      if (!doc.getElementById('ice-tm-target-style-v273')) {
        const style = doc.createElement('style');
        style.id = 'ice-tm-target-style-v273';
        style.textContent = '.ice-tm-target-active-v273{outline:3px solid #22c55e!important;outline-offset:2px!important;box-shadow:0 0 0 4px rgba(34,197,94,.20)!important;}';
        (doc.head || doc.documentElement).appendChild(style);
      }
    } catch (_) {}
    const handler = (event) => {
      try { if (event.isTrusted === false) return; } catch (_) {}
      const targets = refreshScanTarget();
      const path = event.composedPath?.() || [event.target];
      for (const node of path) {
        const found = targets.find((item) => item.element === node);
        if (found) { setScanTarget(found.element, false); return; }
        if (String(node?.tagName || '').toLowerCase() === 'label' && node.control) {
          const byLabel = targets.find((item) => item.element === node.control);
          if (byLabel) { setScanTarget(byLabel.element, false); return; }
        }
      }
    };
    for (const name of ['pointerdown', 'touchstart', 'mousedown', 'focusin', 'click']) {
      doc.addEventListener(name, handler, true);
    }
    page.setInterval(() => {
      const current = String(location.href);
      if (current !== lastTargetUrl) {
        lastTargetUrl = current;
        clearScanTarget();
      }
      refreshScanTarget();
    }, 700);
    refreshScanTarget();
  }

  function setNativeValue(element, value) {
    const tag = String(element.tagName || '').toLowerCase();

    if (tag === 'input') {
      const setter = Object.getOwnPropertyDescriptor(page.HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(element, value);
      else element.value = value;
      return;
    }

    if (tag === 'textarea') {
      const setter = Object.getOwnPropertyDescriptor(page.HTMLTextAreaElement.prototype, 'value')?.set;
      if (setter) setter.call(element, value);
      else element.value = value;
      return;
    }

    if (element.isContentEditable) {
      element.textContent = value;
    }
  }

  function dispatchValueEvents(element, value, pressEnter) {
    try { element.focus(); } catch (_) {}

    try {
      element.dispatchEvent(new InputEvent('beforeinput', {
        bubbles: true,
        cancelable: true,
        inputType: 'insertText',
        data: value
      }));
    } catch (_) {}

    try {
      element.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertText',
        data: value
      }));
    } catch (_) {
      element.dispatchEvent(new Event('input', { bubbles: true }));
    }

    element.dispatchEvent(new Event('change', { bubbles: true }));

    if (pressEnter) {
      const init = {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      };
      try { element.dispatchEvent(new KeyboardEvent('keydown', init)); } catch (_) {}
      try { element.dispatchEvent(new KeyboardEvent('keypress', init)); } catch (_) {}
      try { element.dispatchEvent(new KeyboardEvent('keyup', init)); } catch (_) {}

      const form = element.closest?.('form');
      if (form) {
        try {
          if (typeof form.requestSubmit === 'function') form.requestSubmit();
          else form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        } catch (_) {}
      }
    }

    try { element.blur(); } catch (_) {}
  }

  function injectValue(value, pressEnter) {
    const targets = refreshScanTarget();
    let changed = 0;
    const details = [];
    let reason = '';

    if (targets.length > 1 && !activeScanTarget) {
      reason = 'target_required';
    } else {
      const selected = activeScanTarget || targets[0]?.element || null;
      const selectedItem = targets.find((item) => item.element === selected);
      if (selected && selectedItem) {
        try {
          selected.disabled = false;
          selected.readOnly = false;
          selected.removeAttribute('disabled');
          selected.removeAttribute('readonly');
          setNativeValue(selected, value);
          dispatchValueEvents(selected, value, pressEnter);
          changed++;
          details.push({
            tag: selected.tagName, id: selected.id || '', name: selected.name || '',
            placeholder: selected.placeholder || '', score: selectedItem.score,
            target: activeScanTargetLabel || describeScanTarget(selected)
          });
        } catch (_) { reason = 'target_fill_failed'; }
      }
    }

    sendTop('inject-report', {
      changed, total: targets.length, value, pressEnter, details, reason,
      target: activeScanTargetLabel || ''
    });
  }

  const injectQueue = [];
  let queueRunning = false;
  const recentInjected = new Map();

  function queueInjection(value, pressEnter) {
    const clean = String(value || '').trim();
    if (!clean) return;
    const now = Date.now();
    const last = recentInjected.get(clean) || 0;
    if (now - last < 900) return;
    recentInjected.set(clean, now);
    if (injectQueue.length >= 24) injectQueue.shift();
    injectQueue.push({ value: clean, pressEnter: Boolean(pressEnter) });
    if (queueRunning) return;
    queueRunning = true;
    const next = () => {
      const item = injectQueue.shift();
      if (!item) { queueRunning = false; return; }
      injectValue(item.value, item.pressEnter);
      page.setTimeout(next, 130);
    };
    next();
  }

  page.addEventListener('message', (event) => {
    const message = event.data;
    if (!message || message.channel !== CHANNEL) return;
    if (wasSeen(String(message.id || ''))) return;

    if (message.type === 'inject' && message.value) {
      if (isTop && page.__LPWScannerBridge && typeof page.__LPWScannerBridge.send === 'function') {
        let result = { ok: false, reason: 'bridge_error' };
        try {
          const raw = page.__LPWScannerBridge.send(String(message.value), `tm:${message.id || ''}`, Boolean(message.pressEnter));
          result = typeof raw === 'string' ? JSON.parse(raw) : raw;
        } catch (_) {}
        sendTop('inject-report', {
          changed: result?.ok ? 1 : 0,
          total: Number(result?.targetCount || page.__LPWScannerBridge.getTarget?.().count || 0),
          value: String(message.value),
          pressEnter: Boolean(message.pressEnter),
          reason: result?.reason || '',
          target: result?.target || page.__LPWScannerBridge.getTarget?.().label || '',
          bridge: true
        });
        return;
      }
      queueInjection(String(message.value), Boolean(message.pressEnter));
      if ((message.depth || 0) < 3) {
        forwardToFrames({ ...message, depth: (message.depth || 0) + 1 });
      }
    }

    if (message.type === 'probe') {
      const targets = findTargets();
      sendTop('probe-report', {
        count: targets.length,
        targets: targets.slice(0, 5).map(({ element, score }) => ({
          tag: element.tagName,
          id: element.id || '',
          name: element.name || '',
          placeholder: element.placeholder || '',
          score
        }))
      });

      if ((message.depth || 0) < 3) {
        forwardToFrames({ ...message, depth: (message.depth || 0) + 1 });
      }
    }
  });

  function cloneVirtualStream() {
    if (!galleryState.masterStream) return null;
    const tracks = galleryState.masterStream.getTracks().map((track) => {
      try {
        const cloned = track.clone();
        try { cloned.contentHint = 'detail'; } catch (_) {}
        return cloned;
      } catch (_) {
        return track;
      }
    });
    return new page.MediaStream(tracks);
  }

  function reportGallery(text) {
    sendTop('gallery-status', { text });
  }

  function getSrcObjectDescriptor() {
    if (galleryState.cachedSrcObjectDescriptor) return galleryState.cachedSrcObjectDescriptor;
    let proto = page.HTMLMediaElement && page.HTMLMediaElement.prototype;
    while (proto) {
      const descriptor = Object.getOwnPropertyDescriptor(proto, 'srcObject');
      if (descriptor) {
        galleryState.cachedSrcObjectDescriptor = descriptor;
        return descriptor;
      }
      proto = Object.getPrototypeOf(proto);
    }
    return null;
  }

  function ensureVirtualCanvas() {
    if (galleryState.virtualCanvas) {
      if (!galleryState.masterStream && typeof galleryState.virtualCanvas.captureStream === 'function') {
        galleryState.masterStream = galleryState.virtualCanvas.captureStream(3);
        const existingTrack = galleryState.masterStream.getVideoTracks()[0];
        if (existingTrack) { try { existingTrack.contentHint = 'detail'; } catch (_) {} }
      }
      return;
    }
    galleryState.virtualCanvas = doc.createElement('canvas');
    galleryState.virtualCanvas.width = 768;
    galleryState.virtualCanvas.height = 768;
    galleryState.virtualCanvas.id = 'ice-v27-virtual-camera';
    Object.assign(galleryState.virtualCanvas.style, {
      position: 'fixed',
      right: '0',
      top: '0',
      width: '2px',
      height: '2px',
      opacity: '0.001',
      pointerEvents: 'none',
      zIndex: '-2147483647'
    });

    galleryState.virtualCtx = galleryState.virtualCanvas.getContext('2d', {
      alpha: false,
      desynchronized: false
    });

    if (!galleryState.virtualCtx || typeof galleryState.virtualCanvas.captureStream !== 'function') {
      throw new Error('Browser tidak mendukung kamera virtual.');
    }

    galleryState.virtualCtx.fillStyle = '#ffffff';
    galleryState.virtualCtx.fillRect(0, 0, 768, 768);

    const attach = () => {
      if (!galleryState.virtualCanvas.isConnected && doc.documentElement) {
        doc.documentElement.appendChild(galleryState.virtualCanvas);
      }
    };
    attach();
    doc.addEventListener('DOMContentLoaded', attach, { once: true });

    galleryState.masterStream = galleryState.virtualCanvas.captureStream(3);
    const track = galleryState.masterStream.getVideoTracks()[0];
    if (track) {
      try { track.contentHint = 'detail'; } catch (_) {}
    }
  }

  function drawVirtualFrame() {
    if (!galleryState.virtualCanvas || !galleryState.virtualCtx || !galleryState.sourceImage) return;
    const size = galleryState.virtualCanvas.width;
    const iw = galleryState.sourceImage.naturalWidth || galleryState.sourceImage.width || 1;
    const ih = galleryState.sourceImage.naturalHeight || galleryState.sourceImage.height || 1;
    const safe = size * 0.9;
    const fit = Math.min(safe / iw, safe / ih);

    galleryState.virtualCtx.fillStyle = '#ffffff';
    galleryState.virtualCtx.fillRect(0, 0, size, size);
    galleryState.virtualCtx.imageSmoothingEnabled = true;
    galleryState.virtualCtx.imageSmoothingQuality = 'high';
    galleryState.virtualCtx.drawImage(
      galleryState.sourceImage,
      (size - iw * fit) / 2,
      (size - ih * fit) / 2,
      iw * fit,
      ih * fit
    );

    const pulse = Math.floor(Date.now() / 120) % 2;
    galleryState.virtualCtx.fillStyle = pulse ? '#ffffff' : '#fefefe';
    galleryState.virtualCtx.fillRect(size - 2, size - 2, 1, 1);
  }

  function startDrawing() {
    if (galleryState.drawTimer) page.clearTimeout(galleryState.drawTimer);
    const tick = () => {
      galleryState.drawTimer = 0;
      if (!galleryState.enabled || !galleryState.sourceImage) return;
      if (!doc.hidden) drawVirtualFrame();
      galleryState.drawTimer = page.setTimeout(tick, doc.hidden ? 1400 : 420);
    };
    tick();
  }

  function stopGalleryRuntime() {
    if (galleryState.drawTimer) page.clearTimeout(galleryState.drawTimer);
    galleryState.drawTimer = 0;
    try {
      if (galleryState.masterStream) {
        for (const track of galleryState.masterStream.getTracks()) track.stop();
      }
    } catch (_) {}
    galleryState.masterStream = null;
  }

  async function loadGalleryImage() {
    if (!galleryState.enabled || !galleryState.imageDataUrl) {
      galleryState.mediaResolve(false);
      return false;
    }

    try {
      const img = new page.Image();
      img.decoding = 'async';
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () => reject(new Error('Gambar galeri gagal dibuka.'));
        img.src = galleryState.imageDataUrl;
      });
      galleryState.sourceImage = img;
      ensureVirtualCanvas();
      startDrawing();
      galleryState.mediaResolve(true);
      reportGallery('Gambar galeri siap dipakai scanner.');
      replaceAllVideosSoon();
      installMutationWatcher();
      return true;
    } catch (error) {
      galleryState.mediaReject(error);
      reportGallery(`Gagal menyiapkan gambar: ${error.message || error}`);
      return false;
    }
  }

  async function virtualGetUserMedia(constraints = {}) {
    const wantsVideo = Boolean(constraints && constraints.video);
    if (!galleryState.enabled || !galleryState.imageDataUrl || !wantsVideo) {
      if (!galleryState.originalGetUserMedia) {
        throw new Error('getUserMedia tidak tersedia.');
      }
      return galleryState.originalGetUserMedia(constraints);
    }

    if (!galleryState.masterStream) {
      await galleryState.mediaReady;
    }
    if (!galleryState.masterStream) {
      throw new Error('Aliran kamera virtual belum siap.');
    }
    return cloneVirtualStream();
  }

  function patchGetUserMedia() {
    const mediaDevices = page.navigator && page.navigator.mediaDevices;
    if (!mediaDevices || galleryState.mediaPatched) return;

    galleryState.originalGetUserMedia = typeof mediaDevices.getUserMedia === 'function'
      ? mediaDevices.getUserMedia.bind(mediaDevices)
      : null;

    if (!galleryState.originalGetUserMedia) return;

    let done = false;
    try {
      Object.defineProperty(mediaDevices, 'getUserMedia', {
        configurable: true,
        enumerable: true,
        writable: true,
        value: virtualGetUserMedia
      });
      done = true;
    } catch (_) {}

    if (!done) {
      try {
        Object.defineProperty(Object.getPrototypeOf(mediaDevices), 'getUserMedia', {
          configurable: true,
          writable: true,
          value: virtualGetUserMedia
        });
        done = true;
      } catch (_) {}
    }

    try {
      const legacy = (constraints, success, failure) => {
        virtualGetUserMedia(constraints).then(success, failure);
      };
      page.navigator.getUserMedia = legacy;
      page.navigator.webkitGetUserMedia = legacy;
      page.navigator.mozGetUserMedia = legacy;
    } catch (_) {}

    galleryState.mediaPatched = true;
    reportGallery(done ? 'Hook kamera aktif.' : 'Hook kamera terbatas.');
  }

  function setVirtualStreamOnVideo(video) {
    if (!galleryState.enabled || !galleryState.imageDataUrl || !galleryState.masterStream || !video) return false;
    try {
      const descriptor = getSrcObjectDescriptor();
      if (!descriptor || typeof descriptor.set !== 'function') return false;
      descriptor.set.call(video, cloneVirtualStream());
      video.muted = true;
      video.autoplay = true;
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.setAttribute('autoplay', '');
      Promise.resolve(video.play()).catch(() => {});
      return true;
    } catch (_) {
      return false;
    }
  }

  function patchSrcObjectSetter() {
    if (galleryState.srcPatched || !page.HTMLMediaElement) return;
    const descriptor = getSrcObjectDescriptor();
    if (!descriptor || typeof descriptor.set !== 'function') return;

    try {
      Object.defineProperty(page.HTMLMediaElement.prototype, 'srcObject', {
        configurable: descriptor.configurable !== false,
        enumerable: descriptor.enumerable,
        get: descriptor.get,
        set(value) {
          const isVideo = this instanceof page.HTMLVideoElement || String(this.tagName || '').toUpperCase() === 'VIDEO';
          if (galleryState.enabled && galleryState.imageDataUrl && isVideo) {
            if (galleryState.masterStream) {
              descriptor.set.call(this, cloneVirtualStream());
              Promise.resolve(this.play()).catch(() => {});
              return;
            }
            descriptor.set.call(this, value);
            galleryState.mediaReady.then(() => setVirtualStreamOnVideo(this)).catch(() => {});
            return;
          }
          descriptor.set.call(this, value);
        }
      });
      galleryState.srcPatched = true;
    } catch (_) {}
  }

  function replaceAllVideos() {
    if (!doc.querySelectorAll || !galleryState.masterStream) return 0;
    let count = 0;
    for (const video of doc.querySelectorAll('video')) {
      if (setVirtualStreamOnVideo(video)) count++;
    }
    return count;
  }

  function replaceAllVideosSoon() {
    [0, 400, 1200, 3000].forEach((delay) => {
      page.setTimeout(() => {
        try { replaceAllVideos(); } catch (_) {}
      }, delay);
    });
  }

  function installMutationWatcher() {
    if (!doc.documentElement || !page.MutationObserver || galleryState.observer) return;

    let scheduled = false;
    galleryState.observer = new page.MutationObserver((records) => {
      if (!galleryState.enabled || !galleryState.masterStream || scheduled || doc.hidden) return;
      let hasVideo = false;
      for (const record of records) {
        for (const node of record.addedNodes || []) {
          if (node && node.nodeType === 1 &&
              (String(node.tagName || '').toLowerCase() === 'video' || node.querySelector?.('video'))) {
            hasVideo = true;
            break;
          }
        }
        if (hasVideo) break;
      }
      if (!hasVideo) return;
      scheduled = true;
      page.setTimeout(() => {
        scheduled = false;
        replaceAllVideos();
      }, 300);
    });

    galleryState.observer.observe(doc.documentElement, { childList: true, subtree: true });
    page.setTimeout(() => {
      try { galleryState.observer.disconnect(); } catch (_) {}
      galleryState.observer = null;
    }, 12000);
  }

  function fileToPreparedDataUrl(file) {
    return new Promise((resolve, reject) => {
      const objectUrl = URL.createObjectURL(file);
      const img = new Image();

      img.onload = async () => {
        try {
          const sourceCanvas = doc.createElement('canvas');
          sourceCanvas.width = img.naturalWidth || img.width;
          sourceCanvas.height = img.naturalHeight || img.height;
          const sourceCtx = sourceCanvas.getContext('2d', { alpha: false, willReadFrequently: true });
          sourceCtx.fillStyle = '#ffffff';
          sourceCtx.fillRect(0, 0, sourceCanvas.width, sourceCanvas.height);
          sourceCtx.drawImage(img, 0, 0);

          let crop = { x: 0, y: 0, width: sourceCanvas.width, height: sourceCanvas.height };

          try {
            if ('BarcodeDetector' in page) {
              const formats = await page.BarcodeDetector.getSupportedFormats();
              if (formats.includes('qr_code')) {
                const detector = new page.BarcodeDetector({ formats: ['qr_code'] });
                const results = await detector.detect(sourceCanvas);
                if (results.length && results[0].boundingBox) {
                  const box = results[0].boundingBox;
                  const padding = Math.max(box.width, box.height) * 0.35;
                  crop.x = Math.max(0, box.x - padding);
                  crop.y = Math.max(0, box.y - padding);
                  crop.width = Math.min(sourceCanvas.width - crop.x, box.width + padding * 2);
                  crop.height = Math.min(sourceCanvas.height - crop.y, box.height + padding * 2);
                }
              }
            }
          } catch (_) {}

          const out = doc.createElement('canvas');
          out.width = 768;
          out.height = 768;
          const outCtx = out.getContext('2d', { alpha: false });
          outCtx.fillStyle = '#ffffff';
          outCtx.fillRect(0, 0, 768, 768);

          const fit = Math.min((768 * 0.88) / crop.width, (768 * 0.88) / crop.height);
          const dw = crop.width * fit;
          const dh = crop.height * fit;
          outCtx.imageSmoothingEnabled = true;
          outCtx.imageSmoothingQuality = 'high';
          outCtx.drawImage(
            sourceCanvas,
            crop.x, crop.y, crop.width, crop.height,
            (768 - dw) / 2,
            (768 - dh) / 2,
            dw, dh
          );

          URL.revokeObjectURL(objectUrl);
          resolve(out.toDataURL('image/jpeg', 0.90));
        } catch (error) {
          URL.revokeObjectURL(objectUrl);
          reject(error);
        }
      };

      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('Gambar tidak dapat dibuka.'));
      };

      img.src = objectUrl;
    });
  }

  function saveHistory(value) {
    const current = loadHistory();
    const next = [value, ...current.filter((item) => item !== value)].slice(0, 12);
    gmSet(STORAGE.manualHistory, JSON.stringify(next));
    return next;
  }

  function loadHistory() {
    try {
      const raw = gmGet(STORAGE.manualHistory, '[]');
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.filter((item) => typeof item === 'string') : [];
    } catch (_) {
      return [];
    }
  }

  installTargetSelection();

  if (!isTop) {
    patchGetUserMedia();
    patchSrcObjectSetter();
    loadGalleryImage();
    installMutationWatcher();
    return;
  }

  let panel;
  let launcher;
  let previewEl;
  let historyWrap;
  let galleryBadge;
  let lastCode = '';

  function makeButton(text, color = '#2563eb') {
    const button = doc.createElement('button');
    button.type = 'button';
    button.textContent = text;
    Object.assign(button.style, {
      border: '0',
      borderRadius: '10px',
      padding: '10px 12px',
      fontWeight: '700',
      fontSize: '13px',
      cursor: 'pointer',
      color: '#ffffff',
      background: color,
      touchAction: 'manipulation'
    });
    return button;
  }

  function setStatus(text) {
    if (statusEl) statusEl.textContent = text;
  }

  function renderHistory() {
    if (!historyWrap) return;
    historyWrap.innerHTML = '';
    const items = loadHistory();
    if (!items.length) {
      const empty = doc.createElement('div');
      empty.textContent = 'Riwayat kode belum ada.';
      empty.style.color = '#94a3b8';
      historyWrap.appendChild(empty);
      return;
    }

    items.forEach((value) => {
      const chip = doc.createElement('button');
      chip.type = 'button';
      chip.textContent = value;
      Object.assign(chip.style, {
        border: '1px solid #475569',
        borderRadius: '999px',
        padding: '6px 10px',
        background: '#1e293b',
        color: '#ffffff',
        fontSize: '12px',
        cursor: 'pointer',
        maxWidth: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      });
      chip.addEventListener('click', () => {
        lastCode = value;
        sendManual(value, true);
      });
      historyWrap.appendChild(chip);
    });
  }

  function updateGalleryUi() {
    if (!galleryBadge || !previewEl) return;
    if (!galleryState.enabled) {
      galleryBadge.textContent = 'Galeri: off';
      galleryBadge.style.background = '#334155';
      previewEl.style.display = 'none';
      previewEl.removeAttribute('src');
      return;
    }
    galleryBadge.textContent = galleryState.imageDataUrl
      ? `Galeri: ${galleryState.imageName || 'aktif'}`
      : 'Galeri: aktif, gambar belum dipilih';
    galleryBadge.style.background = '#166534';
    if (galleryState.imageDataUrl) {
      previewEl.src = galleryState.imageDataUrl;
      previewEl.style.display = 'block';
    } else {
      previewEl.style.display = 'none';
      previewEl.removeAttribute('src');
    }
  }

  function sendManual(value, pressEnter) {
    const clean = String(value || '').trim();
    if (!clean) {
      setStatus('Kode masih kosong.');
      return;
    }
    lastCode = clean;
    saveHistory(clean);
    renderHistory();
    setStatus(
      pressEnter
        ? `Mengirim "${clean}" + Enter...`
        : `Mengisi "${clean}" tanpa Enter...`
    );

    const message = {
      channel: CHANNEL,
      type: 'inject',
      value: clean,
      pressEnter,
      depth: 0,
      id: nextMessageId()
    };
    page.postMessage(message, '*');
  }

  function askCode(pressEnter) {
    const result = page.prompt(
      pressEnter
        ? 'Masukkan kode lalu tekan OK (isi + Enter):'
        : 'Masukkan kode lalu tekan OK (hanya isi):',
      lastCode
    );
    if (result === null) return;
    sendManual(result, pressEnter);
  }

  function probe() {
    setStatus('Mencari kolom barcode/HU...');
    const message = { channel: CHANNEL, type: 'probe', depth: 0, id: nextMessageId() };
    page.postMessage(message, '*');
  }

  function chooseGalleryImage() {
    const input = doc.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      input.remove();
      if (!file) return;
      try {
        setStatus('Menyiapkan gambar galeri...');
        const dataUrl = await fileToPreparedDataUrl(file);
        galleryState.imageDataUrl = dataUrl;
        galleryState.imageName = file.name || 'scan-image.jpg';
        galleryState.enabled = true;
        gmSet(STORAGE.galleryEnabled, true);
        gmSet(STORAGE.galleryImage, dataUrl);
        gmSet(STORAGE.galleryName, galleryState.imageName);
        await loadGalleryImage();
        updateGalleryUi();
        setStatus('Mode galeri siap. Buka ulang scanner bila kamera sudah terlanjur aktif.');
      } catch (error) {
        setStatus(`Gagal memuat gambar: ${error.message || error}`);
      }
    }, { once: true });
    (doc.body || doc.documentElement).appendChild(input);
    input.click();
  }

  function toggleGallery() {
    galleryState.enabled = !galleryState.enabled;
    gmSet(STORAGE.galleryEnabled, galleryState.enabled);
    if (!galleryState.enabled) {
      stopGalleryRuntime();
      setStatus('Mode galeri dimatikan. Kamera asli dipakai lagi pada permintaan berikutnya.');
    } else {
      if (galleryState.imageDataUrl) loadGalleryImage().catch(() => {});
      setStatus(
        galleryState.imageDataUrl
          ? 'Mode galeri aktif. Buka ulang scanner bila perlu.'
          : 'Mode galeri aktif, pilih gambar dulu.'
      );
    }
    updateGalleryUi();
  }

  function clearGallery() {
    galleryState.imageDataUrl = '';
    galleryState.imageName = '';
    galleryState.sourceImage = null;
    stopGalleryRuntime();
    gmSet(STORAGE.galleryImage, '');
    gmSet(STORAGE.galleryName, '');
    setStatus('Gambar galeri dihapus.');
    updateGalleryUi();
  }

  function showPanel() {
    if (panel) panel.style.display = 'block';
    if (launcher) launcher.style.display = 'none';
    gmSet(STORAGE.compact, false);
  }

  function hidePanel() {
    if (panel) panel.style.display = 'none';
    if (launcher) launcher.style.display = 'block';
    gmSet(STORAGE.compact, true);
  }

  function createUi() {
    if (panel || !doc.documentElement) return;

    launcher = makeButton('ICE 2.7.2', '#7c3aed');
    Object.assign(launcher.style, {
      position: 'fixed',
      right: '10px',
      bottom: '10px',
      zIndex: '2147483647',
      boxShadow: '0 6px 20px rgba(0,0,0,.45)',
      display: gmGet(STORAGE.compact, false) ? 'block' : 'none'
    });
    launcher.addEventListener('click', showPanel);

    panel = doc.createElement('div');
    Object.assign(panel.style, {
      position: 'fixed',
      left: '10px',
      right: '10px',
      bottom: '10px',
      zIndex: '2147483647',
      background: 'rgba(15,23,42,.97)',
      color: '#ffffff',
      border: '1px solid #475569',
      borderRadius: '14px',
      padding: '10px',
      boxShadow: '0 8px 28px rgba(0,0,0,.5)',
      fontFamily: 'system-ui,sans-serif',
      fontSize: '13px',
      pointerEvents: 'auto',
      display: gmGet(STORAGE.compact, false) ? 'none' : 'block'
    });

    const header = doc.createElement('div');
    Object.assign(header.style, {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: '8px',
      marginBottom: '8px'
    });

    const title = doc.createElement('strong');
    title.textContent = 'ICE Inject v2.7.3 Direct Ready';
    title.style.fontSize = '16px';

    const headerRow = doc.createElement('div');
    headerRow.style.display = 'flex';
    headerRow.style.gap = '6px';

    galleryBadge = doc.createElement('span');
    Object.assign(galleryBadge.style, {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '5px 8px',
      borderRadius: '999px',
      fontSize: '11px',
      fontWeight: '700',
      background: '#334155'
    });

    const smallBtn = makeButton('Kecilkan', '#334155');
    smallBtn.style.padding = '7px 9px';
    smallBtn.addEventListener('click', hidePanel);

    headerRow.append(galleryBadge, smallBtn);
    header.append(title, headerRow);

    const desc = doc.createElement('div');
    desc.textContent = 'Input scanner aktif sejak halaman dimuat. Jika ada banyak kolom, sentuh kolom tujuan terlebih dahulu.';
    Object.assign(desc.style, {
      color: '#cbd5e1',
      lineHeight: '1.4',
      marginBottom: '8px'
    });

    previewEl = doc.createElement('img');
    Object.assign(previewEl.style, {
      display: 'none',
      width: '100%',
      maxHeight: '140px',
      objectFit: 'contain',
      background: '#ffffff',
      borderRadius: '8px',
      marginBottom: '8px'
    });

    const row1 = doc.createElement('div');
    Object.assign(row1.style, {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '6px',
      marginBottom: '6px'
    });

    const fillBtn = makeButton('Isi + Enter', '#0f766e');
    fillBtn.addEventListener('click', () => askCode(true));
    const fillOnlyBtn = makeButton('Isi Saja', '#2563eb');
    fillOnlyBtn.addEventListener('click', () => askCode(false));
    const probeBtn = makeButton('Cek Kolom', '#475569');
    probeBtn.addEventListener('click', probe);
    row1.append(fillBtn, fillOnlyBtn, probeBtn);

    const row2 = doc.createElement('div');
    Object.assign(row2.style, {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '6px',
      marginBottom: '8px'
    });

    const toggleGalleryBtn = makeButton('On/Off Galeri', '#7c3aed');
    toggleGalleryBtn.addEventListener('click', toggleGallery);
    const chooseGalleryBtn = makeButton('Pilih Gambar', '#1d4ed8');
    chooseGalleryBtn.addEventListener('click', chooseGalleryImage);
    const clearGalleryBtn = makeButton('Hapus Gambar', '#991b1b');
    clearGalleryBtn.addEventListener('click', clearGallery);
    row2.append(toggleGalleryBtn, chooseGalleryBtn, clearGalleryBtn);

    statusEl = doc.createElement('div');
    Object.assign(statusEl.style, {
      minHeight: '34px',
      borderRadius: '10px',
      padding: '8px 10px',
      background: 'rgba(30,41,59,.9)',
      color: '#e2e8f0',
      lineHeight: '1.4',
      marginBottom: '8px'
    });
    statusEl.textContent = 'Siap dipakai.';

    const historyTitle = doc.createElement('div');
    historyTitle.textContent = 'Riwayat kode cepat';
    Object.assign(historyTitle.style, {
      fontWeight: '700',
      marginBottom: '6px'
    });

    historyWrap = doc.createElement('div');
    Object.assign(historyWrap.style, {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '6px'
    });

    panel.append(header, desc, previewEl, row1, row2, statusEl, historyTitle, historyWrap);
    doc.documentElement.append(panel, launcher);
    updateGalleryUi();
    renderHistory();
  }

  page.addEventListener('message', (event) => {
    const message = event.data;
    if (!message || message.channel !== CHANNEL) return;

    if (message.type === 'inject-report') {
      if (message.reason === 'target_required') {
        setStatus('Sentuh kolom tujuan scan terlebih dahulu.');
      } else if (message.reason === 'target_fill_failed') {
        setStatus('Kolom tujuan gagal diisi. Sentuh ulang kolom tujuan.');
      } else {
        setStatus(
          message.changed > 0
            ? `Berhasil mengisi ${message.target ? message.target : message.changed + ' kolom'}${message.pressEnter ? ' + Enter' : ''}.`
            : 'Kolom barcode/HU belum ditemukan pada halaman ini.'
        );
      }
      return;
    }

    if (message.type === 'probe-report') {
      setStatus(
        message.count > 0
          ? `Ditemukan ${message.count} kandidat kolom barcode/HU.`
          : 'Belum menemukan kolom barcode/HU.'
      );
      return;
    }

    if (message.type === 'gallery-status' && message.text) {
      setStatus(String(message.text));
    }
  });

  patchGetUserMedia();
  patchSrcObjectSetter();
  loadGalleryImage();
  installMutationWatcher();

  if (doc.readyState === 'loading') {
    doc.addEventListener('DOMContentLoaded', createUi, { once: true });
  } else {
    createUi();
  }
})();
