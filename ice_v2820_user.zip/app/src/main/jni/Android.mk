# HevSocks5Tunnel memakai JNI_OnLoad untuk mendaftarkan metode native.
# PKGNAME dan CLSNAME diberikan melalui Application.mk agar registrasi
# diarahkan ke com/mimar/iceinject/DualNetworkVpnService.
LOCAL_PATH := $(call my-dir)
include $(LOCAL_PATH)/hev-socks5-tunnel/Android.mk
