Tools ICE v1
- Menu utama untuk membuka 4 file HTML offline.
- Mendukung pemilih foto/TXT Android melalui WebView.
- Tombol Back kembali ke menu/halaman sebelumnya.
- Target Android 15, minimum Android 8.

Build:
1. Upload semua isi folder ini ke repository GitHub.
2. Buka Actions > Build Tools ICE APK > Run workflow.
3. Unduh artifact tools_ice_v1_apk.
