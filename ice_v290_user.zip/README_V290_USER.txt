ICE Inject User v2.9.0 — Modern UI

Perubahan tampilan:
- Tema Android Material menggantikan tema Holo lama.
- Menu tiga titik menjadi bottom sheet modern dengan ikon, quick actions, dan animasi halus.
- Toolbar browser, address bar, tombol tab, serta navigasi bawah dirapikan.
- Panel scanner memakai sudut membulat, ripple sentuhan, jarak konsisten, dan animasi buka/tutup ringan.
- Dialog bawaan memakai gaya Material yang lebih rapi.
- Kamera QR mendapat bingkai fokus, panel kontrol modern, dan animasi status.
- Tidak memakai blur atau efek berat; animasi 135–190 ms agar tetap ringan.

Fitur scanner, antrean, dual jaringan, login/lisensi, bookmark, dan tab tetap dipertahankan.
APK output: ice_v290_user.apk
