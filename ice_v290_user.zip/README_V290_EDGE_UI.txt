ICE Inject v2.9.0 Edge UI

Perubahan utama:
- Tab strip permanen seperti Microsoft Edge.
- Tab aktif berbentuk kartu, tombol tutup langsung tanpa animasi membuka tab.
- Address bar baru dengan warna terang, border halus, indikator HTTPS, reload/stop, favorit, jumlah tab, dan menu.
- Daftar tab menjadi bottom sheet modern.
- Menu browser menjadi panel grid modern dan berisi akses langsung scanner, antrean QR, foto QR, desktop mode, bookmark, share, dan lisensi/admin.
- Navigasi bawah terang dan stabil.
- Panel scanner lama tetap dipertahankan agar fungsi kerja tidak berubah.
- Lisensi/login, antrean, foto QR, WebView bridge, desktop mode, GPS, zoom, bookmark, dan logika scanner tidak dihapus.

Catatan:
UI ini bergaya Edge, bukan salinan aset/logo resmi Microsoft. Mesin browser tetap Android WebView modern agar ringan dan kompatibel dengan fitur ICE.
