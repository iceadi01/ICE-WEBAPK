ICE Inject Admin v2.8.4

- Build admin tanpa key/login.
- Package terpisah: com.mimar.iceinject.admin, sehingga bisa dipasang berdampingan dengan versi user.
- Nama aplikasi: ICE Inject Admin.
- Fitur dual jaringan dan ingat Wi-Fi dari v2.8.4 tetap tersedia.
- Karena package terpisah, data/pengaturan Wi-Fi versi user tidak otomatis terbawa ke versi admin.
