package com.mimar.iceinject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.IpPrefix;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.RouteInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URI;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * VPN lokal split-route untuk perangkat non-root.
 * Hanya DNS dan jaringan lokal/perusahaan yang masuk TUN. Internet publik tetap
 * mengikuti jaringan bawaan Android (umumnya data seluler).
 */
public class DualNetworkVpnService extends VpnService {
    public static final String ACTION_CONNECT = "com.mimar.iceinject.DUAL_CONNECT";
    public static final String ACTION_DISCONNECT = "com.mimar.iceinject.DUAL_DISCONNECT";
    public static final String ACTION_STATE = "com.mimar.iceinject.DUAL_STATE";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_MESSAGE = "message";

    private static final String CHANNEL_ID = "ice_dual_network";
    private static final int NOTIFICATION_ID = 2814;
    private static final int SOCKS_PORT = 10808;
    private static final String TUN_ADDRESS = "10.77.0.1";
    private static final String TUN_DNS = "10.77.0.2";
    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_URL = "company_url";
    private static final String DEFAULT_COMPANY_HOST = "lp4m-lpw.liebrapermana.com";

    private static volatile boolean running = false;
    private static volatile String lastMessage = "Dual jaringan sistem belum aktif";
    private static volatile boolean nativeLoaded = false;

    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private ConnectivityManager.NetworkCallback cellularCallback;
    private volatile Network wifiNetwork;
    private volatile Network cellularNetwork;
    private ParcelFileDescriptor tunFd;
    private LocalSocks5Server socksServer;
    private Thread tunnelThread;
    private Thread startThread;
    private volatile boolean stopping = false;

    private static native int nativeRun(String configPath, int tunFd);
    private static native void nativeStop();

    public static boolean isRunning() {
        return running;
    }

    public static String getLastMessage() {
        return lastMessage;
    }

    private static synchronized void ensureNativeLoaded() {
        if (nativeLoaded) return;
        System.loadLibrary("hev-socks5-tunnel");
        System.loadLibrary("ice-dual-jni");
        nativeLoaded = true;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        createNotificationChannel();
        registerNetworkWatchers();
        discoverNetworks();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_CONNECT : intent.getAction();
        if (ACTION_DISCONNECT.equals(action)) {
            stopRouting("Dual jaringan sistem dimatikan");
            return START_NOT_STICKY;
        }
        startForegroundCompat(buildNotification("Menyiapkan Wi-Fi perusahaan…"));
        startRoutingAsync();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public void onRevoke() {
        stopRouting("Izin VPN dicabut oleh Android");
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopRoutingInternal(false, "Layanan dual jaringan berhenti");
        unregisterNetworkWatchers();
        super.onDestroy();
    }

    private synchronized void startRoutingAsync() {
        if (running || (startThread != null && startThread.isAlive())) {
            publishState(running, running ? "Dual jaringan sistem sudah aktif" : "Sedang menyiapkan dual jaringan…");
            return;
        }
        stopping = false;
        startThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    waitForWifi();
                    if (stopping) return;
                    if (wifiNetwork == null) {
                        failAndStop("Wi-Fi perusahaan belum tersedia. Sambungkan dari ICE lalu coba lagi.");
                        return;
                    }
                    buildAndStartTunnel();
                } catch (Throwable error) {
                    failAndStop("Gagal mengaktifkan dual jaringan: " + safeMessage(error));
                }
            }
        }, "ice-dual-start");
        startThread.start();
    }

    private void waitForWifi() throws InterruptedException {
        for (int i = 0; i < 30 && !stopping; i++) {
            discoverNetworks();
            if (wifiNetwork != null) return;
            Thread.sleep(500L);
        }
    }

    private synchronized void buildAndStartTunnel() throws Exception {
        if (running || stopping) return;
        ensureNativeLoaded();

        final String companyHost = getCompanyHost();
        socksServer = new LocalSocks5Server(this, SOCKS_PORT, TUN_DNS);
        socksServer.setNetworks(wifiNetwork, cellularNetwork);
        socksServer.setCompanyHost(companyHost);
        socksServer.start();

        Builder builder = new Builder();
        builder.setSession("ICE Dual Jaringan Sistem");
        builder.setMtu(1500);
        if (Build.VERSION.SDK_INT >= 21) builder.setBlocking(false);
        builder.addAddress(TUN_ADDRESS, 30);

        Set<String> routes = new LinkedHashSet<String>();
        addRoute(builder, routes, "10.0.0.0", 8);
        addRoute(builder, routes, "172.16.0.0", 12);
        addRoute(builder, routes, "192.168.0.0", 16);
        addWifiLinkRoutes(builder, routes, wifiNetwork);
        addCompanyHostRoutes(builder, routes, companyHost, wifiNetwork);
        builder.addDnsServer(TUN_DNS);

        try {
            builder.addDisallowedApplication(getPackageName());
        } catch (PackageManager.NameNotFoundException ignored) {}

        tunFd = builder.establish();
        if (tunFd == null) throw new IOException("Android tidak membuat antarmuka VPN");
        try {
            if (Build.VERSION.SDK_INT >= 22) {
                if (cellularNetwork != null) setUnderlyingNetworks(new Network[] { wifiNetwork, cellularNetwork });
                else setUnderlyingNetworks(new Network[] { wifiNetwork });
            }
        } catch (Throwable ignored) {}

        final File configFile = writeTunnelConfig();
        final int fd = tunFd.getFd();
        running = true;
        publishState(true, "Aktif: LP4M/subnet via Wi-Fi • internet publik via data");
        updateNotification("LP4M/subnet via Wi-Fi • internet via data");

        tunnelThread = new Thread(new Runnable() {
            @Override
            public void run() {
                int result = -1;
                try {
                    result = nativeRun(configFile.getAbsolutePath(), fd);
                } catch (Throwable error) {
                    lastMessage = "Mesin tunnel berhenti: " + safeMessage(error);
                }
                if (!stopping) {
                    final String message = result == 0
                            ? "Mesin dual jaringan berhenti"
                            : "Mesin dual jaringan gagal (kode " + result + ")";
                    failAndStop(message);
                }
            }
        }, "ice-hev-tunnel");
        tunnelThread.start();
    }

    private File writeTunnelConfig() throws IOException {
        File config = new File(getCacheDir(), "ice-dual-tunnel.yml");
        String text = "misc:\n"
                + " task-stack-size: 86016\n"
                + " connect-timeout: 10000\n"
                + " tcp-read-write-timeout: 300000\n"
                + " udp-read-write-timeout: 60000\n"
                + " log-level: warn\n"
                + "tunnel:\n"
                + " mtu: 1500\n"
                + "socks5:\n"
                + " port: " + SOCKS_PORT + "\n"
                + " address: '127.0.0.1'\n"
                + " udp: 'udp'\n";
        FileOutputStream output = new FileOutputStream(config, false);
        try {
            output.write(text.getBytes("UTF-8"));
            output.flush();
        } finally {
            output.close();
        }
        return config;
    }

    private void addWifiLinkRoutes(Builder builder, Set<String> routes, Network network) {
        if (connectivityManager == null || network == null) return;
        try {
            LinkProperties properties = connectivityManager.getLinkProperties(network);
            if (properties == null) return;
            List<RouteInfo> networkRoutes = properties.getRoutes();
            for (RouteInfo route : networkRoutes) {
                IpPrefix prefix = route.getDestination();
                if (prefix == null || !(prefix.getAddress() instanceof Inet4Address)) continue;
                int length = prefix.getPrefixLength();
                if (length <= 0 || length > 32) continue;
                addRoute(builder, routes, prefix.getAddress().getHostAddress(), length);
            }
        } catch (Throwable ignored) {}
    }

    private void addCompanyHostRoutes(Builder builder, Set<String> routes, String host, Network network) {
        if (network == null || host == null || host.length() == 0) return;
        try {
            InetAddress[] addresses = network.getAllByName(host);
            for (InetAddress address : addresses) {
                if (address instanceof Inet4Address) {
                    addRoute(builder, routes, address.getHostAddress(), 32);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void addRoute(Builder builder, Set<String> routes, String address, int prefix) {
        String key = address + "/" + prefix;
        if (!routes.add(key)) return;
        try {
            builder.addRoute(address, prefix);
        } catch (Throwable ignored) {}
    }

    private String getCompanyHost() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String url = prefs.getString(PREF_URL, "");
        if (url != null && url.trim().length() > 0) {
            try {
                String host = new URI(url.trim()).getHost();
                if (host != null && host.length() > 0) return host.toLowerCase();
            } catch (Throwable ignored) {}
        }
        return DEFAULT_COMPANY_HOST;
    }

    private void registerNetworkWatchers() {
        if (connectivityManager == null) return;
        try {
            NetworkRequest wifiRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            wifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    wifiNetwork = network;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
                @Override public void onLost(Network network) {
                    if (network != null && network.equals(wifiNetwork)) wifiNetwork = null;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                    if (running && wifiNetwork == null) publishState(true, "VPN aktif, tetapi Wi-Fi perusahaan terputus");
                }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        wifiNetwork = network;
                        if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                    }
                }
            };
            connectivityManager.registerNetworkCallback(wifiRequest, wifiCallback);

            NetworkRequest cellularRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            cellularCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    cellularNetwork = network;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
                @Override public void onLost(Network network) {
                    if (network != null && network.equals(cellularNetwork)) cellularNetwork = null;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
            };
            connectivityManager.requestNetwork(cellularRequest, cellularCallback);
        } catch (Throwable ignored) {}
    }

    private void unregisterNetworkWatchers() {
        if (connectivityManager == null) return;
        try { if (wifiCallback != null) connectivityManager.unregisterNetworkCallback(wifiCallback); } catch (Throwable ignored) {}
        try { if (cellularCallback != null) connectivityManager.unregisterNetworkCallback(cellularCallback); } catch (Throwable ignored) {}
        wifiCallback = null;
        cellularCallback = null;
    }

    private void discoverNetworks() {
        if (connectivityManager == null) return;
        try {
            Network preferredWifi = null;
            Network preferredCell = null;
            for (Network network : connectivityManager.getAllNetworks()) {
                NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(network);
                if (caps == null) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    // Jaringan lokal tanpa INTERNET diprioritaskan karena ini biasanya
                    // hasil WifiNetworkSpecifier dari ICE v2.8.9.
                    if (preferredWifi == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        preferredWifi = network;
                    }
                }
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    preferredCell = network;
                }
            }
            if (preferredWifi != null) wifiNetwork = preferredWifi;
            if (preferredCell != null) cellularNetwork = preferredCell;
            if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
        } catch (Throwable ignored) {}
    }

    private void stopRouting(String message) {
        stopRoutingInternal(true, message);
    }

    private synchronized void stopRoutingInternal(boolean stopSelfToo, String message) {
        if (stopping) return;
        stopping = true;
        running = false;
        try { if (nativeLoaded) nativeStop(); } catch (Throwable ignored) {}
        if (socksServer != null) {
            try { socksServer.stop(); } catch (Throwable ignored) {}
            socksServer = null;
        }
        if (tunFd != null) {
            try { tunFd.close(); } catch (Throwable ignored) {}
            tunFd = null;
        }
        publishState(false, message);
        try { stopForeground(true); } catch (Throwable ignored) {}
        if (stopSelfToo) stopSelf();
    }

    private void failAndStop(final String message) {
        publishState(false, message);
        updateNotification(message);
        stopRoutingInternal(true, message);
    }

    private void publishState(boolean active, String message) {
        running = active;
        lastMessage = message == null ? "" : message;
        Intent broadcast = new Intent(ACTION_STATE);
        broadcast.setPackage(getPackageName());
        broadcast.putExtra(EXTRA_STATE, active);
        broadcast.putExtra(EXTRA_MESSAGE, lastMessage);
        sendBroadcast(broadcast);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int immutable = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent openIntent = PendingIntent.getActivity(this, 2814, open, immutable | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, DualNetworkVpnService.class);
        stop.setAction(ACTION_DISCONNECT);
        PendingIntent stopIntent = PendingIntent.getService(this, 2815, stop, immutable | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("ICE Dual Jaringan")
                .setContentText(text)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopIntent);
        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "ICE Dual Jaringan", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Routing LP4M dan subnet perusahaan melalui Wi-Fi lokal");
        manager.createNotificationChannel(channel);
    }

    private static String safeMessage(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        return message == null || message.length() == 0 ? error.getClass().getSimpleName() : message;
    }
}
