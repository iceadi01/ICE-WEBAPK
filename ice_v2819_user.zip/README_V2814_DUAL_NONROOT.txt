ICE Inject v2.8.14 — Dual Jaringan Sistem Non-root
======================================================

Perubahan utama
- Basis koneksi ICE tetap memakai pola v2.8.9.
- Ditambahkan VpnService split-route untuk HP non-root.
- Chrome/browser lain dapat memakai LP4M dan subnet lokal melalui Wi-Fi perusahaan.
- Internet publik tidak dimasukkan ke tunnel dan tetap mengikuti data seluler Android.
- DNS LP4M diprioritaskan ke DNS Wi-Fi perusahaan; DNS umum ke data seluler.
- Layanan tetap aktif saat ICE diminimalkan dan menampilkan notifikasi permanen.
- Tombol badge jaringan: aktifkan. Tekan lama: pengaturan SSID/password dan tombol matikan.

Cara build GitHub Actions
1. Upload ZIP source user/admin ke root repository kosong.
2. Upload file workflow build-user-v2814.yml atau build-admin-v2814.yml ke:
   .github/workflows/
3. Buka Actions > workflow v2.8.14 > Run workflow.
4. Workflow mengunduh hev-socks5-tunnel resmi dan Android NDK, lalu build + sign APK.

Catatan penggunaan
- Android akan meminta izin VPN satu kali.
- Ikon VPN/notifikasi harus tetap aktif agar browser lain dapat mengakses subnet perusahaan.
- Android hanya mengizinkan satu VPN aktif, jadi VPN lain harus dimatikan.
- Mode sistem membutuhkan Android 10+ karena koneksi Wi-Fi lokal memakai WifiNetworkSpecifier.
- Bila Chrome memakai Secure DNS/DoH dan LP4M tidak ter-resolve, matikan Secure DNS di Chrome.

Dependensi native
- https://github.com/heiher/hev-socks5-tunnel
- Workflow mencoba tag 2.15.0 lalu fallback ke branch utama.
