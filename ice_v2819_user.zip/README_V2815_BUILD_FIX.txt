ICE Inject v2.8.15 — Build Fix

Perbaikan:
- Mempertahankan path app/src/main/jni sebelum Android.mk Hev dimasukkan.
- Mencegah ndk-build mencari ice_dual_jni.c di folder build/core milik NDK.
- Tetap memakai basis koneksi ICE v2.8.9 dan dual jaringan sistem non-root.
- Workflow v2.8.15 juga menulis ulang Android.mk yang benar saat build.
