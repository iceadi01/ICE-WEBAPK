ICE Inject v2.8.2 — Dual Network Seluruh HP (uji Tecno Android 15)

Target:
- Wi-Fi perusahaan tetap tersambung untuk membuka LP4M di ICE Inject.
- Data seluler tetap dipertahankan aktif agar WhatsApp, Telegram, Chrome,
  dan notifikasi aplikasi lain dapat memakai internet tanpa memutus Wi-Fi.

Perubahan:
1. Menambahkan foreground service DualNetworkService.
2. Service meminta dan mempertahankan jaringan seluler selama aktif.
3. Service tetap berjalan saat ICE Inject diminimalkan/ditutup dari layar recent,
   kecuali aplikasi dipaksa berhenti atau HP mematikan service karena pembatasan baterai.
4. Ada notifikasi tetap "ICE Dual Network aktif" dengan tombol Matikan.
5. Tekan badge WIFI+DATA pada ICE Inject untuk melihat status, mengaktifkan,
   atau mematikan layanan seluruh HP.
6. Routing LP4M di dalam ICE Inject tetap melalui Wi-Fi perusahaan.
7. Package dan signing key tetap sama agar dapat dipasang sebagai pembaruan.

Cara tes:
1. Nyalakan data seluler.
2. Sambungkan Wi-Fi perusahaan dan pilih tetap terhubung walau tanpa internet.
3. Buka ICE Inject v2.8.2; service mulai otomatis.
4. Pastikan notifikasi "ICE Dual Network aktif" muncul.
5. Buka LP4M di ICE Inject.
6. Tanpa memutus Wi-Fi, pindah ke WhatsApp/Chrome dan coba internet/notifikasi.

Catatan penting:
- Aplikasi biasa tidak dapat mengubah tabel routing seluruh Android seperti aplikasi sistem/root.
  Versi ini memakai metode non-root yang aman: mempertahankan jaringan seluler aktif,
  sementara Android memilih data sebagai jalur internet dan Wi-Fi sebagai jaringan lokal.
- Hasil akhir dapat berbeda pada firmware HiOS/Tecno. Jika aplikasi lain tetap tidak mendapat
  internet, aktifkan "Data seluler selalu aktif" di Opsi Developer dan izinkan ICE Inject
  berjalan tanpa pembatasan baterai/auto-start.
- Ini bukan VPN internet dan tidak mengirim trafik ke server pihak ketiga.

Versi:
- versionCode 22
- versionName 2.8.2
