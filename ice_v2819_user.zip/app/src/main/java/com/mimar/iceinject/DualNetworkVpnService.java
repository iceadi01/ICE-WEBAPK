package com.mimar.iceinject;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.IpPrefix;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.RouteInfo;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URI;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * VPN lokal split-route untuk perangkat non-root.
 * Hanya DNS dan jaringan lokal/perusahaan yang masuk TUN. Internet publik tetap
 * mengikuti jaringan bawaan Android (umumnya data seluler).
 */
public class DualNetworkVpnService extends VpnService {
    public static final String ACTION_CONNECT = "com.mimar.iceinject.DUAL_CONNECT";
    public static final String ACTION_DISCONNECT = "com.mimar.iceinject.DUAL_DISCONNECT";
    public static final String ACTION_QUERY = "com.mimar.iceinject.DUAL_QUERY";
    public static final String ACTION_STATE = "com.mimar.iceinject.DUAL_STATE";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_MESSAGE = "message";

    private static final String CHANNEL_ID = "ice_dual_network";
    private static final int NOTIFICATION_ID = 2814;
    private static final int SOCKS_PORT = 10808;
    private static final String TUN_ADDRESS = "10.77.0.1";
    private static final String TUN_DNS = "10.77.0.2";
    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_URL = "company_url";
    private static final String DEFAULT_COMPANY_HOST = "lp4m-lpw.liebrapermana.com";

    private static volatile boolean running = false;
    private static volatile boolean starting = false;
    private static volatile String lastMessage = "Dual jaringan sistem belum aktif";
    private static volatile boolean nativeLoaded = false;

    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback wifiCallback;
    private ConnectivityManager.NetworkCallback cellularCallback;
    private volatile Network wifiNetwork;
    private volatile Network cellularNetwork;
    private ParcelFileDescriptor tunFd;
    private LocalSocks5Server socksServer;
    private Thread tunnelThread;
    private Thread startThread;
    private volatile boolean stopping = false;
    private volatile boolean engineStarted = false;
    private File engineMarker;
    private boolean previousEngineCrash = false;

    private static native int nativeRun(String configPath, int tunFd);
    private static native void nativeStop();

    public static boolean isRunning() {
        return running;
    }

    public static String getLastMessage() {
        return lastMessage;
    }

    private static synchronized void ensureNativeLoaded() {
        if (nativeLoaded) return;
        System.loadLibrary("hev-socks5-tunnel");
        System.loadLibrary("ice-dual-jni");
        nativeLoaded = true;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        engineMarker = new File(getFilesDir(), "ice_dual_engine_running.flag");
        installJavaCrashRecorder();
        String exitDiagnosis = readPreviousVpnExitDiagnosis();
        previousEngineCrash = engineMarker.exists();
        if (exitDiagnosis.length() > 0) {
            lastMessage = exitDiagnosis;
        } else if (previousEngineCrash) {
            String detail = readEngineLogTail();
            lastMessage = "Mesin VPN sebelumnya berhenti mendadak"
                    + (detail.length() == 0 ? "." : ": " + detail);
        }
        if (previousEngineCrash) deleteEngineMarker();
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            createNotificationChannel();
            registerNetworkWatchers();
            discoverNetworks();
        } catch (Throwable error) {
            lastMessage = "Gagal menyiapkan layanan VPN: " + safeMessage(error);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_CONNECT : intent.getAction();
        try {
            if (ACTION_QUERY.equals(action)) {
                boolean activeOrStarting = running || starting
                        || (startThread != null && startThread.isAlive());
                String message = starting && !running
                        ? "Sedang menyiapkan dual jaringan sistem…"
                        : lastMessage;
                publishState(running, message);
                // Jangan hentikan service ketika ACTION_QUERY datang saat proses start.
                // Dialog izin VPN membuat Activity resume dan melakukan query sekitar 250 ms
                // setelah ACTION_CONNECT; versi 2.8.16 salah mematikan service di sini.
                if (!activeOrStarting) stopSelf(startId);
                return activeOrStarting ? START_STICKY : START_NOT_STICKY;
            }
            if (ACTION_DISCONNECT.equals(action)) {
                stopRouting("Dual jaringan sistem dimatikan");
                return START_NOT_STICKY;
            }
            startForegroundCompat(buildNotification("Menyiapkan Wi-Fi perusahaan…"));
            previousEngineCrash = false;
            deleteEngineMarker();
            startRoutingAsync();
            return START_STICKY;
        } catch (Throwable error) {
            String message = "Layanan VPN gagal dimulai: " + safeMessage(error);
            publishState(false, message);
            try { stopForeground(true); } catch (Throwable ignored) {}
            stopSelf(startId);
            return START_NOT_STICKY;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public void onRevoke() {
        stopRouting("Izin VPN dicabut oleh Android");
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopRoutingInternal(false, "Layanan dual jaringan berhenti");
        unregisterNetworkWatchers();
        super.onDestroy();
    }

    private synchronized void startRoutingAsync() {
        if (running || starting || (startThread != null && startThread.isAlive())) {
            publishState(running, running ? "Dual jaringan sistem sudah aktif" : "Sedang menyiapkan dual jaringan…");
            return;
        }
        stopping = false;
        starting = true;
        publishState(false, "Sedang menyiapkan dual jaringan sistem…");
        startThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    waitForWifi();
                    if (stopping) return;
                    if (wifiNetwork == null) {
                        failAndStop("Wi-Fi perusahaan belum tersedia. Sambungkan dari ICE lalu coba lagi.");
                        return;
                    }
                    buildAndStartTunnel();
                } catch (Throwable error) {
                    failAndStop("Gagal mengaktifkan dual jaringan: " + safeMessage(error));
                }
            }
        }, "ice-dual-start");
        startThread.start();
    }

    private void waitForWifi() throws InterruptedException {
        for (int i = 0; i < 30 && !stopping; i++) {
            discoverNetworks();
            if (wifiNetwork != null) return;
            Thread.sleep(500L);
        }
    }

    private synchronized void buildAndStartTunnel() throws Exception {
        if (running || stopping) return;
        ensureNativeLoaded();

        final String companyHost = getCompanyHost();
        socksServer = new LocalSocks5Server(this, SOCKS_PORT, TUN_DNS);
        socksServer.setNetworks(wifiNetwork, cellularNetwork);
        socksServer.setCompanyHost(companyHost);
        socksServer.start();

        Builder builder = new Builder();
        builder.setSession("ICE Dual Jaringan Sistem");
        builder.setMtu(1400);
        if (Build.VERSION.SDK_INT >= 21) builder.setBlocking(false);
        builder.addAddress(TUN_ADDRESS, 30);

        Set<String> routes = new LinkedHashSet<String>();
        addRoute(builder, routes, "10.0.0.0", 8);
        addRoute(builder, routes, "172.16.0.0", 12);
        addRoute(builder, routes, "192.168.0.0", 16);
        addWifiLinkRoutes(builder, routes, wifiNetwork);
        addCompanyHostRoutes(builder, routes, companyHost, wifiNetwork);
        builder.addDnsServer(TUN_DNS);

        try {
            builder.addDisallowedApplication(getPackageName());
        } catch (PackageManager.NameNotFoundException ignored) {}

        tunFd = builder.establish();
        if (tunFd == null) throw new IOException("Android tidak membuat antarmuka VPN");
        try {
            if (Build.VERSION.SDK_INT >= 22) {
                if (cellularNetwork != null) setUnderlyingNetworks(new Network[] { wifiNetwork, cellularNetwork });
                else setUnderlyingNetworks(new Network[] { wifiNetwork });
            }
        } catch (Throwable ignored) {}

        final File configFile = writeTunnelConfig();
        final int fd = tunFd.getFd();

        tunnelThread = new Thread(new Runnable() {
            @Override
            public void run() {
                int result = -1;
                engineStarted = true;
                writeEngineMarker();
                try {
                    result = nativeRun(configFile.getAbsolutePath(), fd);
                } catch (Throwable error) {
                    lastMessage = "Mesin tunnel berhenti: " + safeMessage(error);
                } finally {
                    engineStarted = false;
                    deleteEngineMarker();
                }
                if (!stopping) {
                    String base = result == 0
                            ? "Mesin dual jaringan berhenti"
                            : "Mesin dual jaringan gagal (kode " + result + ")";
                    String detail = readEngineLogTail();
                    final String message = detail.length() == 0 ? base : base + ": " + detail;
                    // nativeRun sudah selesai. Jangan panggil nativeStop lagi dari thread ini.
                    failAndStop(message);
                }
            }
        }, "ice-hev-tunnel");
        tunnelThread.start();

        // nativeRun bersifat blocking. Jika thread masih hidup setelah masa uji,
        // mesin dianggap benar-benar aktif. Ini mencegah status aktif palsu.
        for (int i = 0; i < 15 && !stopping; i++) {
            if (!tunnelThread.isAlive()) return;
            Thread.sleep(100L);
        }
        if (stopping || !tunnelThread.isAlive()) return;
        starting = false;
        running = true;
        publishState(true, "Aktif: LP4M/subnet via Wi-Fi • internet publik via data");
        updateNotification("LP4M/subnet via Wi-Fi • internet via data");
    }

    private File writeTunnelConfig() throws IOException {
        File config = new File(getCacheDir(), "ice-dual-tunnel.yml");
        File logFile = new File(getFilesDir(), "ice-dual-hev.log");
        try { new FileOutputStream(logFile, false).close(); } catch (Throwable ignored) {}
        String logPath = logFile.getAbsolutePath().replace("'", "");
        String text = "misc:\n"
                + " task-stack-size: 86016\n"
                + " connect-timeout: 10000\n"
                + " tcp-read-write-timeout: 300000\n"
                + " udp-read-write-timeout: 60000\n"
                + " log-file: '" + logPath + "'\n"
                + " log-level: debug\n"
                + "tunnel:\n"
                + " mtu: 1400\n"
                + "socks5:\n"
                + " port: " + SOCKS_PORT + "\n"
                + " address: '127.0.0.1'\n"
                + " udp: 'udp'\n";
        FileOutputStream output = new FileOutputStream(config, false);
        try {
            output.write(text.getBytes("UTF-8"));
            output.flush();
        } finally {
            output.close();
        }
        return config;
    }

    private void addWifiLinkRoutes(Builder builder, Set<String> routes, Network network) {
        if (connectivityManager == null || network == null) return;
        try {
            LinkProperties properties = connectivityManager.getLinkProperties(network);
            if (properties == null) return;
            List<RouteInfo> networkRoutes = properties.getRoutes();
            for (RouteInfo route : networkRoutes) {
                IpPrefix prefix = route.getDestination();
                if (prefix == null || !(prefix.getAddress() instanceof Inet4Address)) continue;
                int length = prefix.getPrefixLength();
                if (length <= 0 || length > 32) continue;
                addRoute(builder, routes, prefix.getAddress().getHostAddress(), length);
            }
        } catch (Throwable ignored) {}
    }

    private void addCompanyHostRoutes(Builder builder, Set<String> routes, String host, Network network) {
        if (network == null || host == null || host.length() == 0) return;
        try {
            InetAddress[] addresses = network.getAllByName(host);
            for (InetAddress address : addresses) {
                if (address instanceof Inet4Address) {
                    addRoute(builder, routes, address.getHostAddress(), 32);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void addRoute(Builder builder, Set<String> routes, String address, int prefix) {
        String key = address + "/" + prefix;
        if (!routes.add(key)) return;
        try {
            builder.addRoute(address, prefix);
        } catch (Throwable ignored) {}
    }

    private String getCompanyHost() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String url = prefs.getString(PREF_URL, "");
        if (url != null && url.trim().length() > 0) {
            try {
                String host = new URI(url.trim()).getHost();
                if (host != null && host.length() > 0) return host.toLowerCase();
            } catch (Throwable ignored) {}
        }
        return DEFAULT_COMPANY_HOST;
    }

    private void registerNetworkWatchers() {
        if (connectivityManager == null) return;
        try {
            NetworkRequest wifiRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            wifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    wifiNetwork = network;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
                @Override public void onLost(Network network) {
                    if (network != null && network.equals(wifiNetwork)) wifiNetwork = null;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                    if (running && wifiNetwork == null) publishState(true, "VPN aktif, tetapi Wi-Fi perusahaan terputus");
                }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        wifiNetwork = network;
                        if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                    }
                }
            };
            connectivityManager.registerNetworkCallback(wifiRequest, wifiCallback);

            NetworkRequest cellularRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            cellularCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    cellularNetwork = network;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
                @Override public void onLost(Network network) {
                    if (network != null && network.equals(cellularNetwork)) cellularNetwork = null;
                    if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
                }
            };
            connectivityManager.requestNetwork(cellularRequest, cellularCallback);
        } catch (Throwable ignored) {}
    }

    private void unregisterNetworkWatchers() {
        if (connectivityManager == null) return;
        try { if (wifiCallback != null) connectivityManager.unregisterNetworkCallback(wifiCallback); } catch (Throwable ignored) {}
        try { if (cellularCallback != null) connectivityManager.unregisterNetworkCallback(cellularCallback); } catch (Throwable ignored) {}
        wifiCallback = null;
        cellularCallback = null;
    }

    private void discoverNetworks() {
        if (connectivityManager == null) return;
        try {
            Network preferredWifi = null;
            Network preferredCell = null;
            for (Network network : connectivityManager.getAllNetworks()) {
                NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(network);
                if (caps == null) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    // Jaringan lokal tanpa INTERNET diprioritaskan karena ini biasanya
                    // hasil WifiNetworkSpecifier dari ICE v2.8.9.
                    if (preferredWifi == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        preferredWifi = network;
                    }
                }
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    preferredCell = network;
                }
            }
            if (preferredWifi != null) wifiNetwork = preferredWifi;
            if (preferredCell != null) cellularNetwork = preferredCell;
            if (socksServer != null) socksServer.setNetworks(wifiNetwork, cellularNetwork);
        } catch (Throwable ignored) {}
    }

    private void stopRouting(String message) {
        stopRoutingInternal(true, message);
    }

    private synchronized void stopRoutingInternal(boolean stopSelfToo, String message) {
        if (stopping) return;
        stopping = true;
        starting = false;
        running = false;
        deleteEngineMarker();
        // Hanya kirim perintah quit bila nativeRun masih benar-benar aktif.
        // Memanggil quit setelah init gagal dapat menunggu event-fd yang belum dibuat.
        boolean shouldStopNative = nativeLoaded && engineStarted
                && Thread.currentThread() != tunnelThread;
        try { if (shouldStopNative) nativeStop(); } catch (Throwable ignored) {}
        if (socksServer != null) {
            try { socksServer.stop(); } catch (Throwable ignored) {}
            socksServer = null;
        }
        if (tunFd != null) {
            try { tunFd.close(); } catch (Throwable ignored) {}
            tunFd = null;
        }
        publishState(false, message);
        try { stopForeground(true); } catch (Throwable ignored) {}
        if (stopSelfToo) stopSelf();
    }

    private void failAndStop(final String message) {
        publishState(false, message);
        updateNotification(message);
        stopRoutingInternal(true, message);
    }

    private void publishState(boolean active, String message) {
        running = active;
        lastMessage = message == null ? "" : message;
        Intent broadcast = new Intent(ACTION_STATE);
        broadcast.setPackage(getPackageName());
        broadcast.putExtra(EXTRA_STATE, active);
        broadcast.putExtra(EXTRA_MESSAGE, lastMessage);
        sendBroadcast(broadcast);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int immutable = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent openIntent = PendingIntent.getActivity(this, 2814, open, immutable | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, DualNetworkVpnService.class);
        stop.setAction(ACTION_DISCONNECT);
        PendingIntent stopIntent = PendingIntent.getService(this, 2815, stop, immutable | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("ICE Dual Jaringan")
                .setContentText(text)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan", stopIntent);
        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
                return;
            } catch (Throwable ignored) {
                // Beberapa ROM Android 15 lama salah menerapkan overload 3 argumen.
            }
        }
        startForeground(NOTIFICATION_ID, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "ICE Dual Jaringan", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Routing LP4M dan subnet perusahaan melalui Wi-Fi lokal");
        manager.createNotificationChannel(channel);
    }

    private void writeEngineMarker() {
        if (engineMarker == null) return;
        try {
            FileOutputStream output = new FileOutputStream(engineMarker, false);
            try {
                String text = "pid=" + android.os.Process.myPid() + "\n"
                        + "time=" + System.currentTimeMillis() + "\n";
                output.write(text.getBytes("UTF-8"));
                output.flush();
            } finally {
                output.close();
            }
        } catch (Throwable ignored) {}
    }

    private void deleteEngineMarker() {
        if (engineMarker == null) return;
        try { if (engineMarker.exists()) engineMarker.delete(); } catch (Throwable ignored) {}
    }

    private String readEngineLogTail() {
        File logFile = new File(getFilesDir(), "ice-dual-hev.log");
        if (!logFile.exists() || logFile.length() <= 0) return "";
        RandomAccessFile input = null;
        try {
            input = new RandomAccessFile(logFile, "r");
            long start = Math.max(0L, input.length() - 4096L);
            input.seek(start);
            byte[] data = new byte[(int) (input.length() - start)];
            input.readFully(data);
            String text = new String(data, "UTF-8")
                    .replace('\r', ' ').replace('\n', ' ').trim();
            while (text.contains("  ")) text = text.replace("  ", " ");
            if (text.length() > 260) text = text.substring(text.length() - 260);
            return text;
        } catch (Throwable ignored) {
            return "";
        } finally {
            if (input != null) try { input.close(); } catch (Throwable ignored) {}
        }
    }


    private void installJavaCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread thread, Throwable error) {
                File file = new File(getFilesDir(), "ice-dual-java-crash.txt");
                FileOutputStream output = null;
                try {
                    output = new FileOutputStream(file, false);
                    StringBuilder text = new StringBuilder();
                    text.append(error == null ? "Throwable null" : error.toString()).append('\n');
                    if (error != null) {
                        StackTraceElement[] trace = error.getStackTrace();
                        int limit = Math.min(trace == null ? 0 : trace.length, 40);
                        for (int i = 0; i < limit; i++) text.append("at ").append(trace[i]).append('\n');
                    }
                    output.write(text.toString().getBytes("UTF-8"));
                    output.flush();
                } catch (Throwable ignored) {
                } finally {
                    if (output != null) try { output.close(); } catch (Throwable ignored) {}
                }
                if (previous != null) previous.uncaughtException(thread, error);
                else android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
    }

    private String readPreviousVpnExitDiagnosis() {
        String javaCrash = readSmallTextFile(new File(getFilesDir(), "ice-dual-java-crash.txt"), 900);
        if (javaCrash.length() > 0) {
            try { new File(getFilesDir(), "ice-dual-java-crash.txt").delete(); } catch (Throwable ignored) {}
            return "Crash Java proses VPN: " + compact(javaCrash, 280);
        }
        if (Build.VERSION.SDK_INT < 30) return "";
        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (manager == null) return "";
            List<ApplicationExitInfo> exits = manager.getHistoricalProcessExitReasons(getPackageName(), 0, 20);
            if (exits == null) return "";
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            long reported = prefs.getLong("dual_vpn_last_exit_reported", 0L);
            String expected = getPackageName() + ":dualvpn";
            for (ApplicationExitInfo info : exits) {
                if (info == null || !expected.equals(info.getProcessName())) continue;
                long time = info.getTimestamp();
                if (time <= reported) continue;
                int reason = info.getReason();
                // Normal exit/user stop tidak dianggap crash.
                if (reason == ApplicationExitInfo.REASON_USER_REQUESTED
                        || reason == ApplicationExitInfo.REASON_EXIT_SELF
                        || reason == ApplicationExitInfo.REASON_OTHER) continue;
                prefs.edit().putLong("dual_vpn_last_exit_reported", time).apply();
                String label;
                if (reason == ApplicationExitInfo.REASON_CRASH_NATIVE) label = "Crash native VPN";
                else if (reason == ApplicationExitInfo.REASON_CRASH) label = "Crash Java VPN";
                else if (reason == ApplicationExitInfo.REASON_ANR) label = "VPN tidak merespons (ANR)";
                else if (reason == ApplicationExitInfo.REASON_LOW_MEMORY) label = "VPN dihentikan karena memori rendah";
                else if (reason == ApplicationExitInfo.REASON_SIGNALED) label = "VPN dihentikan sinyal sistem";
                else label = "Proses VPN berhenti (reason " + reason + ")";
                String description = info.getDescription();
                String detail = label + ", status " + info.getStatus();
                if (description != null && description.trim().length() > 0) {
                    detail += ": " + description.trim();
                }
                String hev = readEngineLogTail();
                if (hev.length() > 0) detail += " | Hev: " + hev;
                return compact(detail, 420);
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private String readSmallTextFile(File file, int maxBytes) {
        if (file == null || !file.exists() || file.length() <= 0) return "";
        RandomAccessFile input = null;
        try {
            input = new RandomAccessFile(file, "r");
            long start = Math.max(0L, input.length() - Math.max(128, maxBytes));
            input.seek(start);
            byte[] data = new byte[(int) (input.length() - start)];
            input.readFully(data);
            return new String(data, "UTF-8");
        } catch (Throwable ignored) {
            return "";
        } finally {
            if (input != null) try { input.close(); } catch (Throwable ignored) {}
        }
    }

    private String compact(String text, int max) {
        if (text == null) return "";
        String value = text.replace('\r', ' ').replace('\n', ' ').trim();
        while (value.contains("  ")) value = value.replace("  ", " ");
        if (value.length() > max) value = value.substring(0, max);
        return value;
    }

    private static String safeMessage(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        return message == null || message.length() == 0 ? error.getClass().getSimpleName() : message;
    }
}
