package com.mimar.iceinject;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.os.Build;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** SOCKS5 lokal yang memilih socket keluar melalui Network Wi-Fi atau seluler. */
public final class LocalSocks5Server {
    private static final int SOCKS_VERSION = 5;
    private static final int CMD_CONNECT = 1;
    private static final int CMD_UDP_ASSOCIATE = 3;
    private static final int ATYP_IPV4 = 1;
    private static final int ATYP_DOMAIN = 3;
    private static final int ATYP_IPV6 = 4;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private final Context context;
    private final ConnectivityManager connectivityManager;
    private final int port;
    private final InetAddress syntheticDns;
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private volatile boolean running;
    private volatile Network wifiNetwork;
    private volatile Network cellularNetwork;
    private volatile String companyHost = "lp4m-lpw.liebrapermana.com";
    private volatile String companySuffix = "liebrapermana.com";
    private ServerSocket serverSocket;
    private Thread acceptThread;

    LocalSocks5Server(Context context, int port, String syntheticDns) throws IOException {
        this.context = context.getApplicationContext();
        this.connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        this.port = port;
        this.syntheticDns = InetAddress.getByName(syntheticDns);
    }

    void setNetworks(Network wifi, Network cellular) {
        this.wifiNetwork = wifi;
        this.cellularNetwork = cellular;
    }

    void setCompanyHost(String host) {
        if (host == null || host.trim().length() == 0) return;
        companyHost = normalizeHost(host);
        String[] labels = companyHost.split("\\.");
        if (labels.length >= 2) companySuffix = labels[labels.length - 2] + "." + labels[labels.length - 1];
    }

    synchronized void start() throws IOException {
        if (running) return;
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port));
        running = true;
        acceptThread = new Thread(new Runnable() {
            @Override public void run() { acceptLoop(); }
        }, "ice-socks-accept");
        acceptThread.start();
    }

    synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        serverSocket = null;
        workers.shutdownNow();
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket client = serverSocket.accept();
                client.setTcpNoDelay(true);
                workers.execute(new Runnable() {
                    @Override public void run() { handleClient(client); }
                });
            } catch (SocketException closed) {
                if (running) sleepQuietly(100L);
            } catch (Throwable error) {
                if (running) sleepQuietly(100L);
            }
        }
    }

    private void handleClient(Socket client) {
        try {
            BufferedInputStream input = new BufferedInputStream(client.getInputStream());
            BufferedOutputStream output = new BufferedOutputStream(client.getOutputStream());
            int version = readU8(input);
            int methodCount = readU8(input);
            if (version != SOCKS_VERSION || methodCount <= 0) return;
            byte[] methods = new byte[methodCount];
            readFully(input, methods);
            output.write(new byte[] { 5, 0 });
            output.flush();

            int requestVersion = readU8(input);
            int command = readU8(input);
            readU8(input); // RSV
            int addressType = readU8(input);
            if (requestVersion != SOCKS_VERSION) return;
            Target target = readTarget(input, addressType);
            int destinationPort = (readU8(input) << 8) | readU8(input);

            if (command == CMD_CONNECT) {
                handleConnect(client, input, output, target, destinationPort);
            } else if (command == CMD_UDP_ASSOCIATE) {
                handleUdpAssociate(client, input, output);
            } else {
                sendReply(output, 7, null, 0);
            }
        } catch (Throwable ignored) {
        } finally {
            closeQuietly(client);
        }
    }

    private void handleConnect(Socket client, InputStream clientInput, OutputStream clientOutput,
                               Target target, int destinationPort) throws IOException {
        if (destinationPort == 53 && isSyntheticDns(target)) {
            sendReply(clientOutput, 0, InetAddress.getByName("127.0.0.1"), 0);
            relayTcpDns(clientInput, clientOutput);
            return;
        }

        Network selected = chooseNetwork(target.host, target.address);
        InetAddress resolved = resolveTarget(target, selected);
        if (resolved == null) {
            sendReply(clientOutput, 4, null, 0);
            return;
        }

        Socket remote = null;
        try {
            remote = createSocket(selected);
            remote.setTcpNoDelay(true);
            remote.connect(new InetSocketAddress(resolved, destinationPort), 10000);
            SocketAddress local = remote.getLocalSocketAddress();
            InetAddress boundAddress = local instanceof InetSocketAddress
                    ? ((InetSocketAddress) local).getAddress() : null;
            int boundPort = local instanceof InetSocketAddress
                    ? ((InetSocketAddress) local).getPort() : 0;
            sendReply(clientOutput, 0, boundAddress, boundPort);
            copyBidirectional(client, remote);
        } catch (Throwable error) {
            try { sendReply(clientOutput, 5, null, 0); } catch (Throwable ignored) {}
        } finally {
            closeQuietly(remote);
        }
    }

    private void copyBidirectional(final Socket client, final Socket remote) throws InterruptedException {
        final Object lock = new Object();
        final int[] finished = new int[] { 0 };
        Runnable left = new Runnable() {
            @Override public void run() {
                try { copy(client.getInputStream(), remote.getOutputStream()); } catch (Throwable ignored) {}
                try { remote.shutdownOutput(); } catch (Throwable ignored) {}
                synchronized (lock) { finished[0]++; lock.notifyAll(); }
            }
        };
        Runnable right = new Runnable() {
            @Override public void run() {
                try { copy(remote.getInputStream(), client.getOutputStream()); } catch (Throwable ignored) {}
                try { client.shutdownOutput(); } catch (Throwable ignored) {}
                synchronized (lock) { finished[0]++; lock.notifyAll(); }
            }
        };
        workers.execute(left);
        workers.execute(right);
        synchronized (lock) {
            while (finished[0] < 2 && running) lock.wait(1000L);
        }
    }

    private void handleUdpAssociate(final Socket control, final InputStream controlInput,
                                    OutputStream output) throws IOException {
        final DatagramSocket relay = new DatagramSocket(new InetSocketAddress("127.0.0.1", 0));
        relay.setSoTimeout(1000);
        sendReply(output, 0, InetAddress.getByName("127.0.0.1"), relay.getLocalPort());

        Thread watcher = new Thread(new Runnable() {
            @Override public void run() {
                try { while (controlInput.read() >= 0) { } } catch (Throwable ignored) {}
                relay.close();
            }
        }, "ice-socks-udp-control");
        watcher.setDaemon(true);
        watcher.start();

        byte[] buffer = new byte[65535];
        while (running && !relay.isClosed()) {
            try {
                final DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
                relay.receive(incoming);
                final byte[] packet = Arrays.copyOfRange(incoming.getData(), incoming.getOffset(),
                        incoming.getOffset() + incoming.getLength());
                final InetSocketAddress clientAddress = new InetSocketAddress(incoming.getAddress(), incoming.getPort());
                workers.execute(new Runnable() {
                    @Override public void run() { processUdpPacket(relay, clientAddress, packet); }
                });
            } catch (SocketTimeoutException timeout) {
                // Memeriksa flag running setiap detik.
            } catch (SocketException closed) {
                break;
            }
        }
        relay.close();
    }

    private void processUdpPacket(DatagramSocket relay, InetSocketAddress clientAddress, byte[] packet) {
        DatagramSocket outgoing = null;
        try {
            UdpRequest request = parseUdpRequest(packet);
            if (request == null || request.fragment != 0) return;

            byte[] responseData;
            InetAddress responseAddress;
            int responsePort;
            if (request.port == 53 && isSyntheticDns(request.target)) {
                responseData = forwardDns(request.payload);
                if (responseData == null) return;
                responseAddress = syntheticDns;
                responsePort = 53;
            } else {
                Network selected = chooseNetwork(request.target.host, request.target.address);
                InetAddress destination = resolveTarget(request.target, selected);
                if (destination == null) return;
                outgoing = new DatagramSocket();
                outgoing.setSoTimeout(6000);
                bindDatagram(selected, outgoing);
                outgoing.send(new DatagramPacket(request.payload, request.payload.length, destination, request.port));
                byte[] remoteBuffer = new byte[65535];
                DatagramPacket remoteResponse = new DatagramPacket(remoteBuffer, remoteBuffer.length);
                outgoing.receive(remoteResponse);
                responseData = Arrays.copyOfRange(remoteResponse.getData(), remoteResponse.getOffset(),
                        remoteResponse.getOffset() + remoteResponse.getLength());
                responseAddress = remoteResponse.getAddress();
                responsePort = remoteResponse.getPort();
            }

            byte[] wrapped = buildUdpResponse(responseAddress, responsePort, responseData);
            synchronized (relay) {
                relay.send(new DatagramPacket(wrapped, wrapped.length, clientAddress));
            }
        } catch (Throwable ignored) {
        } finally {
            if (outgoing != null) outgoing.close();
        }
    }

    private void relayTcpDns(InputStream input, OutputStream output) throws IOException {
        while (running) {
            int high = input.read();
            if (high < 0) return;
            int low = input.read();
            if (low < 0) return;
            int length = (high << 8) | low;
            if (length <= 0 || length > 65535) return;
            byte[] query = new byte[length];
            readFully(input, query);
            byte[] response = forwardDns(query);
            if (response == null) return;
            output.write((response.length >>> 8) & 0xff);
            output.write(response.length & 0xff);
            output.write(response);
            output.flush();
        }
    }

    private byte[] forwardDns(byte[] query) {
        String qname = parseDnsQuestionName(query);
        Network preferred = isCompanyHost(qname) ? wifiNetwork : cellularNetwork;
        Network fallback = preferred == wifiNetwork ? cellularNetwork : wifiNetwork;
        byte[] response = queryDnsServers(query, preferred);
        if (response == null) response = queryDnsServers(query, fallback);
        return response;
    }

    private byte[] queryDnsServers(byte[] query, Network network) {
        List<InetAddress> servers = dnsServers(network);
        if (servers.isEmpty()) {
            try {
                if (network == cellularNetwork) {
                    servers.add(InetAddress.getByName("1.1.1.1"));
                    servers.add(InetAddress.getByName("8.8.8.8"));
                }
            } catch (Throwable ignored) {}
        }
        for (InetAddress server : servers) {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setSoTimeout(4000);
                bindDatagram(network, socket);
                socket.send(new DatagramPacket(query, query.length, server, 53));
                byte[] response = new byte[65535];
                DatagramPacket packet = new DatagramPacket(response, response.length);
                socket.receive(packet);
                return Arrays.copyOfRange(packet.getData(), packet.getOffset(), packet.getOffset() + packet.getLength());
            } catch (Throwable ignored) {
            } finally {
                if (socket != null) socket.close();
            }
        }
        return null;
    }

    private List<InetAddress> dnsServers(Network network) {
        List<InetAddress> result = new ArrayList<InetAddress>();
        if (network == null || connectivityManager == null) return result;
        try {
            LinkProperties properties = connectivityManager.getLinkProperties(network);
            if (properties != null) result.addAll(properties.getDnsServers());
        } catch (Throwable ignored) {}
        return result;
    }

    private Network chooseNetwork(String host, InetAddress address) {
        if (isCompanyHost(host) || isPrivateAddress(address)) {
            return wifiNetwork != null ? wifiNetwork : cellularNetwork;
        }
        return cellularNetwork != null ? cellularNetwork : wifiNetwork;
    }

    private InetAddress resolveTarget(Target target, Network network) {
        if (target.address != null) return target.address;
        if (target.host == null || target.host.length() == 0) return null;
        try {
            InetAddress[] addresses = network != null
                    ? network.getAllByName(target.host)
                    : InetAddress.getAllByName(target.host);
            for (InetAddress address : addresses) if (address instanceof Inet4Address) return address;
            return addresses.length > 0 ? addresses[0] : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Socket createSocket(Network network) throws IOException {
        return network == null ? new Socket() : network.getSocketFactory().createSocket();
    }

    private void bindDatagram(Network network, DatagramSocket socket) throws IOException {
        if (network != null && Build.VERSION.SDK_INT >= 22) network.bindSocket(socket);
    }

    private boolean isSyntheticDns(Target target) {
        return target != null && target.address != null && target.address.equals(syntheticDns);
    }

    private boolean isCompanyHost(String host) {
        String value = normalizeHost(host);
        if (value.length() == 0) return false;
        return value.equals(companyHost)
                || value.endsWith("." + companyHost)
                || value.equals(companySuffix)
                || value.endsWith("." + companySuffix);
    }

    private static boolean isPrivateAddress(InetAddress address) {
        if (address == null) return false;
        if (address.isAnyLocalAddress() || address.isLoopbackAddress() || address.isLinkLocalAddress()
                || address.isSiteLocalAddress()) return true;
        byte[] bytes = address.getAddress();
        if (address instanceof Inet4Address && bytes.length == 4) {
            int a = bytes[0] & 0xff;
            int b = bytes[1] & 0xff;
            return a == 10 || (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168);
        }
        if (address instanceof Inet6Address && bytes.length == 16) {
            return (bytes[0] & 0xfe) == 0xfc;
        }
        return false;
    }

    private static String normalizeHost(String host) {
        if (host == null) return "";
        String value = host.trim().toLowerCase(Locale.US);
        while (value.endsWith(".")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private static Target readTarget(InputStream input, int atyp) throws IOException {
        if (atyp == ATYP_IPV4) {
            byte[] bytes = new byte[4];
            readFully(input, bytes);
            InetAddress address = InetAddress.getByAddress(bytes);
            return new Target(address.getHostAddress(), address);
        }
        if (atyp == ATYP_DOMAIN) {
            int length = readU8(input);
            byte[] bytes = new byte[length];
            readFully(input, bytes);
            return new Target(new String(bytes, UTF8), null);
        }
        if (atyp == ATYP_IPV6) {
            byte[] bytes = new byte[16];
            readFully(input, bytes);
            InetAddress address = InetAddress.getByAddress(bytes);
            return new Target(address.getHostAddress(), address);
        }
        throw new IOException("ATYP tidak didukung");
    }

    private static void sendReply(OutputStream output, int reply, InetAddress address, int port) throws IOException {
        byte[] addr = address == null ? new byte[] {0, 0, 0, 0} : address.getAddress();
        if (addr.length != 4 && addr.length != 16) addr = new byte[] {0, 0, 0, 0};
        output.write(5);
        output.write(reply);
        output.write(0);
        output.write(addr.length == 16 ? ATYP_IPV6 : ATYP_IPV4);
        output.write(addr);
        output.write((port >>> 8) & 0xff);
        output.write(port & 0xff);
        output.flush();
    }

    private static UdpRequest parseUdpRequest(byte[] packet) throws IOException {
        if (packet == null || packet.length < 10) return null;
        int position = 0;
        if (packet[position++] != 0 || packet[position++] != 0) return null;
        int fragment = packet[position++] & 0xff;
        int atyp = packet[position++] & 0xff;
        Target target;
        if (atyp == ATYP_IPV4) {
            if (position + 4 > packet.length) return null;
            byte[] address = Arrays.copyOfRange(packet, position, position + 4);
            position += 4;
            InetAddress inet = InetAddress.getByAddress(address);
            target = new Target(inet.getHostAddress(), inet);
        } else if (atyp == ATYP_DOMAIN) {
            if (position >= packet.length) return null;
            int length = packet[position++] & 0xff;
            if (position + length > packet.length) return null;
            target = new Target(new String(packet, position, length, UTF8), null);
            position += length;
        } else if (atyp == ATYP_IPV6) {
            if (position + 16 > packet.length) return null;
            byte[] address = Arrays.copyOfRange(packet, position, position + 16);
            position += 16;
            InetAddress inet = InetAddress.getByAddress(address);
            target = new Target(inet.getHostAddress(), inet);
        } else {
            return null;
        }
        if (position + 2 > packet.length) return null;
        int port = ((packet[position++] & 0xff) << 8) | (packet[position++] & 0xff);
        byte[] payload = Arrays.copyOfRange(packet, position, packet.length);
        return new UdpRequest(fragment, target, port, payload);
    }

    private static byte[] buildUdpResponse(InetAddress address, int port, byte[] payload) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(payload.length + 24);
        output.write(0); output.write(0); output.write(0);
        byte[] bytes = address == null ? new byte[] {0, 0, 0, 0} : address.getAddress();
        output.write(bytes.length == 16 ? ATYP_IPV6 : ATYP_IPV4);
        output.write(bytes);
        output.write((port >>> 8) & 0xff);
        output.write(port & 0xff);
        output.write(payload);
        return output.toByteArray();
    }

    private static String parseDnsQuestionName(byte[] query) {
        if (query == null || query.length < 13) return "";
        int position = 12;
        StringBuilder name = new StringBuilder();
        try {
            while (position < query.length) {
                int length = query[position++] & 0xff;
                if (length == 0) break;
                if ((length & 0xc0) != 0 || position + length > query.length) return "";
                if (name.length() > 0) name.append('.');
                name.append(new String(query, position, length, UTF8));
                position += length;
            }
        } catch (Throwable ignored) { return ""; }
        return normalizeHost(name.toString());
    }

    private static int readU8(InputStream input) throws IOException {
        int value = input.read();
        if (value < 0) throw new EOFException();
        return value;
    }

    private static void readFully(InputStream input, byte[] data) throws IOException {
        int offset = 0;
        while (offset < data.length) {
            int count = input.read(data, offset, data.length - offset);
            if (count < 0) throw new EOFException();
            offset += count;
        }
    }

    private static void copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[32768];
        int count;
        while ((count = input.read(buffer)) >= 0) {
            if (count == 0) continue;
            output.write(buffer, 0, count);
            output.flush();
        }
    }

    private static void closeQuietly(Socket socket) {
        if (socket == null) return;
        try { socket.close(); } catch (IOException ignored) {}
    }

    private static void sleepQuietly(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    private static final class Target {
        final String host;
        final InetAddress address;
        Target(String host, InetAddress address) { this.host = host; this.address = address; }
    }

    private static final class UdpRequest {
        final int fragment;
        final Target target;
        final int port;
        final byte[] payload;
        UdpRequest(int fragment, Target target, int port, byte[] payload) {
            this.fragment = fragment; this.target = target; this.port = port; this.payload = payload;
        }
    }
}
