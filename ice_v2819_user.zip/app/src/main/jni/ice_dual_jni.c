#include <jni.h>

int hev_socks5_tunnel_main_from_file(const char *config_path, int tun_fd);
void hev_socks5_tunnel_quit(void);

JNIEXPORT jint JNICALL
Java_com_mimar_iceinject_DualNetworkVpnService_nativeRun(
        JNIEnv *env, jclass clazz, jstring config_path, jint tun_fd) {
    (void) clazz;
    if (config_path == NULL) return -1;
    const char *path = (*env)->GetStringUTFChars(env, config_path, NULL);
    if (path == NULL) return -1;
    int result = hev_socks5_tunnel_main_from_file(path, (int) tun_fd);
    (*env)->ReleaseStringUTFChars(env, config_path, path);
    return (jint) result;
}

JNIEXPORT void JNICALL
Java_com_mimar_iceinject_DualNetworkVpnService_nativeStop(JNIEnv *env, jclass clazz) {
    (void) env;
    (void) clazz;
    hev_socks5_tunnel_quit();
}
