# Simpan path JNI aplikasi sebelum memasukkan Android.mk milik dependensi.
# Android.mk Hev dan submodulnya mengubah LOCAL_PATH/TOP_PATH secara global.
ICE_APP_JNI_PATH := $(call my-dir)
ICE_HEV_PATH := $(ICE_APP_JNI_PATH)/hev-socks5-tunnel

include $(ICE_HEV_PATH)/Android.mk

# Pulihkan path aplikasi agar ice_dual_jni.c tidak dicari di build/core milik NDK.
LOCAL_PATH := $(ICE_APP_JNI_PATH)
include $(CLEAR_VARS)
LOCAL_MODULE := ice-dual-jni
LOCAL_SRC_FILES := ice_dual_jni.c
LOCAL_C_INCLUDES := $(ICE_HEV_PATH)/src
LOCAL_SHARED_LIBRARIES := hev-socks5-tunnel
LOCAL_LDLIBS := -llog
LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384
LOCAL_LDFLAGS += -Wl,-z,common-page-size=16384
include $(BUILD_SHARED_LIBRARY)
