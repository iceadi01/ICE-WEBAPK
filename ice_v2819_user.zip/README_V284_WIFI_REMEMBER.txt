ICE Inject v2.8.4 — Wi-Fi kerja diingat otomatis

Perubahan:
- Tekan singkat badge jaringan: langsung menyambungkan memakai SSID/password yang sudah pernah disimpan di ICE.
- Tahan badge jaringan: membuka pengaturan untuk mengganti SSID/password.
- Otomatis mencoba menyambung kembali saat aplikasi dibuka atau kembali aktif.
- Password cukup dimasukkan satu kali di ICE.

Batas Android:
- APK biasa tidak dapat membaca password Wi-Fi yang disimpan oleh menu Pengaturan Android.
- Karena itu, untuk Wi-Fi yang belum pernah disimpan oleh ICE, password tetap harus dimasukkan satu kali.
- Setelah itu tidak perlu diketik lagi selama data aplikasi tidak dihapus/uninstall.
