ICE Inject v2.8.19 — VPN Engine Update + Crash Diagnostic

- Basis fitur browser tetap v2.8.9.
- Split VPN non-root untuk Chrome/browser lain.
- Workflow memakai HevSocks5Tunnel 2.15.0 resmi.
- Android 11+ membaca ApplicationExitInfo untuk membedakan crash native, crash Java, ANR, low memory, dan signal.
- Crash Java proses :dualvpn disimpan ke file internal dan ditampilkan setelah ICE dibuka kembali.
- Log Hev dibuat debug selama tahap diagnosis.
- MTU diturunkan ke 1400 untuk kompatibilitas perangkat/ROM.
