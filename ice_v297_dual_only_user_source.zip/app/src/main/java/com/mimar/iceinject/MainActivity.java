package com.mimar.iceinject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class MainActivity extends Activity {
    // Diganti otomatis saat build admin/user.
    private static final boolean ADMIN_BUILD = false;

    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_URL = "company_url";
    private static final String PREF_LICENSE_SERVER = "license_server";
    private static final String PREF_LICENSE_KEY = "license_key";
    private static final String PREF_LICENSE_TOKEN = "license_token";
    private static final String PREF_LICENSE_EXPIRY = "license_expiry_ms";
    private static final String PREF_LICENSE_CREATED = "license_created_ms";
    private static final String PREF_LICENSE_DURATION_LABEL = "license_duration_label";
    private static final String PREF_LAST_SERVER_TIME = "last_server_time_ms";
    private static final String PREF_LAST_SERVER_ELAPSED = "last_server_elapsed_ms";
    private static final String PREF_LAST_CHECK = "last_license_check_ms";
    private static final String PREF_DEVICE_ID = "device_id_fallback";
    private static final String PREF_BOOKMARKS = "browser_bookmarks";
    private static final String PREF_DESKTOP_MODE = "desktop_mode";
    private static final String PREF_WORK_WIFI_SSID = "work_wifi_ssid";
    private static final String PREF_WORK_WIFI_PASSWORD = "work_wifi_password";
    private static final String PREF_WORK_WIFI_AUTO = "work_wifi_auto";

    private static final String DEFAULT_URL = "https://lp4m-lpw.liebrapermana.com";
    private static final String DEFAULT_LICENSE_SERVER = "https://accuracy.fwh.is";
    private static final String APP_VERSION = "2.9.7";
    // Mode kerja: boleh tetap masuk di WiFi lokal tanpa internet jika lisensi sudah pernah valid online.
    // Batas ini tidak memperpanjang masa key; tetap mengikuti expired dari server.
    private static final long OFFLINE_WORK_GRACE_MS = 18L * 60L * 60L * 1000L;
    private static final long LICENSE_CHECK_INTERVAL_MS = 15000L;
    private static final int CAMERA_PERMISSION_REQUEST = 42;
    private static final int LOCATION_PERMISSION_REQUEST = 43;

    private SharedPreferences preferences;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private LinearLayout tabBar;
    private EditText addressInput;
    private ModernIconView securityIcon;
    private ModernIconView reloadButton;
    private Button bookmarkButton;
    private TextView tabsButton;
    private ProgressBar pageProgress;
    private boolean pageLoading = false;
    private FrameLayout webContainer;
    private LinearLayout toolsPanel;
    private TextView statusText;
    private TextView licenseBadge;
    private TextView networkBadge;


    private final List<TabState> tabs = new ArrayList<TabState>();
    private TabState currentTab;
    private int nextTabNumber = 1;
    private boolean browserStarted = false;
    private boolean licenseUnlocked = ADMIN_BUILD;
    private boolean licenseCheckInProgress = false;

    // Dual network: LP4M memakai Wi-Fi perusahaan, sedangkan login/lisensi dan web umum memakai data seluler.
    private ConnectivityManager connectivityManager;
    private Network wifiNetwork;
    private Network observedWifiNetwork;
    private Network localOnlyWifiNetwork;
    private Network cellularNetwork;
    private Network boundNetwork;
    private ConnectivityManager.NetworkCallback wifiNetworkCallback;
    private ConnectivityManager.NetworkCallback cellularNetworkCallback;
    private ConnectivityManager.NetworkCallback localOnlyWifiCallback;
    private boolean networkCallbacksRegistered = false;
    private boolean localOnlyWifiRequestActive = false;
    private boolean pendingWorkWifiPermission = false;
    private int internetRouteDepth = 0;
    private boolean lastCompanyWifiMissing = false;
    private String runtimeUsername = "";
    private String runtimeSessionToken = "";
    private long runtimeSessionExpiry = 0L;
    private final Runnable licenseWatchdog = new Runnable() {
        @Override
        public void run() {
            if (!ADMIN_BUILD) {
                if (licenseUnlocked) {
                    // Mode kerja: saat aplikasi dipakai tetap cek server berkala jika internet tersedia.
                    // Jika sedang WiFi lokal tanpa internet, cache aktif diberi toleransi terbatas.
                    validateLicenseAsync(false);
                } else {
                    // sedang terkunci, jangan munculkan dialog berulang.
                }
                handler.postDelayed(this, LICENSE_CHECK_INTERVAL_MS);
            }
        }
    };
    private PermissionRequest pendingPermissionRequest;
    private GeolocationPermissions.Callback pendingGeolocationCallback;
    private String pendingGeolocationOrigin;

    private static class TabState {
        int number;
        WebView webView;
        Button button;
        String title;
        String currentUrl;
        boolean destroyed;
    }

    private static class BookmarkItem {
        String name;
        String url;

        BookmarkItem(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }


    /** Ikon vektor ringan yang digambar langsung agar konsisten pada semua perangkat. */
    private class ModernIconView extends View {
        private String iconName;
        private int iconColor;
        private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ModernIconView(Context context, String iconName, int iconColor) {
            super(context);
            this.iconName = iconName == null ? "" : iconName;
            this.iconColor = iconColor;
            setClickable(true);
            setFocusable(true);
        }

        void setIcon(String iconName) {
            this.iconName = iconName == null ? "" : iconName;
            invalidate();
        }

        void setIconColor(int color) {
            this.iconColor = color;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float size = Math.min(w, h);
            float cx = w / 2f;
            float cy = h / 2f;
            float r = size * 0.26f;

            iconPaint.reset();
            iconPaint.setAntiAlias(true);
            iconPaint.setColor(iconColor);
            iconPaint.setStrokeWidth(Math.max(dp(1), size * 0.055f));
            iconPaint.setStrokeCap(Paint.Cap.ROUND);
            iconPaint.setStrokeJoin(Paint.Join.ROUND);
            iconPaint.setStyle(Paint.Style.STROKE);

            String n = iconName == null ? "" : iconName;
            if ("home".equals(n) || "home_settings".equals(n)) {
                Path p = new Path();
                p.moveTo(cx - r, cy - r * 0.10f);
                p.lineTo(cx, cy - r * 0.92f);
                p.lineTo(cx + r, cy - r * 0.10f);
                p.moveTo(cx - r * 0.72f, cy - r * 0.02f);
                p.lineTo(cx - r * 0.72f, cy + r * 0.85f);
                p.lineTo(cx + r * 0.72f, cy + r * 0.85f);
                p.lineTo(cx + r * 0.72f, cy - r * 0.02f);
                canvas.drawPath(p, iconPaint);
                if ("home_settings".equals(n)) {
                    iconPaint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx + r * 0.72f, cy + r * 0.65f, r * 0.28f, iconPaint);
                    iconPaint.setColor(Color.WHITE);
                    canvas.drawCircle(cx + r * 0.72f, cy + r * 0.65f, r * 0.10f, iconPaint);
                }
            } else if ("reload".equals(n)) {
                RectF arc = new RectF(cx - r, cy - r, cx + r, cy + r);
                canvas.drawArc(arc, -55, 285, false, iconPaint);
                Path head = new Path();
                head.moveTo(cx + r * 0.63f, cy - r * 0.84f);
                head.lineTo(cx + r * 0.98f, cy - r * 0.78f);
                head.lineTo(cx + r * 0.86f, cy - r * 0.43f);
                canvas.drawPath(head, iconPaint);
            } else if ("close".equals(n)) {
                canvas.drawLine(cx - r * 0.72f, cy - r * 0.72f, cx + r * 0.72f, cy + r * 0.72f, iconPaint);
                canvas.drawLine(cx + r * 0.72f, cy - r * 0.72f, cx - r * 0.72f, cy + r * 0.72f, iconPaint);
            } else if ("menu".equals(n)) {
                iconPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy - r * 0.72f, r * 0.14f, iconPaint);
                canvas.drawCircle(cx, cy, r * 0.14f, iconPaint);
                canvas.drawCircle(cx, cy + r * 0.72f, r * 0.14f, iconPaint);
            } else if ("back".equals(n) || "forward".equals(n)) {
                boolean isBack = "back".equals(n);
                Path p = new Path();
                if (isBack) {
                    p.moveTo(cx + r * 0.58f, cy - r * 0.72f);
                    p.lineTo(cx - r * 0.22f, cy);
                    p.lineTo(cx + r * 0.58f, cy + r * 0.72f);
                } else {
                    p.moveTo(cx - r * 0.58f, cy - r * 0.72f);
                    p.lineTo(cx + r * 0.22f, cy);
                    p.lineTo(cx - r * 0.58f, cy + r * 0.72f);
                }
                canvas.drawPath(p, iconPaint);
            } else if ("plus".equals(n)) {
                canvas.drawLine(cx - r * 0.78f, cy, cx + r * 0.78f, cy, iconPaint);
                canvas.drawLine(cx, cy - r * 0.78f, cx, cy + r * 0.78f, iconPaint);
            } else if ("keyboard".equals(n)) {
                RectF box = new RectF(cx - r * 1.16f, cy - r * 0.74f, cx + r * 1.16f, cy + r * 0.74f);
                canvas.drawRoundRect(box, r * 0.16f, r * 0.16f, iconPaint);
                iconPaint.setStyle(Paint.Style.FILL);
                float dot = r * 0.10f;
                for (int yy = -1; yy <= 0; yy++) {
                    for (int xx = -2; xx <= 2; xx++) {
                        canvas.drawCircle(cx + xx * r * 0.36f, cy + yy * r * 0.34f, dot, iconPaint);
                    }
                }
                canvas.drawRoundRect(new RectF(cx - r * 0.65f, cy + r * 0.30f, cx + r * 0.65f, cy + r * 0.44f), dot, dot, iconPaint);
            } else if ("tabs".equals(n)) {
                RectF a = new RectF(cx - r * 0.98f, cy - r * 0.52f, cx + r * 0.50f, cy + r * 0.88f);
                RectF b = new RectF(cx - r * 0.50f, cy - r * 0.90f, cx + r * 0.98f, cy + r * 0.50f);
                canvas.drawRoundRect(b, r * 0.18f, r * 0.18f, iconPaint);
                canvas.drawRoundRect(a, r * 0.18f, r * 0.18f, iconPaint);
            } else if ("grid".equals(n)) {
                float q = r * 0.72f;
                float gap = r * 0.22f;
                canvas.drawRoundRect(new RectF(cx-q-gap/2, cy-q-gap/2, cx-gap/2, cy-gap/2), r*.10f,r*.10f,iconPaint);
                canvas.drawRoundRect(new RectF(cx+gap/2, cy-q-gap/2, cx+q+gap/2, cy-gap/2), r*.10f,r*.10f,iconPaint);
                canvas.drawRoundRect(new RectF(cx-q-gap/2, cy+gap/2, cx-gap/2, cy+q+gap/2), r*.10f,r*.10f,iconPaint);
                canvas.drawRoundRect(new RectF(cx+gap/2, cy+gap/2, cx+q+gap/2, cy+q+gap/2), r*.10f,r*.10f,iconPaint);
            } else if ("search".equals(n)) {
                canvas.drawCircle(cx - r * 0.18f, cy - r * 0.18f, r * 0.62f, iconPaint);
                canvas.drawLine(cx + r * 0.28f, cy + r * 0.28f, cx + r * 0.92f, cy + r * 0.92f, iconPaint);
            } else if ("bookmark".equals(n)) {
                Path p = new Path();
                p.moveTo(cx - r * 0.66f, cy - r);
                p.lineTo(cx + r * 0.66f, cy - r);
                p.lineTo(cx + r * 0.66f, cy + r);
                p.lineTo(cx, cy + r * 0.55f);
                p.lineTo(cx - r * 0.66f, cy + r);
                p.close();
                canvas.drawPath(p, iconPaint);
            } else if ("star".equals(n)) {
                Path p = new Path();
                for (int i = 0; i < 10; i++) {
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    float rr = (i % 2 == 0) ? r : r * 0.43f;
                    float x = cx + (float)Math.cos(a) * rr;
                    float y = cy + (float)Math.sin(a) * rr;
                    if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
                canvas.drawPath(p, iconPaint);
            } else if ("download".equals(n) || "save".equals(n)) {
                canvas.drawLine(cx, cy - r, cx, cy + r * 0.45f, iconPaint);
                canvas.drawLine(cx - r * 0.48f, cy, cx, cy + r * 0.48f, iconPaint);
                canvas.drawLine(cx + r * 0.48f, cy, cx, cy + r * 0.48f, iconPaint);
                canvas.drawLine(cx - r * 0.82f, cy + r * 0.88f, cx + r * 0.82f, cy + r * 0.88f, iconPaint);
            } else if ("copy".equals(n)) {
                canvas.drawRoundRect(new RectF(cx-r*.80f, cy-r*.55f, cx+r*.55f, cy+r*.85f), r*.12f,r*.12f,iconPaint);
                canvas.drawRoundRect(new RectF(cx-r*.42f, cy-r*.90f, cx+r*.92f, cy+r*.48f), r*.12f,r*.12f,iconPaint);
            } else if ("share".equals(n)) {
                iconPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx-r*.72f, cy, r*.20f, iconPaint);
                canvas.drawCircle(cx+r*.66f, cy-r*.62f, r*.20f, iconPaint);
                canvas.drawCircle(cx+r*.66f, cy+r*.62f, r*.20f, iconPaint);
                iconPaint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx-r*.52f, cy-r*.06f, cx+r*.46f, cy-r*.52f, iconPaint);
                canvas.drawLine(cx-r*.52f, cy+r*.06f, cx+r*.46f, cy+r*.52f, iconPaint);
            } else if ("edit".equals(n)) {
                Path p = new Path();
                p.moveTo(cx-r*.72f, cy+r*.72f);
                p.lineTo(cx-r*.55f, cy+r*.10f);
                p.lineTo(cx+r*.48f, cy-r*.92f);
                p.lineTo(cx+r*.90f, cy-r*.50f);
                p.lineTo(cx-r*.12f, cy+r*.53f);
                p.close();
                canvas.drawPath(p, iconPaint);
                canvas.drawLine(cx-r*.68f, cy+r*.78f, cx-r*.18f, cy+r*.62f, iconPaint);
            } else if ("desktop".equals(n)) {
                canvas.drawRoundRect(new RectF(cx-r, cy-r*.78f, cx+r, cy+r*.50f), r*.12f,r*.12f,iconPaint);
                canvas.drawLine(cx, cy+r*.50f, cx, cy+r*.90f, iconPaint);
                canvas.drawLine(cx-r*.52f, cy+r*.90f, cx+r*.52f, cy+r*.90f, iconPaint);
            } else if ("shield".equals(n)) {
                Path p = new Path();
                p.moveTo(cx, cy-r);
                p.lineTo(cx+r*.78f, cy-r*.68f);
                p.lineTo(cx+r*.64f, cy+r*.44f);
                p.quadTo(cx, cy+r*1.05f, cx-r*.64f, cy+r*.44f);
                p.lineTo(cx-r*.78f, cy-r*.68f);
                p.close();
                canvas.drawPath(p, iconPaint);
                canvas.drawCircle(cx, cy-r*.05f, r*.15f, iconPaint);
                canvas.drawLine(cx, cy+r*.10f, cx, cy+r*.42f, iconPaint);
            } else if ("history".equals(n)) {
                RectF arc = new RectF(cx-r, cy-r, cx+r, cy+r);
                canvas.drawArc(arc, -65, 300, false, iconPaint);
                canvas.drawLine(cx-r*.70f, cy-r*.74f, cx-r*1.04f, cy-r*.72f, iconPaint);
                canvas.drawLine(cx-r*.70f, cy-r*.74f, cx-r*.76f, cy-r*.40f, iconPaint);
                canvas.drawLine(cx, cy-r*.50f, cx, cy+r*.08f, iconPaint);
                canvas.drawLine(cx, cy+r*.08f, cx+r*.44f, cy+r*.34f, iconPaint);
            } else if ("lock".equals(n)) {
                RectF body = new RectF(cx-r*.78f, cy-r*.10f, cx+r*.78f, cy+r*.90f);
                canvas.drawRoundRect(body, r*.16f,r*.16f,iconPaint);
                RectF shackle = new RectF(cx-r*.48f, cy-r*.90f, cx+r*.48f, cy+r*.20f);
                canvas.drawArc(shackle, 180, 180, false, iconPaint);
            } else if ("settings".equals(n)) {
                canvas.drawCircle(cx, cy, r*.44f, iconPaint);
                canvas.drawCircle(cx, cy, r*.92f, iconPaint);
                for (int i=0;i<8;i++) {
                    double a=i*Math.PI/4;
                    canvas.drawLine(cx+(float)Math.cos(a)*r*.92f, cy+(float)Math.sin(a)*r*.92f,
                            cx+(float)Math.cos(a)*r*1.12f, cy+(float)Math.sin(a)*r*1.12f, iconPaint);
                }
            } else if ("info".equals(n)) {
                canvas.drawCircle(cx, cy, r, iconPaint);
                iconPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy-r*.44f, r*.10f, iconPaint);
                canvas.drawRoundRect(new RectF(cx-r*.10f, cy-r*.12f, cx+r*.10f, cy+r*.58f), r*.10f,r*.10f,iconPaint);
            } else {
                iconPaint.setStyle(Paint.Style.FILL);
                iconPaint.setTextAlign(Paint.Align.CENTER);
                iconPaint.setTextSize(size * .42f);
                canvas.drawText(n.length() > 0 ? n.substring(0, 1) : "•", cx, cy + size * .15f, iconPaint);
            }
        }
    }

    private interface ApiCallback {
        void onResult(boolean success, JSONObject data, String error);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method status = Window.class.getMethod("setStatusBarColor", int.class);
                status.invoke(getWindow(), Color.rgb(7, 11, 19));
                Method navigation = Window.class.getMethod("setNavigationBarColor", int.class);
                navigation.invoke(getWindow(), Color.rgb(7, 11, 19));
            } catch (Throwable ignored) {}
        }

        preferences = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        buildInterface();
        initializeDualNetworkRouting();
        requestCameraPermissionIfNeeded();

        if (ADMIN_BUILD) {
            licenseUnlocked = true;
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            startBrowserIfNeeded();
        } else {
            // v2.8.0: mode login user/password.
            // Setiap aplikasi dibuka dari awal harus login online lagi. Sesi hanya disimpan di memori saat APK masih hidup.
            licenseUnlocked = false;
            runtimeUsername = "";
            runtimeSessionToken = "";
            runtimeSessionExpiry = 0L;
            setLicenseBadge("LOGIN", Color.rgb(202, 138, 4));
            if (preferences.getString(PREF_LICENSE_SERVER, "").length() == 0) {
                preferences.edit().putString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER).apply();
            }
            preferences.edit()
                    .remove(PREF_LICENSE_TOKEN)
                    .remove(PREF_LICENSE_EXPIRY)
                    .remove(PREF_LICENSE_CREATED)
                    .putLong(PREF_LAST_CHECK, 0L)
                    .apply();
            showActivationDialog(true);
        }
        startLicenseWatchdog();
    }

    private void buildInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 11, 19));

        // Bilah browser modern: ikon vektor konsisten dan kapsul alamat yang stabil.
        LinearLayout browserBar = new LinearLayout(this);
        browserBar.setOrientation(LinearLayout.HORIZONTAL);
        browserBar.setGravity(Gravity.CENTER_VERTICAL);
        browserBar.setPadding(dp(9), dp(8), dp(8), dp(8));
        GradientDrawable toolbarBackground = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { Color.rgb(8, 12, 20), Color.rgb(19, 25, 36) });
        browserBar.setBackground(toolbarBackground);

        ModernIconView homeTop = modernIconButton("home", Color.rgb(234, 238, 246),
                Color.rgb(24, 31, 44), dp(22));
        homeTop.setContentDescription("Beranda");
        homeTop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goHome(); }
        });
        browserBar.addView(homeTop, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout addressCapsule = new LinearLayout(this);
        addressCapsule.setOrientation(LinearLayout.HORIZONTAL);
        addressCapsule.setGravity(Gravity.CENTER_VERTICAL);
        addressCapsule.setPadding(dp(7), 0, dp(3), 0);
        addressCapsule.setBackground(makeRoundedStroke(
                Color.rgb(21, 27, 39), dp(27), Color.rgb(50, 61, 79), dp(1)));

        securityIcon = modernIconButton("lock", Color.rgb(103, 214, 145),
                Color.TRANSPARENT, dp(18));
        securityIcon.setContentDescription("Keamanan halaman");
        securityIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPageInfo();
            }
        });
        addressCapsule.addView(securityIcon, new LinearLayout.LayoutParams(dp(30), dp(46)));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextColor(Color.rgb(241, 243, 244));
        addressInput.setHintTextColor(Color.rgb(178, 183, 194));
        addressInput.setTextSize(16);
        addressInput.setHint("Cari atau ketik alamat web");
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setPadding(dp(2), 0, dp(3), 0);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                navigateAddressBar();
                return true;
            }
        });
        addressCapsule.addView(addressInput, new LinearLayout.LayoutParams(0, dp(48), 1));

        reloadButton = modernIconButton("reload", Color.rgb(153, 180, 234),
                Color.TRANSPARENT, dp(20));
        reloadButton.setContentDescription("Muat ulang");
        reloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab == null) return;
                if (pageLoading) {
                    currentTab.webView.stopLoading();
                } else {
                    reloadCurrentTabRouted();
                }
            }
        });
        addressCapsule.addView(reloadButton, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout.LayoutParams capsuleParams = new LinearLayout.LayoutParams(0, dp(50), 1);
        capsuleParams.setMargins(dp(5), 0, dp(7), 0);
        browserBar.addView(addressCapsule, capsuleParams);

        // Bookmark tetap tersedia dari menu, dan objek ini dipertahankan untuk indikator status.
        bookmarkButton = toolbarButton("☆");
        bookmarkButton.setVisibility(View.GONE);

        tabsButton = new TextView(this);
        tabsButton.setText("1");
        tabsButton.setTextSize(14);
        tabsButton.setTextColor(Color.rgb(238, 242, 249));
        tabsButton.setGravity(Gravity.CENTER);
        tabsButton.setTypeface(null, android.graphics.Typeface.BOLD);
        tabsButton.setBackground(makeRoundedStroke(
                Color.rgb(24, 27, 33), dp(9), Color.rgb(218, 220, 224), dp(2)));
        tabsButton.setContentDescription("Daftar tab");
        tabsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTabsDialog();
            }
        });
        LinearLayout.LayoutParams tabsParams = new LinearLayout.LayoutParams(dp(42), dp(38));
        tabsParams.setMargins(0, 0, dp(2), 0);
        browserBar.addView(tabsButton, tabsParams);

        ModernIconView menuButton = modernIconButton("menu", Color.rgb(234, 238, 246),
                Color.rgb(24, 31, 44), dp(22));
        menuButton.setContentDescription("Menu browser");
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBrowserMenu();
            }
        });
        LinearLayout.LayoutParams menuParams = new LinearLayout.LayoutParams(dp(46), dp(46));
        menuParams.setMargins(dp(3), 0, 0, 0);
        browserBar.addView(menuButton, menuParams);

        root.addView(browserBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(66)));

        pageProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100);
        pageProgress.setProgress(0);
        pageProgress.setVisibility(View.GONE);
        try {
            pageProgress.getProgressDrawable().setColorFilter(
                    Color.rgb(26, 115, 232), PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {}
        root.addView(pageProgress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(2)));

        // Dipertahankan secara internal untuk kompatibilitas, tetapi tab dibuka lewat tombol jumlah tab.
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setVisibility(View.GONE);

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.rgb(7, 11, 19));
        root.addView(webContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        // Panel status ringkas untuk routing dual jaringan.
        toolsPanel = new LinearLayout(this);
        toolsPanel.setOrientation(LinearLayout.HORIZONTAL);
        toolsPanel.setGravity(Gravity.CENTER_VERTICAL);
        toolsPanel.setPadding(dp(12), dp(7), dp(12), dp(7));
        toolsPanel.setBackground(makeRoundedStroke(Color.rgb(15, 23, 42), dp(18),
                Color.rgb(49, 62, 84), dp(1)));
        if (Build.VERSION.SDK_INT >= 21) toolsPanel.setElevation(dp(8));

        statusText = new TextView(this);
        statusText.setText("ICE Dual siap");
        statusText.setTextColor(Color.rgb(203, 213, 225));
        statusText.setTextSize(12);
        statusText.setSingleLine(true);
        toolsPanel.addView(statusText, new LinearLayout.LayoutParams(0, dp(34), 1));

        networkBadge = new TextView(this);
        networkBadge.setText("JARINGAN");
        networkBadge.setTextColor(Color.WHITE);
        networkBadge.setTextSize(10);
        networkBadge.setGravity(Gravity.CENTER);
        networkBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        networkBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        networkBadge.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { handleNetworkBadgeClick(); }
        });
        networkBadge.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                showDualNetworkInfo();
                return true;
            }
        });
        LinearLayout.LayoutParams networkParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        networkParams.setMargins(0, 0, dp(6), 0);
        toolsPanel.addView(networkBadge, networkParams);

        licenseBadge = new TextView(this);
        licenseBadge.setText("LISENSI");
        licenseBadge.setTextColor(Color.WHITE);
        licenseBadge.setTextSize(10);
        licenseBadge.setGravity(Gravity.CENTER);
        licenseBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        licenseBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        toolsPanel.addView(licenseBadge);

        LinearLayout.LayoutParams toolsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        toolsParams.setMargins(dp(10), dp(6), dp(10), dp(3));
        root.addView(toolsPanel, toolsParams);

        // Navigasi bawah modern: kapsul mengambang dengan ikon vektor seragam.
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(6), dp(4), dp(6), dp(4));
        bottomBar.setBackground(makeRoundedStroke(Color.rgb(14, 19, 29), dp(24),
                Color.rgb(39, 49, 66), dp(1)));
        if (Build.VERSION.SDK_INT >= 21) bottomBar.setElevation(dp(14));

        ModernIconView backButton = bottomNavButton("back", "Kembali");
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoBack()) currentTab.webView.goBack();
            }
        });
        bottomBar.addView(backButton, new LinearLayout.LayoutParams(0, dp(50), 1));

        ModernIconView forwardButton = bottomNavButton("forward", "Maju");
        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoForward()) currentTab.webView.goForward();
            }
        });
        bottomBar.addView(forwardButton, new LinearLayout.LayoutParams(0, dp(50), 1));

        ModernIconView homeButton = bottomNavButton("home", "Beranda");
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goHome(); }
        });
        bottomBar.addView(homeButton, new LinearLayout.LayoutParams(0, dp(50), 1));

        ModernIconView newTabButton = bottomNavButton("plus", "Tab baru");
        newTabButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!licenseUnlocked) { showActivationDialog(true); return; }
                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            }
        });
        bottomBar.addView(newTabButton, new LinearLayout.LayoutParams(0, dp(50), 1));


        LinearLayout.LayoutParams bottomParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        bottomParams.setMargins(dp(10), dp(4), dp(10), dp(6));
        root.addView(bottomBar, bottomParams);


        setContentView(root);
    }


    private void initializeDualNetworkRouting() {
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) {
                updateNetworkBadge();
                return;
            }

            discoverExistingNetworks();

            // Hanya memantau Wi-Fi biasa. Jangan request Wi-Fi generik karena itu dapat
            // membuat Wi-Fi perusahaan tetap menjadi jalur utama seluruh HP.
            NetworkRequest wifiRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            wifiNetworkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    observedWifiNetwork = network;
                    if (localOnlyWifiNetwork == null) wifiNetwork = network;
                    lastCompanyWifiMissing = false;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(observedWifiNetwork)) observedWifiNetwork = null;
                    if (localOnlyWifiNetwork == null && network != null && network.equals(wifiNetwork)) {
                        wifiNetwork = null;
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        observedWifiNetwork = network;
                        if (localOnlyWifiNetwork == null) wifiNetwork = network;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshNetworkRoute();
                            }
                        });
                    }
                }
            };

            NetworkRequest cellularRequest = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            cellularNetworkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    cellularNetwork = network;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(cellularNetwork)) cellularNetwork = null;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                        }
                    });
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        cellularNetwork = network;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                refreshNetworkRoute();
                            }
                        });
                    }
                }
            };

            connectivityManager.registerNetworkCallback(wifiRequest, wifiNetworkCallback);
            // Menahan radio seluler untuk proses ICE. Ini tidak mengubah jalur aplikasi lain,
            // tetapi membantu data tetap siap saat koneksi Wi-Fi khusus aktif.
            connectivityManager.requestNetwork(cellularRequest, cellularNetworkCallback);
            networkCallbacksRegistered = true;
        } catch (Throwable error) {
            networkCallbacksRegistered = false;
            setStatus("Dual jaringan belum siap: " + safeMessage(error));
        }
        refreshNetworkRoute();
    }

    private void discoverExistingNetworks() {
        if (connectivityManager == null) return;
        try {
            Network[] networks = connectivityManager.getAllNetworks();
            if (networks == null) return;
            for (Network network : networks) {
                NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
                if (capabilities == null) continue;
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    observedWifiNetwork = network;
                    if (localOnlyWifiNetwork == null) wifiNetwork = network;
                }
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    cellularNetwork = network;
                }
            }
        } catch (Throwable ignored) {}
    }

    private void beginInternetRoute() {
        internetRouteDepth++;
        refreshNetworkRoute();
    }

    private void endInternetRoute() {
        if (internetRouteDepth > 0) internetRouteDepth--;
        refreshNetworkRoute();
    }

    private ApiCallback beginInternetRouteForCallback(final ApiCallback callback) {
        beginInternetRoute();
        return new ApiCallback() {
            private boolean completed = false;

            @Override
            public synchronized void onResult(boolean success, JSONObject data, String error) {
                if (completed) return;
                completed = true;
                endInternetRoute();
                if (callback != null) callback.onResult(success, data, error);
            }
        };
    }

    private void finishLicenseCheckRoute() {
        licenseCheckInProgress = false;
        refreshNetworkRoute();
    }

    private void refreshNetworkRoute() {
        if (connectivityManager == null) {
            updateNetworkBadge();
            return;
        }

        boolean needsInternet = !licenseUnlocked || licenseCheckInProgress || internetRouteDepth > 0;
        String activeUrl = currentTab == null ? preferences.getString(PREF_URL, DEFAULT_URL) : currentTab.currentUrl;
        boolean companyPage = isCompanyUrl(activeUrl);

        Network desired;
        if (needsInternet || !companyPage) {
            desired = cellularNetwork;
        } else {
            desired = wifiNetwork;
        }

        if (desired == null) {
            clearProcessNetworkBinding();
        } else {
            bindProcessNetwork(desired);
        }

        if (!needsInternet && companyPage && wifiNetwork == null) {
            if (!lastCompanyWifiMissing) {
                lastCompanyWifiMissing = true;
                setStatus("Sambungkan Wi-Fi perusahaan agar LP4M dapat dibuka.");
            }
        } else {
            lastCompanyWifiMissing = false;
        }
        updateNetworkBadge();
    }

    private void bindProcessNetwork(Network network) {
        if (connectivityManager == null || network == null) return;
        if (network.equals(boundNetwork)) return;
        try {
            boolean ok;
            if (Build.VERSION.SDK_INT >= 23) {
                ok = connectivityManager.bindProcessToNetwork(network);
            } else {
                ok = ConnectivityManager.setProcessDefaultNetwork(network);
            }
            if (ok) boundNetwork = network;
        } catch (Throwable error) {
            setStatus("Gagal memilih jalur jaringan: " + safeMessage(error));
        }
    }

    private void clearProcessNetworkBinding() {
        if (connectivityManager == null) return;
        if (boundNetwork == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                connectivityManager.bindProcessToNetwork(null);
            } else {
                ConnectivityManager.setProcessDefaultNetwork(null);
            }
        } catch (Throwable ignored) {}
        boundNetwork = null;
    }

    private boolean isCompanyUrl(String value) {
        if (value == null || value.length() == 0) return true;
        if (value.startsWith("javascript:") || value.startsWith("about:")
                || value.startsWith("data:") || value.startsWith("blob:")
                || value.startsWith("file:")) return true;
        try {
            Uri uri = Uri.parse(normalizeUrl(value));
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.US);
            if ("lp4m-lpw.liebrapermana.com".equals(host)) return true;

            String home = preferences == null ? DEFAULT_URL : preferences.getString(PREF_URL, DEFAULT_URL);
            String homeHost = Uri.parse(normalizeUrl(home)).getHost();
            if (homeHost != null && host.equals(homeHost.toLowerCase(Locale.US))) return true;

            String[] parts = host.split("\\.");
            if (parts.length == 4) {
                int a = Integer.parseInt(parts[0]);
                int b = Integer.parseInt(parts[1]);
                int c = Integer.parseInt(parts[2]);
                return a == 172 && b == 30 && c >= 16 && c <= 31;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void loadUrlRouted(final TabState tab, final String rawUrl) {
        if (tab == null || tab.destroyed || tab.webView == null) return;
        final String url = rawUrl == null ? DEFAULT_URL : normalizeUrl(rawUrl);
        tab.currentUrl = url;
        if (tab == currentTab) refreshNetworkRoute();
        tab.webView.loadUrl(url);
    }

    private void reloadCurrentTabRouted() {
        if (currentTab == null || currentTab.destroyed || currentTab.webView == null) return;
        refreshNetworkRoute();
        try {
            currentTab.webView.reload();
        } catch (Throwable ignored) {}
    }

    private void updateNetworkBadge() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (networkBadge == null) return;
                boolean wifi = wifiNetwork != null;
                boolean cell = cellularNetwork != null;
                boolean defaultCell = isDefaultNetworkCellular();
                boolean special = localOnlyWifiNetwork != null;
                String text;
                int color;
                if (special && defaultCell && cell) {
                    text = "DUAL OK";
                    color = Color.rgb(22, 163, 74);
                } else if (wifi && cell && !defaultCell) {
                    text = "WIFI DOMINAN";
                    color = Color.rgb(202, 138, 4);
                } else if (wifi && cell) {
                    text = "WIFI+DATA";
                    color = Color.rgb(37, 99, 235);
                } else if (wifi) {
                    text = "WIFI";
                    color = Color.rgb(202, 138, 4);
                } else if (cell) {
                    text = "DATA";
                    color = Color.rgb(37, 99, 235);
                } else {
                    text = "PUTUS";
                    color = Color.rgb(185, 28, 28);
                }
                networkBadge.setText(text);
                networkBadge.setBackground(makeRounded(color, dp(14)));
            }
        });
    }

    private boolean isDefaultNetworkCellular() {
        if (connectivityManager == null || Build.VERSION.SDK_INT < 23) return false;
        try {
            Network active = connectivityManager.getActiveNetwork();
            NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(active);
            return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private String currentWifiSsid() {
        try {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (manager == null) return "";
            WifiInfo info = manager.getConnectionInfo();
            if (info == null) return "";
            String ssid = info.getSSID();
            if (ssid == null || "<unknown ssid>".equalsIgnoreCase(ssid)) return "";
            if (ssid.length() >= 2 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
                ssid = ssid.substring(1, ssid.length() - 1);
            }
            return ssid;
        } catch (Throwable ignored) {
            return "";
        }
    }


    private void handleNetworkBadgeClick() {
        if (Build.VERSION.SDK_INT < 29) {
            showDualNetworkInfo();
            return;
        }
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            requestLocationPermissionIfNeeded();
            setStatus("Izinkan lokasi agar Android dapat memilih Wi-Fi kerja.");
            return;
        }
        if (localOnlyWifiNetwork != null) {
            setStatus("Dual jaringan sudah aktif. Tahan tombol DUAL OK untuk mengganti Wi-Fi.");
            return;
        }
        String savedSsid = preferences.getString(PREF_WORK_WIFI_SSID, "").trim();
        String savedPassword = preferences.getString(PREF_WORK_WIFI_PASSWORD, "");
        if (savedSsid.length() > 0) {
            preferences.edit().putBoolean(PREF_WORK_WIFI_AUTO, true).apply();
            setStatus("Menyambungkan Wi-Fi " + savedSsid + " memakai data yang tersimpan…");
            connectWorkWifiLocalOnly(savedSsid, savedPassword, true);
            return;
        }
        showDualNetworkInfo();
    }

    private void showDualNetworkInfo() {
        if (Build.VERSION.SDK_INT < 29) {
            new AlertDialog.Builder(this)
                    .setTitle("Wi-Fi kerja khusus")
                    .setMessage("Mode ini membutuhkan Android 10 atau lebih baru.")
                    .setPositiveButton("Tutup", null)
                    .show();
            return;
        }
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            requestLocationPermissionIfNeeded();
            setStatus("Izinkan lokasi agar Android dapat memilih Wi-Fi kerja.");
            return;
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(8), dp(18), 0);

        TextView info = new TextView(this);
        info.setText("Agar WhatsApp/Chrome tetap memakai data, Wi-Fi perusahaan harus disambungkan dari ICE sebagai jaringan lokal khusus.\n\nPassword Wi-Fi Android yang pernah tersimpan tidak dapat dibaca oleh APK biasa. Masukkan satu kali di ICE; setelah itu ICE menyimpan dan menyambungkannya otomatis. Tahan tombol jaringan untuk membuka pengaturan ini lagi.");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(45, 55, 72));
        layout.addView(info, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        EditText ssidInput = new EditText(this);
        ssidInput.setHint("Nama Wi-Fi / SSID perusahaan");
        String savedSsid = preferences.getString(PREF_WORK_WIFI_SSID, "");
        if (savedSsid.length() == 0) savedSsid = currentWifiSsid();
        ssidInput.setText(savedSsid);
        layout.addView(ssidInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        EditText passwordInput = new EditText(this);
        passwordInput.setHint("Masukkan sekali; berikutnya otomatis");
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setText(preferences.getString(PREF_WORK_WIFI_PASSWORD, ""));
        layout.addView(passwordInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        TextView state = new TextView(this);
        String route = isDefaultNetworkCellular() ? "Data seluler" : "Wi-Fi/otomatis Android";
        state.setText("Wi-Fi khusus ICE: " + (localOnlyWifiNetwork != null ? "AKTIF" : "BELUM AKTIF")
                + "\nJalur utama HP: " + route);
        state.setTextSize(12);
        state.setTextColor(Color.rgb(71, 85, 105));
        state.setPadding(0, dp(8), 0, 0);
        layout.addView(state);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Wi-Fi kerja khusus")
                .setView(layout)
                .setPositiveButton("Hubungkan", null)
                .setNeutralButton("Putus", null)
                .setNegativeButton("Pengaturan Wi-Fi", null)
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface ignored) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String ssid = ssidInput.getText().toString().trim();
                        String password = passwordInput.getText().toString();
                        if (ssid.length() == 0) {
                            ssidInput.setError("Isi nama Wi-Fi perusahaan");
                            return;
                        }
                        if (password.length() > 0 && password.length() < 8) {
                            passwordInput.setError("Password WPA minimal 8 karakter");
                            return;
                        }
                        preferences.edit()
                                .putString(PREF_WORK_WIFI_SSID, ssid)
                                .putString(PREF_WORK_WIFI_PASSWORD, password)
                                .putBoolean(PREF_WORK_WIFI_AUTO, true)
                                .apply();
                        connectWorkWifiLocalOnly(ssid, password, true);
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        disconnectWorkWifiLocalOnly();
                        dialog.dismiss();
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                        } catch (Throwable error) {
                            setStatus("Tidak dapat membuka Pengaturan Wi-Fi: " + safeMessage(error));
                        }
                        dialog.dismiss();
                    }
                });
            }
        });
        dialog.show();
    }

    private void connectWorkWifiLocalOnly(final String ssid, final String password, final boolean userInitiated) {
        if (Build.VERSION.SDK_INT < 29 || connectivityManager == null) return;
        if (!hasLocationPermission()) {
            pendingWorkWifiPermission = true;
            requestLocationPermissionIfNeeded();
            return;
        }
        disconnectWorkWifiLocalOnlyInternal(false);
        try {
            WifiNetworkSpecifier.Builder specifierBuilder = new WifiNetworkSpecifier.Builder()
                    .setSsid(ssid);
            if (password != null && password.length() > 0) {
                specifierBuilder.setWpa2Passphrase(password);
            }
            WifiNetworkSpecifier specifier = specifierBuilder.build();
            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(specifier)
                    .build();

            localOnlyWifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    localOnlyWifiRequestActive = true;
                    localOnlyWifiNetwork = network;
                    wifiNetwork = network;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            if (isDefaultNetworkCellular()) {
                                setStatus("Dual jaringan berhasil: ICE lewat Wi-Fi, aplikasi lain lewat data.");
                            } else {
                                setStatus("Wi-Fi khusus tersambung, tetapi Wi-Fi biasa masih dominan. Lupakan Wi-Fi perusahaan dari Pengaturan lalu coba lagi.");
                            }
                            if (browserStarted && currentTab != null && isCompanyUrl(currentTab.currentUrl)) {
                                reloadCurrentTabRouted();
                            }
                        }
                    });
                }

                @Override
                public void onLost(Network network) {
                    if (network != null && network.equals(localOnlyWifiNetwork)) {
                        localOnlyWifiNetwork = null;
                        wifiNetwork = observedWifiNetwork;
                    }
                    localOnlyWifiRequestActive = false;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            setStatus("Wi-Fi kerja khusus terputus.");
                        }
                    });
                }

                @Override
                public void onUnavailable() {
                    localOnlyWifiRequestActive = false;
                    localOnlyWifiNetwork = null;
                    wifiNetwork = observedWifiNetwork;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshNetworkRoute();
                            setStatus("Gagal menyambungkan Wi-Fi khusus. Pastikan SSID/password benar dan Wi-Fi perusahaan sudah dilupakan dari Pengaturan.");
                        }
                    });
                }
            };
            localOnlyWifiRequestActive = true;
            connectivityManager.requestNetwork(request, localOnlyWifiCallback);
            if (userInitiated) setStatus("Pilih/izinkan Wi-Fi perusahaan pada dialog Android…");
        } catch (Throwable error) {
            localOnlyWifiRequestActive = false;
            setStatus("Gagal meminta Wi-Fi kerja khusus: " + safeMessage(error));
        }
    }

    private void disconnectWorkWifiLocalOnly() {
        preferences.edit().putBoolean(PREF_WORK_WIFI_AUTO, false).apply();
        disconnectWorkWifiLocalOnlyInternal(true);
    }

    private void disconnectWorkWifiLocalOnlyInternal(boolean showStatus) {
        if (connectivityManager != null && localOnlyWifiCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(localOnlyWifiCallback);
            } catch (Throwable ignored) {}
        }
        localOnlyWifiCallback = null;
        localOnlyWifiRequestActive = false;
        localOnlyWifiNetwork = null;
        wifiNetwork = observedWifiNetwork;
        refreshNetworkRoute();
        if (showStatus) setStatus("Wi-Fi kerja khusus dimatikan.");
    }

    private void maybeAutoConnectWorkWifi() {
        if (Build.VERSION.SDK_INT < 29 || localOnlyWifiRequestActive || localOnlyWifiNetwork != null) return;
        if (!preferences.getBoolean(PREF_WORK_WIFI_AUTO, false)) return;
        if (!hasLocationPermission()) return;
        String ssid = preferences.getString(PREF_WORK_WIFI_SSID, "");
        if (ssid.length() == 0) return;
        String password = preferences.getString(PREF_WORK_WIFI_PASSWORD, "");
        setStatus("Menyambungkan otomatis ke Wi-Fi " + ssid + "…");
        connectWorkWifiLocalOnly(ssid, password, false);
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        return message == null || message.length() == 0 ? error.getClass().getSimpleName() : message;
    }

    private void startBrowserIfNeeded() {
        if (browserStarted) return;
        browserStarted = true;
        createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
        maybeAutoConnectWorkWifi();
    }

    private void createNewTab(String url, boolean switchNow) {
        final TabState tab = new TabState();
        tab.number = nextTabNumber++;
        tab.title = "Tab " + tab.number;
        tab.currentUrl = normalizeUrl(url);

        tab.webView = new WebView(this);
        tab.webView.setVisibility(View.GONE);
        configureWebView(tab);
        webContainer.addView(tab.webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        tab.button = null;
        tabs.add(tab);
        updateTabCount();

        // Tampilkan tab lebih dulu supaya sentuhan terasa langsung, baru mulai memuat halaman.
        if (switchNow) switchToTab(tab);
        loadUrlRouted(tab, tab.currentUrl);
    }


    private void switchToTab(TabState tab) {
        if (tab == null || tab.destroyed) return;

        for (TabState item : tabs) {
            boolean active = item == tab;
            item.webView.setVisibility(active ? View.VISIBLE : View.GONE);
            try {
                if (active) {
                    item.webView.onResume();
                    item.webView.resumeTimers();
                } else {
                    item.webView.onPause();
                    item.webView.pauseTimers();
                }
            } catch (Throwable ignored) {}
        }

        currentTab = tab;
        refreshNetworkRoute();
        updateBrowserUi(tab);
        setStatus("Tab " + tab.number + ": " + shortUrl(tab.currentUrl));
    }


    private void closeCurrentTab() {
        if (currentTab == null) return;
        if (tabs.size() <= 1) {
            loadUrlRouted(currentTab, preferences.getString(PREF_URL, DEFAULT_URL));
            return;
        }
        closeTab(currentTab);
    }

    private void closeTab(TabState tab) {
        int index = tabs.indexOf(tab);
        if (index < 0) return;

        tabs.remove(tab);
        webContainer.removeView(tab.webView);
        tab.destroyed = true;
        try { tab.webView.stopLoading(); } catch (Throwable ignored) {}
        try { tab.webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
        try { tab.webView.destroy(); } catch (Throwable ignored) {}
        updateTabCount();

        if (tabs.size() == 0) {
            createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            return;
        }

        int nextIndex = Math.min(index, tabs.size() - 1);
        switchToTab(tabs.get(nextIndex));
    }


    private void showModernErrorPage(final TabState tab, String failingUrl,
                                     String description, int errorCode) {
        if (tab == null || tab.webView == null || tab.destroyed) return;
        final String safeUrl = failingUrl == null ? "" : failingUrl;
        tab.currentUrl = safeUrl;
        String host = shortUrl(safeUrl);
        String detail = description == null || description.trim().length() == 0
                ? "ERR_CONNECTION_FAILED" : description.trim();
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 50% 32%,#16243d 0,#0b1220 42%,#070b13 100%);color:#eef4ff;font-family:system-ui,-apple-system,Roboto,Arial;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:28px}.wrap{width:100%;max-width:520px;text-align:center}.art{width:132px;height:104px;margin:0 auto 28px;position:relative}.window{position:absolute;left:10px;top:8px;width:102px;height:80px;border:3px solid #668ee8;border-radius:20px;background:linear-gradient(145deg,rgba(84,124,210,.18),rgba(18,29,52,.45));box-shadow:0 18px 46px rgba(0,0,0,.32)}.window:before{content:'•••';position:absolute;left:14px;top:5px;color:#7fa3f2;letter-spacing:5px}.face{font-size:36px;position:absolute;left:35px;top:29px;color:#8eaae9}.badge{position:absolute;right:0;bottom:0;width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(145deg,#4d83f5,#2154bd);font-size:28px;font-weight:800;box-shadow:0 12px 28px rgba(36,91,202,.45)}h1{font-size:28px;line-height:1.25;margin:0 0 14px;font-weight:750}.desc{color:#aebbd1;font-size:16px;line-height:1.55;margin:0 auto;max-width:430px}.code{color:#8290a8;font-size:14px;margin-top:18px;word-break:break-word}.btn{margin-top:28px;border:0;border-radius:16px;background:linear-gradient(135deg,#4c82f5,#215bcf);color:white;font-size:17px;font-weight:700;padding:15px 30px;min-width:190px;box-shadow:0 14px 30px rgba(31,91,210,.35)}.host{font-weight:650;color:#dbe7ff}</style></head><body><div class='wrap'><div class='art'><div class='window'><div class='face'>⌢</div></div><div class='badge'>!</div></div><h1>Halaman web tidak tersedia</h1><p class='desc'>Halaman web di <span class='host'>"
                + escapeHtml(host) + "</span> tidak dapat dimuat saat ini.</p><div class='code'>net::"
                + escapeHtml(detail.replace(' ', '_').toUpperCase(Locale.US)) + "</div><button class='btn' onclick=\"location.href='"
                + escapeJsString(safeUrl) + "'\">↻&nbsp;&nbsp;Muat ulang</button></div></body></html>";
        try {
            tab.webView.loadDataWithBaseURL(safeUrl, html, "text/html", "UTF-8", null);
        } catch (Throwable ignored) {}
        updateTabTitle(tab, "Halaman web tidak tersedia");
        if (tab == currentTab) updateBrowserUi(tab);
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;");
    }

    private String escapeJsString(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("'", "\\'")
                .replace("\r", "").replace("\n", "\\n");
    }

    private void configureWebView(final TabState tab) {
        WebSettings settings = tab.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(true);
        settings.setSupportZoom(true);
        try { settings.setDisplayZoomControls(false); } catch (Throwable ignored) {}
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        try { settings.setGeolocationEnabled(true); } catch (Throwable ignored) {}
        applyDesktopMode(settings);

        tab.webView.setBackgroundColor(Color.rgb(7, 11, 19));

        tab.webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null || url.length() == 0) return false;
                loadUrlRouted(tab, url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.currentUrl = url;
                if (tab == currentTab) refreshNetworkRoute();
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(5, true);
                    setStatus("Membuka " + shortUrl(url) + "…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                tab.currentUrl = url;
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(100, false);
                    setStatus("Halaman siap");
                }
            }


            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (tab == currentTab) {
                    setPageProgress(100, false);
                    setStatus("Gagal membuka web: " + description);
                }
                String activeUrl = failingUrl == null || failingUrl.length() == 0 ? tab.currentUrl : failingUrl;
                if (activeUrl != null && (tab.currentUrl == null || activeUrl.equals(tab.currentUrl)
                        || activeUrl.equals(view.getUrl()))) {
                    showModernErrorPage(tab, activeUrl, description, errorCode);
                }
            }
        });

        tab.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasCameraPermission()) {
                            request.grant(request.getResources());
                        } else {
                            pendingPermissionRequest = request;
                            requestCameraPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin,
                                                           final GeolocationPermissions.Callback callback) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasLocationPermission()) {
                            callback.invoke(origin, true, false);
                            setStatus("Izin lokasi diberikan.");
                        } else {
                            pendingGeolocationOrigin = origin;
                            pendingGeolocationCallback = callback;
                            requestLocationPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (tab == currentTab) {
                    setPageProgress(newProgress, newProgress < 100);
                    if (newProgress < 100) setStatus("Memuat halaman " + newProgress + "%");
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && title.trim().length() > 0) {
                    updateTabTitle(tab, title.trim());
                    if (tab == currentTab) updateBrowserUi(tab);
                }
            }
        });
    }


    private void updateTabTitle(final TabState tab, final String value) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String shortValue = value == null ? "Tab " + tab.number : value;
                if (shortValue.length() > 32) shortValue = shortValue.substring(0, 32) + "…";
                tab.title = shortValue;
                if (tab.button != null) tab.button.setText(shortValue);
                updateTabCount();
            }
        });
    }


    private void showUrlDialog() {
        showHomeUrlDialog();
    }


    private ModernIconView modernIconButton(String icon, int color, int backgroundColor, int radius) {
        ModernIconView view = new ModernIconView(this, icon, color);
        view.setBackground(makePressableRounded(backgroundColor,
                blendColor(backgroundColor, Color.WHITE, 0.08f), radius));
        return view;
    }

    private ModernIconView bottomNavButton(String icon, String description) {
        ModernIconView view = modernIconButton(icon, Color.rgb(226, 232, 240),
                Color.TRANSPARENT, dp(20));
        view.setContentDescription(description);
        return view;
    }

    private StateListDrawable makePressableRounded(int normalColor, int pressedColor, int radius) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[] { android.R.attr.state_pressed }, makeRounded(pressedColor, radius));
        states.addState(new int[] {}, makeRounded(normalColor, radius));
        return states;
    }

    private int blendColor(int base, int overlay, float amount) {
        amount = Math.max(0f, Math.min(1f, amount));
        int a = Color.alpha(base);
        int r = Math.round(Color.red(base) * (1f - amount) + Color.red(overlay) * amount);
        int g = Math.round(Color.green(base) * (1f - amount) + Color.green(overlay) * amount);
        int b = Math.round(Color.blue(base) * (1f - amount) + Color.blue(overlay) * amount);
        return Color.argb(a, r, g, b);
    }

    private Button toolbarButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.rgb(232, 234, 237));
        button.setTextSize(18);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private Button bottomButton(String text, String description) {
        Button button = toolbarButton(text);
        button.setTextSize(24);
        button.setContentDescription(description);
        return button;
    }

    private GradientDrawable makeRoundedStroke(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = makeRounded(color, radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private void navigateAddressBar() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null || addressInput == null) return;

        String value = addressInput.getText().toString().trim();
        if (value.length() == 0) return;

        String url;
        if (value.indexOf(' ') >= 0 && value.indexOf('.') < 0) {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8");
            } catch (Throwable ignored) {
                url = normalizeUrl(value);
            }
        } else {
            url = normalizeUrl(value);
        }

        addressInput.clearFocus();
        loadUrlRouted(currentTab, url);
    }

    private void goHome() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        String home = preferences.getString(PREF_URL, DEFAULT_URL);
        if (currentTab == null) createNewTab(home, true);
        else loadUrlRouted(currentTab, home);
    }

    private void updateBrowserUi(final TabState tab) {
        if (tab == null) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String url = tab.currentUrl == null ? "" : tab.currentUrl;
                if (addressInput != null && !addressInput.hasFocus()) addressInput.setText(url);
                if (securityIcon != null) {
                    if (url.startsWith("https://")) {
                        securityIcon.setIcon("lock");
                        securityIcon.setIconColor(Color.rgb(103, 214, 145));
                    } else {
                        securityIcon.setIcon("info");
                        securityIcon.setIconColor(Color.rgb(248, 113, 113));
                    }
                }
                if (bookmarkButton != null) {
                    bookmarkButton.setText(isBookmarked(url) ? "★" : "☆");
                    bookmarkButton.setTextColor(isBookmarked(url)
                            ? Color.rgb(251, 188, 4)
                            : Color.rgb(232, 234, 237));
                }
                updateTabCount();
            }
        });
    }

    private void setPageProgress(final int progress, final boolean loading) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pageLoading = loading;
                if (pageProgress != null) {
                    pageProgress.setProgress(Math.max(0, Math.min(100, progress)));
                    pageProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
                }
                if (reloadButton != null) reloadButton.setIcon(loading ? "close" : "reload");
            }
        });
    }

    private void updateTabCount() {
        if (tabsButton != null) tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
    }

    private List<BookmarkItem> loadBookmarks() {
        List<BookmarkItem> list = new ArrayList<BookmarkItem>();
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BOOKMARKS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "Bookmark").trim();
                String url = normalizeUrl(item.optString("url", ""));
                if (url.length() == 0) continue;
                if (name.length() == 0) name = shortUrl(url);
                // Hindari bookmark ganda akibat garis miring atau fragment URL.
                boolean duplicate = false;
                for (BookmarkItem saved : list) {
                    if (bookmarkKey(saved.url).equals(bookmarkKey(url))) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) list.add(new BookmarkItem(name, url));
            }
        } catch (Throwable ignored) {}
        return list;
    }

    private void saveBookmarks(List<BookmarkItem> list) {
        JSONArray array = new JSONArray();
        try {
            for (BookmarkItem item : list) {
                JSONObject object = new JSONObject();
                object.put("name", item.name == null ? "Bookmark" : item.name.trim());
                object.put("url", normalizeUrl(item.url));
                array.put(object);
            }
        } catch (Throwable ignored) {}
        preferences.edit().putString(PREF_BOOKMARKS, array.toString()).apply();
    }

    private String bookmarkKey(String url) {
        if (url == null) return "";
        String value = normalizeUrl(url).trim();
        int hash = value.indexOf('#');
        if (hash >= 0) value = value.substring(0, hash);
        while (value.endsWith("/") && value.length() > 9) {
            value = value.substring(0, value.length() - 1);
        }
        return value.toLowerCase(Locale.US);
    }

    private int bookmarkIndex(String url) {
        String key = bookmarkKey(url);
        List<BookmarkItem> list = loadBookmarks();
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) return i;
        }
        return -1;
    }

    private boolean isBookmarked(String url) {
        return bookmarkIndex(url) >= 0;
    }

    private void toggleCurrentBookmark() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        List<BookmarkItem> list = loadBookmarks();
        String key = bookmarkKey(currentTab.currentUrl);
        int index = -1;
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) {
                index = i;
                break;
            }
        }

        if (index >= 0) {
            list.remove(index);
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark dihapus", Toast.LENGTH_SHORT).show();
        } else {
            String name = currentTab.title == null || currentTab.title.trim().length() == 0
                    ? shortUrl(currentTab.currentUrl)
                    : currentTab.title.trim();
            list.add(new BookmarkItem(name, normalizeUrl(currentTab.currentUrl)));
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark disimpan", Toast.LENGTH_SHORT).show();
        }
        updateBrowserUi(currentTab);
    }

    private void showBookmarksDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(247, 248, 250));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(6));
        top.setBackgroundColor(Color.WHITE);

        ModernIconView back = modernIconButton("back", Color.rgb(32, 33, 36), Color.TRANSPARENT, dp(18));
        back.setContentDescription("Kembali");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dialog.dismiss(); }
        });
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView title = new TextView(this);
        title.setText("Bookmark");
        title.setTextColor(Color.rgb(32, 33, 36));
        title.setTextSize(21);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));

        final ModernIconView addCurrent = modernIconButton("plus", Color.WHITE, Color.rgb(48, 93, 186), dp(17));
        addCurrent.setContentDescription("Simpan halaman aktif");
        addCurrent.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (currentTab != null) toggleCurrentBookmark();
                dialog.dismiss();
                handler.postDelayed(new Runnable() {
                    @Override public void run() { showBookmarksDialog(); }
                }, 90);
            }
        });
        top.addView(addCurrent, new LinearLayout.LayoutParams(dp(46), dp(46)));
        page.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(66)));

        final EditText search = modernSearchInput("Telusuri bookmark");
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        searchParams.setMargins(dp(16), dp(12), dp(16), dp(8));
        page.addView(search, searchParams);

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(4), dp(14), dp(18));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        rebuildBookmarksList(list, dialog, "");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                rebuildBookmarksList(list, dialog, s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        dialog.setContentView(page);
        showModernFullScreenDialog(dialog, page);
    }

    private void rebuildBookmarksList(final LinearLayout list, final Dialog dialog, String query) {
        list.removeAllViews();
        final List<BookmarkItem> bookmarks = loadBookmarks();
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.US);
        int shown = 0;

        for (int i = 0; i < bookmarks.size(); i++) {
            final int index = i;
            final BookmarkItem item = bookmarks.get(i);
            String haystack = (item.name + " " + item.url).toLowerCase(Locale.US);
            if (needle.length() > 0 && !haystack.contains(needle)) continue;
            shown++;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(12), dp(9), dp(6), dp(9));
            card.setBackground(makeRoundedStroke(
                    Color.WHITE, dp(17), Color.rgb(229, 231, 235), dp(1)));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(82));
            cardParams.setMargins(0, dp(7), 0, dp(2));

            String first = item.name == null || item.name.trim().length() == 0
                    ? "★" : item.name.trim().substring(0, 1).toUpperCase(Locale.US);
            TextView favicon = modernIconText(first, Color.rgb(48, 93, 186),
                    Color.rgb(232, 239, 254), 16);
            card.addView(favicon, new LinearLayout.LayoutParams(dp(45), dp(45)));

            LinearLayout textArea = new LinearLayout(this);
            textArea.setOrientation(LinearLayout.VERTICAL);
            textArea.setGravity(Gravity.CENTER_VERTICAL);
            textArea.setPadding(dp(12), 0, dp(6), 0);

            TextView name = new TextView(this);
            name.setText(item.name);
            name.setTextColor(Color.rgb(31, 41, 55));
            name.setTextSize(15);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textArea.addView(name, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));

            TextView url = new TextView(this);
            url.setText(shortUrl(item.url));
            url.setTextColor(Color.rgb(107, 114, 128));
            url.setTextSize(12);
            url.setSingleLine(true);
            url.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textArea.addView(url, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(24)));

            textArea.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    if (currentTab == null) createNewTab(item.url, true);
                    else loadUrlRouted(currentTab, item.url);
                }
            });
            card.addView(textArea, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));

            ModernIconView newTab = modernIconButton("plus", Color.rgb(75, 85, 99),
                    Color.TRANSPARENT, dp(15));
            newTab.setContentDescription("Buka di tab baru");
            newTab.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    createNewTab(item.url, true);
                }
            });
            card.addView(newTab, new LinearLayout.LayoutParams(dp(38), dp(44)));

            ModernIconView edit = modernIconButton("edit", Color.rgb(75, 85, 99),
                    Color.TRANSPARENT, dp(14));
            edit.setContentDescription("Edit bookmark");
            edit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    showBookmarkEditor(index);
                }
            });
            card.addView(edit, new LinearLayout.LayoutParams(dp(38), dp(44)));

            ModernIconView delete = modernIconButton("close", Color.rgb(185, 28, 28),
                    Color.TRANSPARENT, dp(15));
            delete.setContentDescription("Hapus bookmark");
            delete.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    List<BookmarkItem> latest = loadBookmarks();
                    if (index >= 0 && index < latest.size()) {
                        latest.remove(index);
                        saveBookmarks(latest);
                    }
                    rebuildBookmarksList(list, dialog, "");
                    updateBrowserUi(currentTab);
                }
            });
            card.addView(delete, new LinearLayout.LayoutParams(dp(38), dp(44)));

            list.addView(card, cardParams);
        }

        if (shown == 0) {
            LinearLayout emptyWrap = new LinearLayout(this);
            emptyWrap.setOrientation(LinearLayout.VERTICAL);
            emptyWrap.setGravity(Gravity.CENTER);
            emptyWrap.setPadding(dp(20), dp(64), dp(20), dp(28));

            TextView icon = new TextView(this);
            icon.setText("☆");
            icon.setTextSize(54);
            icon.setTextColor(Color.rgb(156, 163, 175));
            icon.setGravity(Gravity.CENTER);
            emptyWrap.addView(icon, new LinearLayout.LayoutParams(dp(90), dp(90)));

            TextView empty = new TextView(this);
            empty.setText(bookmarks.size() == 0
                    ? "Belum ada bookmark\nTekan tombol + untuk menyimpan halaman aktif."
                    : "Bookmark tidak ditemukan");
            empty.setTextColor(Color.rgb(75, 85, 99));
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            empty.setLineSpacing(dp(3), 1f);
            emptyWrap.addView(empty, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            list.addView(emptyWrap);
        }
    }

    private void showBookmarkEditor(final int index) {
        final List<BookmarkItem> bookmarks = loadBookmarks();
        if (index < 0 || index >= bookmarks.size()) return;
        final BookmarkItem item = bookmarks.get(index);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(6), dp(20), 0);

        final EditText name = new EditText(this);
        name.setHint("Nama bookmark");
        name.setSingleLine(true);
        name.setText(item.name);
        layout.addView(name);

        final EditText url = new EditText(this);
        url.setHint("URL");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(item.url);
        layout.addView(url);

        new AlertDialog.Builder(this)
                .setTitle("Edit bookmark")
                .setView(layout)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newUrl = normalizeUrl(url.getText().toString());
                        String newName = name.getText().toString().trim();
                        if (newName.length() == 0) newName = shortUrl(newUrl);
                        item.name = newName;
                        item.url = newUrl;
                        bookmarks.set(index, item);
                        saveBookmarks(bookmarks);
                        updateBrowserUi(currentTab);
                        handler.postDelayed(new Runnable() {
                            @Override public void run() { showBookmarksDialog(); }
                        }, 80);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showTabsDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(248, 249, 252));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(10), dp(12), dp(7));
        top.setBackgroundColor(Color.WHITE);

        ModernIconView add = modernIconButton("plus", Color.WHITE, Color.rgb(45, 94, 190), dp(18));
        add.setContentDescription("Tab baru");
        add.setBackground(makeRounded(Color.rgb(45, 94, 190), dp(18)));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true); }
                });
            }
        });
        top.addView(add, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout switcher = new LinearLayout(this);
        switcher.setOrientation(LinearLayout.HORIZONTAL);
        switcher.setGravity(Gravity.CENTER);
        switcher.setPadding(dp(5), dp(4), dp(5), dp(4));
        switcher.setBackground(makeRounded(Color.rgb(239, 241, 246), dp(24)));

        TextView count = modernIconText(String.valueOf(Math.max(1, tabs.size())),
                Color.rgb(32, 33, 36), Color.WHITE, 15);
        count.setTypeface(null, android.graphics.Typeface.BOLD);
        count.setBackground(makeRounded(Color.WHITE, dp(19)));
        switcher.addView(count, new LinearLayout.LayoutParams(dp(48), dp(40)));

        ModernIconView gridIcon = modernIconButton("grid", Color.rgb(45, 94, 190),
                Color.TRANSPARENT, dp(17));
        switcher.addView(gridIcon, new LinearLayout.LayoutParams(dp(48), dp(40)));

        LinearLayout.LayoutParams switcherParams = new LinearLayout.LayoutParams(dp(106), dp(50));
        switcherParams.setMargins(dp(14), 0, 0, 0);
        top.addView(switcher, switcherParams);

        TextView topTitle = new TextView(this);
        topTitle.setText("Tab terbuka");
        topTitle.setTextColor(Color.rgb(32, 33, 36));
        topTitle.setTextSize(19);
        topTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        topTitle.setGravity(Gravity.CENTER_VERTICAL);
        topTitle.setPadding(dp(14), 0, 0, 0);
        top.addView(topTitle, new LinearLayout.LayoutParams(0, dp(54), 1));

        ModernIconView menu = modernIconButton("menu", Color.rgb(32, 33, 36),
                Color.TRANSPARENT, dp(18));
        menu.setContentDescription("Menu browser");
        menu.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { showBrowserMenu(); }
                });
            }
        });
        top.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(50)));
        page.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));

        final EditText search = modernSearchInput("Telusuri tab Anda");
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        searchParams.setMargins(dp(14), dp(10), dp(14), dp(8));
        page.addView(search, searchParams);

        final GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);
        grid.setPadding(dp(9), dp(2), dp(9), dp(28));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(grid, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        rebuildTabGrid(grid, dialog, "");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                rebuildTabGrid(grid, dialog, s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        dialog.setContentView(page);
        showModernFullScreenDialog(dialog, page);
    }

    private void rebuildTabGrid(final GridLayout grid, final Dialog dialog, String query) {
        grid.removeAllViews();
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.US);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int availableWidth = screenWidth - dp(38);
        int cardWidth = availableWidth / 2;
        int headerHeight = dp(48);
        int footerHeight = dp(39);
        int cardHeight = Math.max(dp(222), Math.round(cardWidth * 1.58f));
        int shown = 0;

        for (final TabState tab : new ArrayList<TabState>(tabs)) {
            String haystack = ((tab.title == null ? "" : tab.title) + " "
                    + (tab.currentUrl == null ? "" : tab.currentUrl)).toLowerCase(Locale.US);
            if (needle.length() > 0 && !haystack.contains(needle)) continue;
            shown++;

            final boolean active = tab == currentTab;
            final int stroke = active ? dp(3) : dp(1);

            FrameLayout outer = new FrameLayout(this);
            outer.setPadding(stroke, stroke, stroke, stroke);
            outer.setClipToPadding(true);
            if (Build.VERSION.SDK_INT >= 21) {
                outer.setElevation(active ? dp(8) : dp(4));
                outer.setClipToOutline(true);
            }
            outer.setBackground(makeRoundedStroke(
                    active ? Color.rgb(229, 237, 255) : Color.WHITE,
                    dp(19),
                    active ? Color.rgb(45, 94, 190) : Color.rgb(218, 221, 228),
                    stroke));

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(makeRounded(Color.WHITE, dp(17)));
            if (Build.VERSION.SDK_INT >= 21) {
                card.setClipToOutline(true);
            }

            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.setPadding(dp(8), dp(3), dp(4), dp(2));

            String first = tab.title == null || tab.title.trim().length() == 0
                    ? "T" : tab.title.trim().substring(0, 1).toUpperCase(Locale.US);
            TextView favicon = modernIconText(first,
                    active ? Color.WHITE : Color.rgb(45, 94, 190),
                    active ? Color.rgb(45, 94, 190) : Color.rgb(232, 239, 254),
                    13);
            favicon.setClickable(false);
            favicon.setFocusable(false);
            header.addView(favicon, new LinearLayout.LayoutParams(dp(31), dp(31)));

            TextView title = new TextView(this);
            title.setText(tab.title == null ? "Tab " + tab.number : tab.title);
            title.setTextColor(Color.rgb(31, 41, 55));
            title.setTextSize(12);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            title.setPadding(dp(7), 0, dp(2), 0);
            header.addView(title, new LinearLayout.LayoutParams(0, headerHeight, 1));

            final ModernIconView close = modernIconButton("close", Color.rgb(75, 85, 99),
                    Color.rgb(245, 246, 248), dp(15));
            close.setContentDescription("Tutup tab");
            close.setEnabled(tabs.size() > 1);
            close.setAlpha(tabs.size() > 1 ? 1f : .35f);
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (tabs.size() <= 1) return;
                    close.setEnabled(false);
                    closeTab(tab);
                    rebuildTabGrid(grid, dialog, needle);
                }
            });
            LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(31), dp(31));
            closeParams.setMargins(dp(2), 0, dp(2), 0);
            header.addView(close, closeParams);
            card.addView(header, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, headerHeight));

            int previewHeight = Math.max(dp(92), cardHeight - headerHeight - footerHeight - (stroke * 2));
            FrameLayout previewShell = new FrameLayout(this);
            previewShell.setBackgroundColor(Color.rgb(250, 250, 251));

            ImageView preview = new ImageView(this);
            preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
            preview.setBackgroundColor(Color.rgb(250, 250, 251));
            Bitmap snapshot = captureTabPreview(tab,
                    Math.max(1, cardWidth - stroke * 2), Math.max(1, previewHeight));
            if (snapshot != null) preview.setImageBitmap(snapshot);
            previewShell.addView(preview, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            card.addView(previewShell, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, previewHeight));

            LinearLayout footer = new LinearLayout(this);
            footer.setOrientation(LinearLayout.HORIZONTAL);
            footer.setGravity(Gravity.CENTER_VERTICAL);
            footer.setPadding(dp(9), 0, dp(8), 0);
            footer.setBackgroundColor(Color.WHITE);

            ModernIconView lock = modernIconButton("lock", Color.rgb(107, 114, 128),
                    Color.TRANSPARENT, dp(12));
            footer.addView(lock, new LinearLayout.LayoutParams(dp(20), footerHeight));

            TextView url = new TextView(this);
            url.setText(shortUrl(tab.currentUrl));
            url.setTextColor(Color.rgb(107, 114, 128));
            url.setTextSize(10);
            url.setSingleLine(true);
            url.setEllipsize(android.text.TextUtils.TruncateAt.END);
            url.setGravity(Gravity.CENTER_VERTICAL);
            url.setPadding(dp(2), 0, 0, 0);
            footer.addView(url, new LinearLayout.LayoutParams(0, footerHeight, 1));
            card.addView(footer, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, footerHeight));

            outer.addView(card, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));

            outer.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    switchToTab(tab);
                }
            });

            GridLayout.LayoutParams cardParams = new GridLayout.LayoutParams();
            cardParams.width = cardWidth;
            cardParams.height = cardHeight;
            cardParams.setMargins(dp(5), dp(7), dp(5), dp(9));
            grid.addView(outer, cardParams);

        }

        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("Tab tidak ditemukan");
            empty.setTextColor(Color.rgb(107, 114, 128));
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams emptyParams = new GridLayout.LayoutParams();
            emptyParams.width = screenWidth - dp(28);
            emptyParams.height = dp(180);
            emptyParams.columnSpec = GridLayout.spec(0, 2);
            grid.addView(empty, emptyParams);
        }
    }

    private Bitmap captureTabPreview(TabState tab, int width, int height) {
        if (tab == null || tab.webView == null || width <= 0 || height <= 0) return null;
        try {
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            int sourceWidth = Math.max(1, tab.webView.getWidth());
            int sourceHeight = Math.max(1, tab.webView.getHeight());
            float scaleX = width / (float) sourceWidth;
            float scaleY = height / (float) sourceHeight;
            canvas.save();
            canvas.scale(scaleX, scaleY);
            tab.webView.draw(canvas);
            canvas.restore();
            return bitmap;
        } catch (Throwable ignored) {
            return null;
        }
    }


    private EditText modernFormInput(String hint, int inputType) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setInputType(inputType);
        input.setTextColor(Color.rgb(31, 41, 55));
        input.setHintTextColor(Color.rgb(132, 141, 157));
        input.setTextSize(15);
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(makeRoundedStroke(Color.rgb(246, 248, 251), dp(15),
                Color.rgb(224, 228, 235), dp(1)));
        return input;
    }

    private EditText modernSearchInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setTextColor(Color.rgb(31, 41, 55));
        input.setHintTextColor(Color.rgb(112, 118, 130));
        input.setHint(hint);
        input.setPadding(dp(18), 0, dp(16), 0);
        input.setCompoundDrawablePadding(dp(11));
        try {
            Drawable searchIcon = getResources().getDrawable(android.R.drawable.ic_menu_search).mutate();
            searchIcon.setColorFilter(Color.rgb(107, 114, 128), PorterDuff.Mode.SRC_IN);
            searchIcon.setBounds(0, 0, dp(20), dp(20));
            input.setCompoundDrawables(searchIcon, null, null, null);
        } catch (Throwable ignored) {}
        input.setBackground(makeRoundedStroke(Color.rgb(239, 242, 247), dp(28),
                Color.rgb(226, 230, 237), dp(1)));
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        return input;
    }

    private TextView modernIconText(String text, int textColor, int backgroundColor, int textSize) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(textColor);
        view.setTextSize(textSize);
        view.setGravity(Gravity.CENTER);
        view.setSingleLine(true);
        view.setBackground(makeRounded(backgroundColor, dp(16)));
        view.setClickable(true);
        view.setFocusable(true);
        return view;
    }

    private void dismissThenRun(final Dialog dialog, final Runnable action) {
        if (dialog == null) {
            if (action != null) action.run();
            return;
        }
        if (!dialog.isShowing()) {
            if (action != null) action.run();
            return;
        }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) {
                try { dialog.setOnDismissListener(null); } catch (Throwable ignored) {}
                if (action != null) action.run();
            }
        });
        dialog.dismiss();
    }

    private void showModernFullScreenDialog(Dialog dialog, View content) {
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setStatusBarColor(Color.WHITE);
            window.setNavigationBarColor(Color.WHITE);
            int flags = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setBackgroundColor(Color.TRANSPARENT);
            View contentRoot = window.findViewById(android.R.id.content);
            if (contentRoot != null) contentRoot.setBackgroundColor(Color.TRANSPARENT);
            window.getDecorView().setSystemUiVisibility(flags);
        }
        content.setAlpha(0f);
        content.animate().alpha(1f).setDuration(170).start();
    }

    private void showBrowserMenu() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        final String bookmarkAction = currentTab != null && isBookmarked(currentTab.currentUrl)
                ? "Hapus bookmark halaman"
                : "Simpan halaman";
        final boolean desktopEnabled = isDesktopModeEnabled();

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(10), dp(16), dp(16));
        panel.setBackground(makeRoundedStroke(Color.WHITE, dp(32), Color.rgb(232, 235, 241), dp(1)));
        if (Build.VERSION.SDK_INT >= 21) {
            panel.setElevation(dp(24));
            panel.setClipToOutline(true);
        }

        TextView handle = new TextView(this);
        handle.setBackground(makeRounded(Color.rgb(197, 201, 208), dp(3)));
        LinearLayout.LayoutParams handleParams = new LinearLayout.LayoutParams(dp(54), dp(5));
        handleParams.gravity = Gravity.CENTER_HORIZONTAL;
        handleParams.setMargins(0, dp(2), 0, dp(8));
        panel.addView(handle, handleParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(dp(8), 0, dp(2), dp(4));

        TextView title = new TextView(this);
        title.setText("Menu ICE Dual");
        title.setTextColor(Color.rgb(24, 27, 32));
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        heading.addView(title, new LinearLayout.LayoutParams(0, dp(46), 1));

        ModernIconView close = modernIconButton("close", Color.rgb(75, 85, 99),
                Color.rgb(244, 246, 250), dp(19));
        close.setContentDescription("Tutup menu");
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dialog.dismiss(); }
        });
        heading.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        panel.addView(heading, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(2), 0, dp(2), dp(4));

        addModernMenuRow(list, "plus", "Tab baru", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true); }
                });
            }
        });
        addModernMenuRow(list, "tabs", "Daftar tab", String.valueOf(Math.max(1, tabs.size())), new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { showTabsDialog(); }
                });
            }
        });
        addMenuDivider(list);
        addModernMenuRow(list, "star", "Bookmark", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { showBookmarksDialog(); }
                });
            }
        });
        addModernMenuRow(list, "save", bookmarkAction, null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                toggleCurrentBookmark();
            }
        });
        addMenuDivider(list);
        addModernMenuRow(list, "home", "Beranda", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                goHome();
            }
        });
        addModernMenuRow(list, "reload", "Muat ulang", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                if (currentTab != null) reloadCurrentTabRouted();
            }
        });
        addModernMenuRow(list, "copy", "Salin URL", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                copyCurrentUrl();
            }
        });
        addModernMenuRow(list, "share", "Bagikan halaman", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                shareCurrentPage();
            }
        });
        addMenuDivider(list);
        addModernMenuToggleRow(list, "desktop", "Mode desktop", desktopEnabled, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                toggleDesktopMode();
            }
        });
        addModernMenuRow(list, "home_settings", "Atur URL beranda", null, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissThenRun(dialog, new Runnable() {
                    @Override public void run() { showHomeUrlDialog(); }
                });
            }
        });
        addModernMenuRow(list, "shield", ADMIN_BUILD ? "Panel KEY admin" : "Info lisensi", null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        dismissThenRun(dialog, new Runnable() {
                            @Override public void run() { if (ADMIN_BUILD) openAdminPanel(); else showLicenseInfoDialog(); }
                        });
                    }
                });

        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        dialog.setContentView(panel);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int screenHeight = getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(Math.round(screenWidth * 0.78f), dp(390));
            lp.height = Math.min(Math.round(screenHeight * 0.78f), dp(680));
            lp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            lp.x = dp(10);
            lp.dimAmount = 0.48f;
            window.setAttributes(lp);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            View decor = window.getDecorView();
            if (decor != null) decor.setBackgroundColor(Color.TRANSPARENT);
            View contentRoot = window.findViewById(android.R.id.content);
            if (contentRoot != null) contentRoot.setBackgroundColor(Color.TRANSPARENT);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setStatusBarColor(Color.rgb(9, 11, 15));
            window.setNavigationBarColor(Color.rgb(7, 8, 10));
            window.getDecorView().setSystemUiVisibility(0);
        }
        panel.setAlpha(0f);
        panel.setTranslationX(dp(70));
        panel.animate().alpha(1f).translationX(0f).setDuration(190).start();
    }

    private void addModernMenuRow(LinearLayout parent, String iconText, String titleText,
                                  String trailingText, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(3), dp(8), dp(3));
        row.setClickable(true);
        row.setFocusable(true);
        row.setBackground(makeRounded(Color.TRANSPARENT, dp(15)));
        row.setOnClickListener(listener);

        ModernIconView icon = modernIconButton(iconText, Color.rgb(36, 43, 54),
                Color.rgb(245, 247, 251), dp(17));
        icon.setClickable(false);
        icon.setFocusable(false);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView label = new TextView(this);
        label.setText(titleText);
        label.setTextColor(Color.rgb(30, 33, 39));
        label.setTextSize(16);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setPadding(dp(14), 0, dp(8), 0);
        label.setSingleLine(true);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(48), 1));

        if (trailingText != null && trailingText.length() > 0) {
            TextView trailing = new TextView(this);
            trailing.setText(trailingText);
            trailing.setTextColor(Color.rgb(45, 94, 190));
            trailing.setTextSize(13);
            trailing.setTypeface(null, android.graphics.Typeface.BOLD);
            trailing.setGravity(Gravity.CENTER);
            trailing.setBackground(makeRounded(Color.rgb(232, 239, 254), dp(15)));
            LinearLayout.LayoutParams trailingParams = new LinearLayout.LayoutParams(dp(38), dp(30));
            trailingParams.setMargins(dp(4), 0, dp(2), 0);
            row.addView(trailing, trailingParams);
        }

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(57));
        rowParams.setMargins(0, dp(1), 0, dp(1));
        parent.addView(row, rowParams);
    }

    private void addModernMenuToggleRow(LinearLayout parent, String iconText, String titleText,
                                        boolean enabled, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(3), dp(8), dp(3));
        row.setClickable(true);
        row.setFocusable(true);
        row.setBackground(makeRounded(Color.TRANSPARENT, dp(15)));
        row.setOnClickListener(listener);

        ModernIconView icon = modernIconButton(iconText, Color.rgb(36, 43, 54),
                Color.rgb(245, 247, 251), dp(17));
        icon.setClickable(false);
        icon.setFocusable(false);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView label = new TextView(this);
        label.setText(titleText);
        label.setTextColor(Color.rgb(30, 33, 39));
        label.setTextSize(16);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setPadding(dp(14), 0, dp(8), 0);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(48), 1));

        FrameLayout toggle = createModernToggle(enabled);
        row.addView(toggle, new LinearLayout.LayoutParams(dp(52), dp(30)));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(57));
        rowParams.setMargins(0, dp(1), 0, dp(1));
        parent.addView(row, rowParams);
    }

    private FrameLayout createModernToggle(boolean enabled) {
        FrameLayout toggle = new FrameLayout(this);
        toggle.setPadding(dp(3), dp(3), dp(3), dp(3));
        toggle.setBackground(makeRounded(
                enabled ? Color.rgb(45, 94, 190) : Color.rgb(205, 208, 214), dp(16)));

        TextView knob = new TextView(this);
        knob.setBackground(makeRounded(Color.WHITE, dp(12)));
        FrameLayout.LayoutParams knobParams = new FrameLayout.LayoutParams(dp(24), dp(24));
        knobParams.gravity = enabled ? Gravity.RIGHT | Gravity.CENTER_VERTICAL
                : Gravity.LEFT | Gravity.CENTER_VERTICAL;
        toggle.addView(knob, knobParams);
        return toggle;
    }

    private void addMenuDivider(LinearLayout parent) {
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(232, 234, 238));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        params.setMargins(dp(58), dp(4), dp(8), dp(4));
        parent.addView(divider, params);
    }

    private boolean isDesktopModeEnabled() {
        return preferences.getBoolean(PREF_DESKTOP_MODE, false);
    }

    private void applyDesktopMode(WebSettings settings) {
        if (settings == null) return;
        boolean desktop = isDesktopModeEnabled();
        String mobileUa = null;
        try {
            mobileUa = new WebView(this).getSettings().getUserAgentString();
        } catch (Throwable ignored) {}
        if (mobileUa == null || mobileUa.length() == 0) {
            mobileUa = "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36";
        }
        String desktopUa = mobileUa.replace(" Mobile ", " ").replace(" Android ", " X11; Linux x86_64 ");
        if (desktopUa.indexOf("Windows NT 10.0; Win64; x64") < 0) {
            desktopUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";
        }
        settings.setUserAgentString(desktop ? desktopUa : mobileUa);
        settings.setUseWideViewPort(desktop);
        settings.setLoadWithOverviewMode(desktop);
    }

    private void toggleDesktopMode() {
        boolean next = !isDesktopModeEnabled();
        preferences.edit().putBoolean(PREF_DESKTOP_MODE, next).apply();
        for (TabState item : tabs) {
            if (item == null || item.destroyed || item.webView == null) continue;
            applyDesktopMode(item.webView.getSettings());
        }
        if (currentTab != null) reloadCurrentTabRouted();
        Toast.makeText(this,
                next ? "Mode desktop diaktifkan" : "Mode desktop dimatikan",
                Toast.LENGTH_SHORT).show();
    }

    private void showHomeUrlDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(preferences.getString(PREF_URL, DEFAULT_URL));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this)
                .setTitle("URL beranda")
                .setMessage("URL ini dibuka saat aplikasi atau tab baru dibuat.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String url = normalizeUrl(input.getText().toString());
                        preferences.edit().putString(PREF_URL, url).apply();
                        Toast.makeText(MainActivity.this, "URL beranda disimpan", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton("Pakai halaman ini", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (currentTab != null) {
                            preferences.edit().putString(PREF_URL, currentTab.currentUrl).apply();
                            Toast.makeText(MainActivity.this, "Halaman aktif dijadikan beranda", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void copyCurrentUrl() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentTab.currentUrl));
            Toast.makeText(this, "URL disalin", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    private void shareCurrentPage() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, currentTab.currentUrl);
            startActivity(Intent.createChooser(intent, "Bagikan halaman"));
        } catch (Throwable ignored) {
            copyCurrentUrl();
        }
    }

    private void showPageInfo() {
        String url = currentTab == null ? "" : currentTab.currentUrl;
        String message = url.startsWith("https://")
                ? "Sambungan HTTPS.\n\n" + url
                : "Sambungan tidak menggunakan HTTPS.\n\n" + url;
        new AlertDialog.Builder(this)
                .setTitle("Info halaman")
                .setMessage(message)
                .setPositiveButton("Salin URL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        copyCurrentUrl();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showLicenseServerDialog(final boolean openAdminAfter) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://domain.com/ice-license");
        input.setText(preferences.getString(PREF_LICENSE_SERVER, ""));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this)
                .setTitle("Server lisensi ICE")
                .setMessage("Masukkan folder tempat paket server lisensi di-upload.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String server = normalizeServerUrl(input.getText().toString());
                        preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
                        if (openAdminAfter) openAdminPanel();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void openAdminPanel() {
        String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, ""));
        if (server.length() == 0) {
            showLicenseServerDialog(true);
            return;
        }
        createNewTab(server + "/admin.php", true);
    }

    private void showActivationDialog(final boolean required) {
        if (ADMIN_BUILD) return;

        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(!required);
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(22), dp(24), dp(22));
        card.setBackground(makeRoundedStroke(Color.WHITE, dp(28), Color.rgb(230, 234, 241), dp(1)));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(24));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);

        ModernIconView logo = modernIconButton("shield", Color.WHITE,
                Color.rgb(45, 94, 190), dp(20));
        hero.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout heroText = new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.setPadding(dp(15), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Masuk ke ICE Inject");
        title.setTextColor(Color.rgb(20, 25, 35));
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        heroText.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Gunakan akun aktif untuk memulai sesi kerja");
        subtitle.setTextColor(Color.rgb(100, 110, 128));
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, 0);
        heroText.addView(subtitle);
        hero.addView(heroText, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        card.addView(hero);

        final EditText serverInput = modernFormInput("URL server",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverInput.setText(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        LinearLayout.LayoutParams serverParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        serverParams.setMargins(0, dp(24), 0, 0);
        card.addView(serverInput, serverParams);

        final EditText userInput = modernFormInput("Username",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        userInput.setText(preferences.getString(PREF_LICENSE_KEY, ""));
        LinearLayout.LayoutParams userParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        userParams.setMargins(0, dp(12), 0, 0);
        card.addView(userInput, userParams);

        final EditText passInput = modernFormInput("Password",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        passParams.setMargins(0, dp(12), 0, 0);
        card.addView(passInput, passParams);

        final TextView message = new TextView(this);
        message.setText("Login membutuhkan internet. Setelah masuk, aplikasi dapat digunakan melalui Wi-Fi perusahaan selama sesi masih terbuka.");
        message.setTextColor(Color.rgb(100, 110, 128));
        message.setTextSize(12);
        message.setLineSpacing(dp(2), 1f);
        message.setPadding(dp(2), dp(14), dp(2), dp(4));
        card.addView(message);

        final Button login = new Button(this);
        login.setText("Masuk");
        login.setAllCaps(false);
        login.setTextColor(Color.WHITE);
        login.setTextSize(16);
        login.setTypeface(null, android.graphics.Typeface.BOLD);
        login.setBackground(makePressableRounded(Color.rgb(45, 94, 190),
                Color.rgb(63, 112, 210), dp(16)));
        if (Build.VERSION.SDK_INT >= 21) login.setElevation(dp(4));
        LinearLayout.LayoutParams loginParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        loginParams.setMargins(0, dp(16), 0, 0);
        card.addView(login, loginParams);

        Button cancel = new Button(this);
        cancel.setText(required ? "Keluar aplikasi" : "Batal");
        cancel.setAllCaps(false);
        cancel.setTextColor(Color.rgb(75, 85, 99));
        cancel.setTextSize(14);
        cancel.setBackground(makePressableRounded(Color.TRANSPARENT,
                Color.rgb(242, 244, 248), dp(14)));
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        cancelParams.setMargins(0, dp(6), 0, 0);
        card.addView(cancel, cancelParams);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                dialog.dismiss();
                if (required) finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final String server = normalizeServerUrl(serverInput.getText().toString());
                final String username = normalizeUsernameLocal(userInput.getText().toString());
                final String password = passInput.getText().toString();
                if (server.length() == 0) {
                    message.setText("URL server harus diisi dengan benar.");
                    message.setTextColor(Color.rgb(185, 28, 28));
                    return;
                }
                if (username.length() < 3 || password.length() == 0) {
                    message.setText("Username dan password belum lengkap.");
                    message.setTextColor(Color.rgb(185, 28, 28));
                    return;
                }

                preferences.edit().putString(PREF_LICENSE_SERVER, server)
                        .putString(PREF_LICENSE_KEY, username).apply();
                login.setEnabled(false);
                login.setText("Memeriksa akun…");
                login.setAlpha(.72f);
                message.setText("Menghubungkan ke server…");
                message.setTextColor(Color.rgb(100, 110, 128));

                loginAccount(server, username, password, new ApiCallback() {
                    @Override public void onResult(boolean success, JSONObject data, String error) {
                        if (success) {
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    licenseUnlocked = true;
                                    updateLicenseBadgeFromCache();
                                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                                    startBrowserIfNeeded();
                                    Toast.makeText(MainActivity.this, "Login berhasil", Toast.LENGTH_LONG).show();
                                }
                            });
                            return;
                        }
                        final String msg = error == null || error.length() == 0
                                ? "Login gagal. Periksa akun dan URL server." : error;
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                login.setEnabled(true);
                                login.setText("Masuk");
                                login.setAlpha(1f);
                                message.setText(msg);
                                message.setTextColor(Color.rgb(185, 28, 28));
                            }
                        });
                    }
                });
            }
        });

        dialog.setContentView(card);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(Math.round(screenWidth * .90f), dp(430));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = .68f;
            window.setAttributes(lp);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setStatusBarColor(Color.rgb(8, 12, 20));
            window.setNavigationBarColor(Color.rgb(8, 12, 20));
        }
        card.setAlpha(0f);
        card.setScaleX(.96f);
        card.setScaleY(.96f);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
    }

    private void openBrowserActivation(final String server, final boolean required) {
        final Dialog browserDialog = new Dialog(this);
        browserDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        browserDialog.setCancelable(!required);
        browserDialog.setCanceledOnTouchOutside(false);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.rgb(245, 247, 250));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(Color.rgb(15, 45, 64));

        TextView title = new TextView(this);
        title.setText("Aktivasi Browser");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        final TextView status = new TextView(this);
        status.setText("Memuat halaman aktivasi…");
        status.setTextColor(Color.rgb(71, 85, 105));
        status.setTextSize(12);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button close = smallButton(required ? "Keluar" : "Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                status.setText("Mengecek hasil aktivasi…");
                verifyActivationFromBrowser(server, browserDialog, status, required);
            }
        });
        bar.addView(close);
        container.addView(bar);
        container.addView(status);

        final WebView activationWeb = new WebView(this);
        WebSettings settings = activationWeb.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method method = android.webkit.CookieManager.class.getMethod(
                        "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                method.invoke(cookieManager, activationWeb, true);
            } catch (Exception ignored) {
            }
        }

        ActivationBridge activationBridge = new ActivationBridge(server, browserDialog, status);
        try {
            activationWeb.addJavascriptInterface(activationBridge, "Android");
            activationWeb.addJavascriptInterface(activationBridge, "IceApp");
        } catch (Throwable ignored) {}

        activationWeb.setWebChromeClient(new WebChromeClient());
        activationWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (handleActivationCallback(url, server, browserDialog, status)) {
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Membuka halaman aktivasi…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Masukkan key pada halaman di bawah.");
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            verifyActivationFromBrowser(server, browserDialog, status, false);
                        }
                    }, 900L);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                status.setText("Gagal memuat halaman: " + description + ". Pastikan internet aktif dan URL server benar.");
                status.setTextColor(Color.rgb(185, 28, 28));
            }
        });

        container.addView(activationWeb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        browserDialog.setContentView(container);
        browserDialog.show();
        Window window = browserDialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        try {
            String url = server + "/activate.php"
                    + "?device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                    + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                    + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
            activationWeb.loadUrl(url);
        } catch (Exception error) {
            status.setText("Tidak dapat membuat URL aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
        }
    }

    private boolean handleActivationCallback(String url, String server, Dialog dialog, TextView status) {
        if (url == null || !url.startsWith("iceinject://activated")) return false;

        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String message = uri.getQueryParameter("message");

            if (!"1".equals(ok)) {
                status.setText(message == null ? "Aktivasi gagal." : message);
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            String key = normalizeKey(uri.getQueryParameter("key"));
            String token = uri.getQueryParameter("token");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if (key.length() < 8 || expiryMillis <= 0) {
                status.setText("Data aktivasi dari server tidak lengkap.");
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

            preferences.edit()
                    .putString(PREF_LICENSE_SERVER, server)
                    .putString(PREF_LICENSE_KEY, key)
                    .putString(PREF_LICENSE_TOKEN, token == null ? "" : token)
                    .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                    .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                    .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                    .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                    .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                    .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                    .apply();

            dialog.dismiss();
            licenseUnlocked = true;
            updateLicenseBadgeFromCache();
            startBrowserIfNeeded();
            Toast.makeText(MainActivity.this,
                    message == null ? "Aktivasi berhasil" : message,
                    Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception error) {
            status.setText("Gagal membaca hasil aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
            return true;
        }
    }

    private long parseLongSafe(String value) {
        try {
            return Long.parseLong(value == null ? "0" : value);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private long parseServerMillis(String value) {
        if (value == null) return 0L;
        String v = value.trim();
        if (v.length() == 0) return 0L;
        try {
            if (v.matches("^[0-9]+$")) {
                long n = Long.parseLong(v);
                return n < 100000000000L ? n * 1000L : n;
            }
        } catch (Exception ignored) {}
        try {
            v = v.replace('T', ' ');
            if (v.endsWith("Z")) v = v.substring(0, v.length() - 1);
            int plus = v.indexOf('+', 10);
            if (plus > 0) v = v.substring(0, plus).trim();
            int dot = v.indexOf('.');
            if (dot > 0) v = v.substring(0, dot);
            if (v.length() >= 19) v = v.substring(0, 19);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
            Date parsed = format.parse(v);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void showLicenseInfoDialog() {
        if (ADMIN_BUILD) return;

        String key = preferences.getString(PREF_LICENSE_KEY, "-");
        long created = preferences.getLong(PREF_LICENSE_CREATED, 0L);
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        String duration = preferences.getString(PREF_LICENSE_DURATION_LABEL, "");
        String server = preferences.getString(PREF_LICENSE_SERVER, "-");
        long remaining = Math.max(0L, expiry - trustedNowMillis());

        StringBuilder message = new StringBuilder();
        message.append("Key: ").append(maskKey(key));
        if (duration != null && duration.length() > 0) {
            message.append("\nDurasi key: ").append(duration);
        }
        if (created > 0) message.append("\nDibuat: ").append(formatDate(created));
        message.append("\nBerakhir: ").append(expiry > 0 ? formatDate(expiry) : "belum aktif");
        if (expiry > 0) message.append("\nSisa waktu: ").append(longRemaining(remaining));
        message.append("\nServer: ").append(server);
        message.append("\n\nSemua waktu ditampilkan dalam WIB dan mengikuti waktu server lisensi.");

        new AlertDialog.Builder(this)
                .setTitle("Lisensi ICE Inject")
                .setMessage(message.toString())
                .setPositiveButton("Ganti / Aktivasi", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showActivationDialog(false);
                    }
                })
                .setNeutralButton("Cek Sekarang", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        validateLicenseAsync(true);
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void loginAccount(final String server, final String username, final String password, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView loginWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = loginWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, loginWeb, true);
                        } catch (Exception ignored) {}
                    }

                    loginWeb.setAlpha(0.01f);
                    loginWeb.setWebChromeClient(new WebChromeClient());
                    loginWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLoginResultFromWebView(view, server, username, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(loginWeb, params);
                    } else {
                        root.addView(loginWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/login-app.php"
                            + "?username=" + URLEncoder.encode(username, "UTF-8")
                            + "&password=" + URLEncoder.encode(password, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    loginWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(loginWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal login" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Timeout login. Cek koneksi internet/server.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLoginResultFromWebView(final WebView view, final String server, final String username,
                                            final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLoginWebText(view, server, username, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil login.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLoginWebText(WebView view, String server, String username,
                                    ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. " + small);
                return;
            }
            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Login ditolak."));
                return;
            }
            if (data.optString("username", "").length() == 0) {
                try { data.put("username", username); } catch (Throwable ignored) {}
            }
            boolean saved = saveLoginSessionFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired/token kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private void activateLicense(final String server, final String key, final ApiCallback callback) {
        // v2.7.6: free hosting sering membalas HttpURLConnection dengan HTML/JS,
        // sehingga JSONObject gagal. Aktivasi sekarang memakai WebView mini supaya
        // cookie/JS hosting tetap jalan, lalu body JSON dibaca dari halaman.
        activateLicenseViaWebView(server, key, callback);
    }

    private void activateLicenseViaWebView(final String server, final String key, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView activationWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = activationWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, activationWeb, true);
                        } catch (Exception ignored) {}
                    }

                    activationWeb.setAlpha(0.01f);
                    activationWeb.setWebChromeClient(new WebChromeClient());
                    activationWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readActivationResultFromWebView(view, server, key, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(activationWeb, params);
                    } else {
                        root.addView(activationWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/activate.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    activationWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(activationWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal aktivasi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Timeout aktivasi. Coba tombol Buka Web.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readActivationResultFromWebView(final WebView view, final String server, final String key,
                                                 final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleActivationWebText(view, server, key, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                // Semua perangkat target Android 15, tapi ini fallback aman.
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil aktivasi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleActivationWebText(WebView view, String server, String key,
                                         ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. Pakai tombol Buka Web. " + small);
                return;
            }

            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Key tidak valid."));
                return;
            }

            if (data.optString("key", "").length() == 0) {
                try { data.put("key", key); } catch (Throwable ignored) {}
            }
            boolean saved = saveLicenseFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private JSONObject jsonFromText(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (t.startsWith("\uFEFF")) t = t.substring(1).trim();
        int first = t.indexOf('{');
        int last = t.lastIndexOf('}');
        if (first < 0 || last <= first) return null;
        try {
            return new JSONObject(t.substring(first, last + 1));
        } catch (Throwable ignored) {
            return null;
        }
    }

    private String decodeJsString(String value) {
        if (value == null) return "";
        try {
            JSONArray arr = new JSONArray("[" + value + "]");
            return arr.optString(0, value);
        } catch (Throwable ignored) {
            return value;
        }
    }

    private class ActivationBridge {
        private final String server;
        private final Dialog dialog;
        private final TextView status;

        ActivationBridge(String server, Dialog dialog, TextView status) {
            this.server = server;
            this.dialog = dialog;
            this.status = status;
        }

        @JavascriptInterface
        public String getDeviceId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getAndroidId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getDeviceName() {
            return Build.MANUFACTURER + " " + Build.MODEL;
        }

        @JavascriptInterface
        public void onLicenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void licenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void activationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void onActivationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void saveLicense(String key, String token, String expiresAt, String deviceId) {
            try {
                JSONObject data = new JSONObject();
                data.put("ok", 1);
                data.put("status", "active");
                data.put("key", key == null ? "" : key);
                data.put("token", token == null ? "" : token);
                data.put("expires_at", expiresAt == null ? "" : expiresAt);
                data.put("device_id", deviceId == null ? getInstallDeviceId() : deviceId);
                data.put("server_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
                handleBridgePayload(data.toString());
            } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void setLicense(String key, String token, String expiresAt, String deviceId) {
            saveLicense(key, token, expiresAt, deviceId);
        }

        @JavascriptInterface
        public void setActivated(boolean active) {
            if (active) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        status.setText("Aktivasi diterima. Tekan Tutup/Keluar jika belum terbuka otomatis.");
                        status.setTextColor(Color.rgb(22, 101, 52));
                    }
                });
            }
        }

        private void handleBridgePayload(final String payload) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject data = jsonFromText(payload);
                        if (data == null || !jsonSaysActive(data)) {
                            status.setText("Data aktivasi tidak lengkap.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        boolean saved = saveLicenseFromJson(server, data);
                        if (!saved) {
                            status.setText("Aktivasi berhasil tapi expired tidak terbaca.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        licenseUnlocked = true;
                        updateLicenseBadgeFromCache();
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        startBrowserIfNeeded();
                        Toast.makeText(MainActivity.this, "Aktivasi berhasil", Toast.LENGTH_LONG).show();
                    } catch (Throwable error) {
                        status.setText("Gagal menyimpan aktivasi: " + error.getMessage());
                        status.setTextColor(Color.rgb(185, 28, 28));
                    }
                }
            });
        }
    }

    private void startLicenseWatchdog() {
        if (ADMIN_BUILD) return;
        handler.removeCallbacks(licenseWatchdog);
        handler.postDelayed(licenseWatchdog, LICENSE_CHECK_INTERVAL_MS);
    }

    private void validateLicenseAsync(final boolean showToast) {
        if (ADMIN_BUILD) return;

        final String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        if (server.length() == 0) {
            lockLicense("URL server lisensi belum diisi.");
            return;
        }
        if (!server.equals(preferences.getString(PREF_LICENSE_SERVER, ""))) {
            preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
        }

        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        if (licenseUnlocked && !showToast && System.currentTimeMillis() - lastCheck < LICENSE_CHECK_INTERVAL_MS) return;
        if (licenseCheckInProgress) return;

        checkLicenseDirect(server, showToast, true, null);
    }

    private void verifyActivationFromBrowser(final String server, final Dialog dialog,
                                             final TextView status, final boolean closeIfFail) {
        checkLicenseDirect(server, false, false, new ApiCallback() {
            @Override
            public void onResult(boolean success, JSONObject data, String error) {
                if (success) {
                    status.setText("Aktivasi berhasil. Aplikasi dibuka…");
                    status.setTextColor(Color.rgb(22, 101, 52));
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    startBrowserIfNeeded();
                    return;
                }
                if (closeIfFail) {
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    finish();
                } else if (error != null && error.length() > 0) {
                    status.setText("Masukkan key pada halaman di bawah. " + error);
                    status.setTextColor(Color.rgb(71, 85, 105));
                }
            }
        });
    }

    private void checkLicenseDirect(final String server, final boolean showToast,
                                    final boolean lockOnFail, final ApiCallback callback) {
        if (licenseCheckInProgress) return;
        licenseCheckInProgress = true;
        refreshNetworkRoute();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = checkWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, checkWeb, true);
                        } catch (Exception ignored) {}
                    }

                    checkWeb.setAlpha(0.01f);
                    checkWeb.setWebChromeClient(new WebChromeClient());
                    checkWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLicenseCheckFromWebView(view, server, showToast, lockOnFail, callback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, description == null ? "Server tidak tersambung" : description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(checkWeb, params);
                    } else {
                        root.addView(checkWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) {
                        finished[0] = true;
                        finishLicenseCheckRoute();
                        removeCheckWebView(checkWeb);
                        if (lockOnFail) lockLicense("Sesi login hilang. Login ulang pakai internet.");
                        if (callback != null) callback.onResult(false, null, "Sesi login hilang");
                        return;
                    }
                    StringBuilder url = new StringBuilder(server).append("/check-session.php")
                            .append("?username=").append(URLEncoder.encode(runtimeUsername, "UTF-8"))
                            .append("&session_token=").append(URLEncoder.encode(runtimeSessionToken, "UTF-8"))
                            .append("&device_id=").append(URLEncoder.encode(getInstallDeviceId(), "UTF-8"))
                            .append("&device_name=").append(URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8"))
                            .append("&app_version=").append(URLEncoder.encode(APP_VERSION, "UTF-8"))
                            .append("&api=1&format=json&_t=").append(System.currentTimeMillis());
                    checkWeb.loadUrl(url.toString());
                } catch (Throwable error) {
                    finished[0] = true;
                    finishLicenseCheckRoute();
                    try { removeCheckWebView(checkWeb); } catch (Throwable ignored) {}
                    if (lockOnFail) handleLicenseServerUnavailable(showToast);
                    if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal cek lisensi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, "Timeout cek lisensi");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLicenseCheckFromWebView(final WebView view, final String server, final boolean showToast,
                                             final boolean lockOnFail, final ApiCallback callback,
                                             final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLicenseCheckText(view, server, showToast, lockOnFail, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                finishLicenseCheckRoute();
                removeCheckWebView(view);
                if (lockOnFail) handleLicenseServerUnavailable(showToast);
                if (callback != null) callback.onResult(false, null, "Android terlalu lama untuk cek lisensi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            finishLicenseCheckRoute();
            removeCheckWebView(view);
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
            if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLicenseCheckText(WebView view, String server, boolean showToast,
                                        boolean lockOnFail, ApiCallback callback,
                                        boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        finishLicenseCheckRoute();
        removeCheckWebView(view);

        JSONObject data = jsonFromText(text);
        if (data != null && jsonSaysActive(data)) {
            boolean saved = saveLoginSessionFromJson(server, data);
            if (saved) {
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                startBrowserIfNeeded();
                if (showToast) Toast.makeText(MainActivity.this,
                        data.optString("message", "Lisensi aktif"),
                        Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onResult(true, data, null);
                return;
            }
        }

        String message = data != null ? data.optString("message", "Lisensi belum aktif.") : "Server tidak memberi JSON valid.";
        if (message == null || message.length() == 0) message = "Lisensi belum aktif.";

        if (data == null) {
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
        } else if (lockOnFail) {
            lockLicense(message);
        }
        if (callback != null) callback.onResult(false, data, message);
    }

    private boolean jsonSaysActive(JSONObject data) {
        if (data == null) return false;
        if (data.optBoolean("ok", false) || data.optInt("ok", 0) == 1) return true;
        if (data.optBoolean("success", false) || data.optInt("success", 0) == 1) return true;
        if (data.optBoolean("valid", false) || data.optInt("valid", 0) == 1) return true;
        if (data.optBoolean("active", false) || data.optInt("active", 0) == 1) return true;
        if (data.optBoolean("is_valid", false) || data.optInt("is_valid", 0) == 1) return true;
        if (data.optBoolean("license_valid", false) || data.optInt("license_valid", 0) == 1) return true;
        return "active".equalsIgnoreCase(data.optString("status", ""));
    }

    private boolean saveLoginSessionFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        String username = normalizeUsernameLocal(data.optString("username", runtimeUsername.length() > 0 ? runtimeUsername : preferences.getString(PREF_LICENSE_KEY, "")));
        String token = data.optString("session_token", data.optString("token", runtimeSessionToken));
        if (username.length() < 3 || token.length() == 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

        runtimeUsername = username;
        runtimeSessionToken = token;
        runtimeSessionExpiry = expiryMillis;
        preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putString(PREF_LICENSE_KEY, username)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, "Login user")
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                .remove(PREF_LICENSE_TOKEN)
                .apply();
        return true;
    }

    private boolean saveLicenseFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
        long createdMillis = extractCreatedMillis(data);
        String oldKey = preferences.getString(PREF_LICENSE_KEY, "");
        String oldToken = preferences.getString(PREF_LICENSE_TOKEN, "");
        String key = normalizeKey(data.optString("key", oldKey));
        String token = data.optString("token", oldToken);
        String durationLabel = data.optString("duration_label", preferences.getString(PREF_LICENSE_DURATION_LABEL, ""));

        SharedPreferences.Editor editor = preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis());
        if (key.length() > 0) editor.putString(PREF_LICENSE_KEY, key);
        if (token != null) editor.putString(PREF_LICENSE_TOKEN, token);
        editor.apply();
        return true;
    }

    private long extractExpiryMillis(JSONObject data) {
        if (data == null) return 0L;
        String[] keys = new String[]{"expires_at", "expires", "expiry", "expire_at", "expire_date", "expired_at"};
        for (String k : keys) {
            long v = parseServerMillis(data.optString(k, ""));
            if (v > 0) return v;
        }
        return 0L;
    }

    private long extractServerMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("server_time", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("server_timestamp", ""));
    }

    private long extractCreatedMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("created_at", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("activated_at", ""));
    }

    private void checkLicenseThroughBrowser(final String server, final String key,
                                            final String token, final boolean showToast) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                WebSettings settings = checkWeb.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setDatabaseEnabled(true);

                android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                cookieManager.setAcceptCookie(true);
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        Method method = android.webkit.CookieManager.class.getMethod(
                                "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                        method.invoke(cookieManager, checkWeb, true);
                    } catch (Exception ignored) {
                    }
                }

                checkWeb.setAlpha(0.01f);
                checkWeb.setWebChromeClient(new WebChromeClient());
                checkWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        if (url != null && url.startsWith("iceinject://checked")) {
                            if (!finished[0]) {
                                finished[0] = true;
                                handleBrowserLicenseCheck(url, checkWeb, showToast);
                            }
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                });

                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                webContainer.addView(checkWeb, params);

                try {
                    String url = server + "/check-app.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&token=" + URLEncoder.encode(token, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
                    checkWeb.loadUrl(url);
                } catch (Exception error) {
                    finished[0] = true;
                    removeCheckWebView(checkWeb);
                    handleLicenseServerUnavailable(showToast);
                    return;
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                }, 20000L);
            }
        });
    }

    private void handleBrowserLicenseCheck(String url, WebView checkWeb, boolean showToast) {
        removeCheckWebView(checkWeb);
        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String code = uri.getQueryParameter("code");
            String message = uri.getQueryParameter("message");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if ("1".equals(ok) && expiryMillis > 0) {
                if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
                preferences.edit()
                        .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                        .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : preferences.getLong(PREF_LICENSE_CREATED, 0L))
                        .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? preferences.getString(PREF_LICENSE_DURATION_LABEL, "") : durationLabel)
                        .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                        .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                        .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                        .apply();
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                if (showToast) Toast.makeText(MainActivity.this,
                        message == null ? "Lisensi masih aktif" : message,
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if ("revoked".equals(code) || "expired".equals(code)
                    || "invalid".equals(code) || "not_found".equals(code)) {
                lockLicense(message == null ? "Lisensi tidak aktif." : message);
                return;
            }

            handleLicenseServerUnavailable(showToast);
        } catch (Exception error) {
            handleLicenseServerUnavailable(showToast);
        }
    }

    private void removeCheckWebView(final WebView view) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (view.getParent() instanceof ViewGroup) {
                        ((ViewGroup)view.getParent()).removeView(view);
                    }
                    view.stopLoading();
                    view.destroy();
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void handleLicenseServerUnavailable(boolean showToast) {
        // Mode kerja untuk WiFi perusahaan: kalau server tidak bisa dicek karena tidak ada internet,
        // APK tetap boleh masuk hanya jika lisensi pernah valid online, belum expired, dan masih dalam batas toleransi.
        if (canUseOfflineWorkMode()) {
            licenseUnlocked = true;
            setLicenseBadge("OFFLINE", Color.rgb(202, 138, 4));
            setStatus("Mode kerja offline aktif. Server lisensi tidak terjangkau, tapi key masih dalam batas toleransi dan belum expired.");
            startBrowserIfNeeded();
            if (showToast) {
                Toast.makeText(MainActivity.this,
                        "Mode kerja offline aktif. Nanti saat internet tersedia lisensi dicek ulang.",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }

        lockLicense("Server lisensi tidak bisa dicek dan batas mode kerja offline habis / key belum aktif / sudah expired.");
        if (showToast) {
            Toast.makeText(MainActivity.this,
                    "Hubungkan internet untuk cek lisensi ulang.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void lockLicense(final String reason) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                licenseUnlocked = false;
                runtimeSessionToken = "";
                runtimeUsername = "";
                runtimeSessionExpiry = 0L;
                setLicenseBadge("TERKUNCI", Color.rgb(185, 28, 28));
                setStatus(reason);
                showActivationDialog(true);
            }
        });
    }

    private boolean canUseOfflineWorkMode() {
        if (ADMIN_BUILD) return true;
        if (!licenseUnlocked) return false;
        if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) return false;
        if (!isCachedLicenseValid()) return false;
        long elapsedAtLastSuccess = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);
        if (elapsedAtLastSuccess > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtLastSuccess;
            return delta >= 0 && delta <= OFFLINE_WORK_GRACE_MS;
        }
        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        return lastCheck > 0 && System.currentTimeMillis() - lastCheck <= OFFLINE_WORK_GRACE_MS;
    }

    private boolean isCachedLicenseValid() {
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry <= 0) return false;
        return trustedNowMillis() < expiry;
    }

    private long trustedNowMillis() {
        long wall = System.currentTimeMillis();
        long server = preferences.getLong(PREF_LAST_SERVER_TIME, 0L);
        long elapsedAtServer = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);

        if (server > 0 && elapsedAtServer > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtServer;
            if (delta >= 0) {
                // Gunakan waktu server yang berjalan dengan elapsedRealtime, bukan jam HP.
                return server + delta;
            }
        }
        return wall;
    }

    private void updateLicenseBadgeFromCache() {
        if (ADMIN_BUILD) {
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            return;
        }
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry > trustedNowMillis()) {
            long remaining = expiry - trustedNowMillis();
            setLicenseBadge(shortRemaining(remaining), Color.rgb(22, 163, 74));
        } else {
            setLicenseBadge("HABIS", Color.rgb(185, 28, 28));
        }
    }

    private void setLicenseBadge(final String text, final int color) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (licenseBadge != null) {
                    licenseBadge.setText(text);
                    licenseBadge.setBackground(makeRounded(color, dp(14)));
                }
            }
        });
    }

    private String shortRemaining(long millis) {
        long minutes = Math.max(0, millis / 60000L);
        if (minutes < 60) return minutes + "m";
        long hours = minutes / 60;
        if (hours < 24) return hours + "j";
        long days = hours / 24;
        if (days < 365) return days + "h";
        return (days / 365) + "th";
    }

    private String longRemaining(long millis) {
        long totalMinutes = Math.max(0L, millis / 60000L);
        long days = totalMinutes / 1440L;
        long hours = (totalMinutes % 1440L) / 60L;
        long minutes = totalMinutes % 60L;
        StringBuilder out = new StringBuilder();
        if (days > 0) out.append(days).append(" hari ");
        if (hours > 0 || days > 0) out.append(hours).append(" jam ");
        out.append(minutes).append(" menit");
        return out.toString().trim();
    }

    private String formatDate(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID"));
        format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
        return format.format(new Date(millis));
    }

    private void postApi(final String endpoint, final Map<String, String> params, final ApiCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                JSONObject data = null;
                String error = null;
                boolean success = false;

                try {
                    StringBuilder body = new StringBuilder();
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        if (body.length() > 0) body.append('&');
                        body.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                        body.append('=');
                        body.append(URLEncoder.encode(entry.getValue() == null ? "" : entry.getValue(), "UTF-8"));
                    }

                    URL targetUrl = new URL(endpoint);
                    connection = (HttpURLConnection) (cellularNetwork != null
                            ? cellularNetwork.openConnection(targetUrl)
                            : targetUrl.openConnection());
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(12000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "ICE-Inject/2.3 Android");

                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
                    writer.write(body.toString());
                    writer.flush();
                    writer.close();

                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 400
                            ? connection.getInputStream()
                            : connection.getErrorStream();
                    String response = readStream(stream);
                    if (response.length() > 0) data = jsonFromText(response);
                    success = code >= 200 && code < 300 && data != null;
                    if (data == null && response != null && response.trim().startsWith("<")) {
                        error = "Server membalas HTML, bukan JSON. Gunakan metode WebView/Buka Web.";
                    } else if (data == null) {
                        error = "Respons server kosong atau bukan JSON.";
                    } else if (!success) {
                        error = data.optString("message", "HTTP " + code);
                    }
                } catch (Throwable throwable) {
                    error = throwable.getMessage();
                    if (error == null || error.length() == 0) error = throwable.getClass().getSimpleName();
                } finally {
                    if (connection != null) connection.disconnect();
                }

                final boolean finalSuccess = success;
                final JSONObject finalData = data;
                final String finalError = error;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onResult(finalSuccess, finalData, finalError);
                    }
                });
            }
        }).start();
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) output.append(line);
        reader.close();
        return output.toString();
    }

    private String getInstallDeviceId() {
        String id = null;
        try {
            id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Throwable ignored) {}

        if (id == null || id.length() < 6) {
            id = preferences.getString(PREF_DEVICE_ID, "");
            if (id.length() < 6) {
                id = "ICE-" + Long.toHexString(System.currentTimeMillis()) + "-" + Integer.toHexString((int) (Math.random() * Integer.MAX_VALUE));
                preferences.edit().putString(PREF_DEVICE_ID, id).apply();
            }
        }
        return id;
    }

    private String normalizeKey(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US).replace(' ', '-');
    }

    private String normalizeUsernameLocal(String value) {
        if (value == null) return "";
        String v = value.trim().toLowerCase(Locale.US);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') {
                out.append(c);
            }
        }
        return out.toString();
    }

    private String normalizeServerUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return "";
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private String normalizeUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return DEFAULT_URL;
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        return url;
    }

    private String shortUrl(String url) {
        if (url == null) return "website";
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return host == null ? url : host;
        } catch (Throwable ignored) {
            return url;
        }
    }

    private String maskKey(String key) {
        if (key == null || key.length() < 8) return "-";
        return key.substring(0, Math.min(7, key.length())) + "••••" + key.substring(Math.max(0, key.length() - 4));
    }

    private String quoteJs(String value) {
        if (value == null) return "\"\"";
        StringBuilder out = new StringBuilder(value.length() + 16);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                default:
                    if (c < 32 || c > 126) {
                        String hex = Integer.toHexString(c);
                        out.append("\\u");
                        for (int j = hex.length(); j < 4; j++) out.append('0');
                        out.append(hex);
                    } else {
                        out.append(c);
                    }
            }
        }
        out.append('"');
        return out.toString();
    }

    private void setStatus(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusText != null) statusText.setText(message == null ? "" : message);
            }
        });
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            Method method = Activity.class.getMethod("checkSelfPermission", String.class);
            Object result = method.invoke(this, permission);
            return result instanceof Integer && ((Integer) result) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean hasCameraPermission() {
        return hasPermission("android.permission.CAMERA");
    }

    private boolean hasLocationPermission() {
        return hasPermission("android.permission.ACCESS_FINE_LOCATION")
                || hasPermission("android.permission.ACCESS_COARSE_LOCATION");
    }

    private void requestPermissionsCompat(String[] permissions, int requestCode, String errorText) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            Method method = Activity.class.getMethod("requestPermissions", String[].class, int.class);
            method.invoke(this, new Object[] { permissions, requestCode });
        } catch (Throwable ignored) {
            setStatus(errorText);
        }
    }

    private void requestCameraPermissionIfNeeded() {
        if (hasCameraPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] { "android.permission.CAMERA" },
                CAMERA_PERMISSION_REQUEST,
                "Berikan izin kamera dari Pengaturan aplikasi.");
    }

    private void requestLocationPermissionIfNeeded() {
        if (hasLocationPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] {
                        "android.permission.ACCESS_FINE_LOCATION",
                        "android.permission.ACCESS_COARSE_LOCATION"
                },
                LOCATION_PERMISSION_REQUEST,
                "Berikan izin lokasi dari Pengaturan aplikasi.");
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean granted = grantResults != null && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (granted) {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera diberikan.");
            } else {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.deny();
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            return;
        }

        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if ((granted || hasLocationPermission())
                    && pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, true, false);
                setStatus("Izin lokasi diberikan.");
            } else if (pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, false, false);
                setStatus("Izin lokasi ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            pendingGeolocationCallback = null;
            pendingGeolocationOrigin = null;
            if (pendingWorkWifiPermission) {
                pendingWorkWifiPermission = false;
                if (granted || hasLocationPermission()) {
                    showDualNetworkInfo();
                } else {
                    setStatus("Izin lokasi diperlukan untuk memilih Wi-Fi kerja.");
                }
            }
        }
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(makeRounded(Color.rgb(51, 65, 85), dp(9)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36));
        params.setMargins(dp(4), 0, 0, 0);
        button.setLayoutParams(params);
        return button;
    }


    private GradientDrawable makeRounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && currentTab != null && currentTab.webView.canGoBack()) {
            currentTab.webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onPause() {
        super.onPause();
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onPause();
                if (tab != currentTab) tab.webView.pauseTimers();
            } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        discoverExistingNetworks();
        refreshNetworkRoute();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                maybeAutoConnectWorkWifi();
            }
        }, 800L);
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onResume();
                if (tab == currentTab) tab.webView.resumeTimers();
            } catch (Throwable ignored) {}
        }
        if (!ADMIN_BUILD) {
            // Jika sesi masih hidup, cek server saat kembali aktif. Jika proses APK mati, token memori hilang dan harus login ulang.
            if (licenseUnlocked && runtimeSessionToken.length() > 0) {
                preferences.edit().putLong(PREF_LAST_CHECK, 0L).apply();
                validateLicenseAsync(false);
                startLicenseWatchdog();
            }
        }
    }

    @Override
    protected void onDestroy() {
        runtimeSessionToken = "";
        runtimeUsername = "";
        runtimeSessionExpiry = 0L;
        preferences.edit().remove(PREF_LICENSE_TOKEN).remove(PREF_LICENSE_EXPIRY).apply();
        handler.removeCallbacksAndMessages(null);
        for (TabState tab : new ArrayList<TabState>(tabs)) {
            tab.destroyed = true;
            tab.webView.destroy();
        }
        tabs.clear();
        try {
            if (connectivityManager != null && networkCallbacksRegistered) {
                if (wifiNetworkCallback != null) connectivityManager.unregisterNetworkCallback(wifiNetworkCallback);
                if (cellularNetworkCallback != null) connectivityManager.unregisterNetworkCallback(cellularNetworkCallback);
            }
        } catch (Throwable ignored) {}
        try {
            if (connectivityManager != null && localOnlyWifiCallback != null) {
                connectivityManager.unregisterNetworkCallback(localOnlyWifiCallback);
            }
        } catch (Throwable ignored) {}
        clearProcessNetworkBinding();
        super.onDestroy();
    }

}
