ICE Inject User v2.8.11

Perbaikan dari v2.8.10:
- Sistem penyambungan dan penangkapan Wi-Fi dikembalikan persis ke dasar v2.8.9.
- Menghapus routing terlalu luas untuk 10.x, 192.168.x, localhost, .local, dan .lan.
- Akses jaringan perusahaan diperluas secara minimal ke seluruh 172.30.0.0/16.
- Report 172.30.2.40:8081 dan semua 172.30.x.x tetap diarahkan melalui Wi-Fi perusahaan.
- Internet umum serta server login/lisensi tetap memakai data seluler.

Catatan: perubahan ini tidak mengubah driver, daya pancar, atau RSSI Android. Fokusnya mencegah aplikasi memaksa terlalu banyak alamat ke Wi-Fi kerja, yang pada v2.8.10 dapat terasa kurang stabil.
