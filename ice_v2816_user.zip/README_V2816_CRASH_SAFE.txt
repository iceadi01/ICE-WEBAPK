ICE Inject v2.8.16 USER — Crash-safe Dual Network

Perubahan:
- Proses VPN/native dipisahkan dari proses browser agar crash mesin tunnel tidak menutup ICE.
- Status VPN dikirim lewat broadcast lintas proses, bukan static memory.
- Startup foreground service Android 15 memakai fallback aman.
- Marker crash native ditulis agar aplikasi dapat menampilkan bahwa mesin VPN berhenti mendadak.
- Workflow mengambil mesin Hev yang dipakai Sockstun 7.0 sebagai basis Android yang lebih teruji.
- Basis koneksi Wi-Fi dan browser tetap dari v2.8.9.

Catatan:
- Hapus APK versi lama lalu pasang APK v2.8.16 jika Android menolak update.
- Aktifkan Wi-Fi kerja terlebih dahulu, kemudian aktifkan DUAL SISTEM.
- Bila mesin VPN masih berhenti, ICE tidak ikut tertutup dan status error muncul di dalam aplikasi.
