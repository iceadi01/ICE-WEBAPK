ICE Inject v2.8.18 USER — Wi-Fi Global tanpa VPN

Perubahan:
- Menghapus VpnService, Hev, SOCKS5 lokal, JNI, dan NDK.
- Wi-Fi perusahaan disimpan melalui halaman resmi Android ACTION_WIFI_ADD_NETWORKS.
- Setelah disetujui, jaringan diperlakukan seperti Wi-Fi yang ditambahkan manual oleh pengguna.
- ICE tetap memakai routing v2.8.9: LP4M melalui Wi-Fi, login/lisensi dan internet ICE melalui data seluler.
- Chrome/browser lain dapat mencoba LP4M melalui Wi-Fi global.

Cara pakai:
1. Nyalakan data seluler.
2. Tekan badge jaringan ICE.
3. Isi SSID/password lalu Simpan & Sambungkan.
4. Setujui halaman Android.
5. Pilih Wi-Fi perusahaan dan pilih Tetap terhubung jika Android menyatakan tidak ada internet.
6. Coba LP4M dari Chrome.

Batasan:
- Tanpa root/VPN, pemilihan jalur internet aplikasi lain tetap ditentukan Android/HiOS.
- Jika HiOS tidak mengizinkan data seluler sebagai fallback saat Wi-Fi tanpa internet aktif, internet umum di browser lain dapat tetap terganggu.
