ICE Inject v2.8.9.2 - Direct Callback Ready

- Callback scanner dipersiapkan otomatis saat halaman dimuat.
- Tidak perlu membuka kamera scan terlebih dahulu untuk memakai input Tampermonkey/ICE.
- Auto-prewarm hanya dijalankan pada domain LP4M/Liebrapermana.
- Saat prewarm, Html5Qrcode start/render dicegat sehingga kamera tidak dinyalakan.
- Fallback input diperkuat: Shadow DOM, iframe same-origin, beforeinput/input/change, dan tombol Enter.
- Listener callback global dan event scanner ikut ditangkap sejak awal.
- Kamera asli tetap berfungsi normal saat pengguna benar-benar membukanya.
- versionCode 31.
