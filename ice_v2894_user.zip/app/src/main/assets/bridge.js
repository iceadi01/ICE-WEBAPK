(function () {
  'use strict';

  var w = window;
  var VERSION = 7;
  var existing = w.__LPWScannerBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }

  var callbacks = [];
  var patched = {};
  var patchTimers = [];
  var observer = null;
  var lastPatchAt = 0;
  var lastGuideAt = 0;
  var lastCount = -1;
  var recent = {};
  var queue = [];
  var processing = false;
  var destroyed = false;
  var prewarmRunning = false;
  var suppressNextScannerStart = false;
  var prewarmDone = false;
  var prewarmAttempts = 0;
  var prewarmTimer = 0;
  var namedHooksInstalled = false;
  var eventHookInstalled = false;
  var barcodeDetectorActive = false;
  var jsQrActive = false;
  var pendingVirtualScans = [];
  var activeTarget = null;
  var activeTargetLabel = '';
  var activeTargetAuto = false;
  var scanTargets = [];
  var lastTargetState = '';
  var lastUrl = String(w.location && w.location.href || '');

  var MAX_CALLBACKS = 4;
  var MAX_QUEUE = 24;
  var CALLBACK_TTL = 12 * 60 * 60 * 1000;
  var DUPLICATE_MS = 1100;
  var SEND_GAP_MS = 140;

  function now() { return Date.now ? Date.now() : new Date().getTime(); }

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount(force) {
    var count = callbacks.length + virtualRouteCount();
    if (!force && count === lastCount) return;
    lastCount = count;
    androidCall('onCallbackCount', [count]);
  }

  function callbackSources() {
    var out = [];
    for (var i = callbacks.length - 1; i >= 0; i--) {
      var source = callbacks[i] && callbacks[i].source;
      if (source && out.indexOf(source) < 0) out.push(source);
    }
    return out;
  }

  function cleanupRecent() {
    var cutoff = now() - Math.max(DUPLICATE_MS * 4, 10000);
    for (var key in recent) {
      if (Object.prototype.hasOwnProperty.call(recent, key) && recent[key] < cutoff) {
        delete recent[key];
      }
    }
  }

  function cleanupCallbacks() {
    var cutoff = now() - CALLBACK_TTL;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      if (entry.addedAt && entry.addedAt < cutoff) continue;
      next.push(entry);
    }
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    source = source || 'callback';
    mode = mode || 'html5';

    var stamp = now();
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source, mode: mode, addedAt: stamp });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
    report('Scanner siap. Jalur aktif: ' + source + '.');
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: {
        text: text,
        format: { formatName: 'QR_CODE', format: 'QR_CODE' }
      }
    };
  }

  function wrapMethod(proto, name, makeWrapper, key) {
    try {
      if (!proto || typeof proto[name] !== 'function') return false;
      if (proto[name].__iceBridgeV4) return true;
      var original = proto[name];
      var wrapped = makeWrapper(original);
      wrapped.__iceBridgeV4 = true;
      wrapped.__iceOriginal = original;
      proto[name] = wrapped;
      patched[key || name] = true;
      return true;
    } catch (_) {
      return false;
    }
  }



  function virtualRouteCount() {
    var count = 0;
    if (barcodeDetectorActive) count++;
    if (jsQrActive) count++;
    return count;
  }

  function fakeBarcodeDetection(text) {
    return {
      rawValue: text,
      format: 'qr_code',
      boundingBox: { x: 0, y: 0, width: 100, height: 100, top: 0, right: 100, bottom: 100, left: 0 },
      cornerPoints: [
        { x: 0, y: 0 }, { x: 100, y: 0 },
        { x: 100, y: 100 }, { x: 0, y: 100 }
      ]
    };
  }

  function fakeJsQrResult(text) {
    return {
      data: text,
      binaryData: [],
      chunks: [],
      version: 1,
      location: {
        topRightCorner: { x: 100, y: 0 },
        topLeftCorner: { x: 0, y: 0 },
        bottomRightCorner: { x: 100, y: 100 },
        bottomLeftCorner: { x: 0, y: 100 },
        topRightFinderPattern: { x: 90, y: 10 },
        topLeftFinderPattern: { x: 10, y: 10 },
        bottomLeftFinderPattern: { x: 10, y: 90 },
        bottomRightAlignmentPattern: { x: 90, y: 90 }
      }
    };
  }

  function patchBarcodeDetectorRoute() {
    try {
      var Detector = w.BarcodeDetector;
      if (!Detector || !Detector.prototype || typeof Detector.prototype.detect !== 'function') return;
      wrapMethod(Detector.prototype, 'detect', function (original) {
        return function () {
          if (!barcodeDetectorActive) {
            barcodeDetectorActive = true;
            reportCount(true);
            report('Jalur BarcodeDetector terdeteksi.');
          }
          if (pendingVirtualScans.length) {
            var text = pendingVirtualScans.shift();
            try { return w.Promise.resolve([fakeBarcodeDetection(text)]); }
            catch (_) { return [{ rawValue: text, format: 'qr_code' }]; }
          }
          return original.apply(this, arguments);
        };
      }, 'BarcodeDetector.detect');
    } catch (_) {}
  }

  function patchJsQrRoute() {
    try {
      var original = w.jsQR;
      if (typeof original !== 'function' || original.__iceBridgeV7) return;
      var wrapped = function () {
        if (!jsQrActive) {
          jsQrActive = true;
          reportCount(true);
          report('Jalur jsQR terdeteksi.');
        }
        if (pendingVirtualScans.length) return fakeJsQrResult(pendingVirtualScans.shift());
        return original.apply(this, arguments);
      };
      wrapped.__iceBridgeV7 = true;
      wrapped.__iceOriginal = original;
      try {
        for (var key in original) {
          if (Object.prototype.hasOwnProperty.call(original, key)) wrapped[key] = original[key];
        }
      } catch (_) {}
      w.jsQR = wrapped;
    } catch (_) {}
  }

  function patchZxingClass(ctor, label) {
    if (!ctor || !ctor.prototype) return;
    var methods = [
      'decodeFromVideoDevice', 'decodeFromConstraints', 'decodeFromStream',
      'decodeContinuously', 'decodeFromVideoElementContinuously'
    ];
    for (var i = 0; i < methods.length; i++) {
      (function (name) {
        wrapMethod(ctor.prototype, name, function (original) {
          return function () {
            var args = Array.prototype.slice.call(arguments);
            for (var j = args.length - 1; j >= 0; j--) {
              if (typeof args[j] === 'function') {
                addCallback(args[j], label + '.' + name, 'zxing');
                break;
              }
            }
            return original.apply(this, args);
          };
        }, label + '.' + name);
      })(methods[i]);
    }
  }

  function patchZxingRoutes() {
    try {
      var spaces = [w.ZXing, w.ZXingBrowser, w.zxing];
      for (var i = 0; i < spaces.length; i++) {
        var ns = spaces[i];
        if (!ns) continue;
        patchZxingClass(ns.BrowserQRCodeReader, 'ZXing.BrowserQRCodeReader');
        patchZxingClass(ns.BrowserMultiFormatReader, 'ZXing.BrowserMultiFormatReader');
        patchZxingClass(ns.BrowserCodeReader, 'ZXing.BrowserCodeReader');
      }
      patchZxingClass(w.BrowserQRCodeReader, 'BrowserQRCodeReader');
      patchZxingClass(w.BrowserMultiFormatReader, 'BrowserMultiFormatReader');
    } catch (_) {}
  }

  function patchLegacyQrcodeCallback() {
    try {
      var qr = w.qrcode;
      if (!qr || qr.__iceCallbackHookV7) return;
      var descriptor = Object.getOwnPropertyDescriptor(qr, 'callback');
      if (descriptor && descriptor.configurable === false) {
        if (typeof qr.callback === 'function') addCallback(qr.callback, 'qrcode.callback', 'text');
        return;
      }
      var current = typeof qr.callback === 'function' ? qr.callback : null;
      if (current) addCallback(current, 'qrcode.callback', 'text');
      Object.defineProperty(qr, 'callback', {
        configurable: true,
        enumerable: true,
        get: function () { return current; },
        set: function (value) {
          current = value;
          if (typeof value === 'function') addCallback(value, 'qrcode.callback', 'text');
        }
      });
      qr.__iceCallbackHookV7 = true;
    } catch (_) {}
  }

  function patchVirtualRoutes() {
    patchBarcodeDetectorRoute();
    patchJsQrRoute();
    patchZxingRoutes();
    patchLegacyQrcodeCallback();
  }

  function queueVirtualScan(text) {
    if (!barcodeDetectorActive && !jsQrActive) return '';
    if (pendingVirtualScans.length >= 8) pendingVirtualScans.shift();
    pendingVirtualScans.push(text);
    return barcodeDetectorActive ? 'BarcodeDetector' : 'jsQR';
  }

  function patchHtml5Qrcode() {
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrapMethod(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, prewarmRunning ? 'ICE.prewarm.Html5Qrcode.start' : 'Html5Qrcode.start', 'html5');
            if (prewarmRunning || suppressNextScannerStart) {
              suppressNextScannerStart = false;
              prewarmDone = true;
              report('Callback scanner siap tanpa membuka kamera.');
              try { return w.Promise ? w.Promise.resolve(null) : null; } catch (_) { return null; }
            }
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        }, 'Html5Qrcode.start');
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrapMethod(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, prewarmRunning ? 'ICE.prewarm.Html5QrcodeScanner.render' : 'Html5QrcodeScanner.render', 'html5');
            if (prewarmRunning || suppressNextScannerStart) {
              suppressNextScannerStart = false;
              prewarmDone = true;
              report('Callback scanner siap tanpa membuka kamera.');
              return;
            }
            return original.call(this, successCallback, errorCallback);
          };
        }, 'Html5QrcodeScanner.render');
      }
    } catch (_) {}
  }

  function patchOtherLibraries() {
    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__iceBridgeV4Wrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__iceBridgeV4Wrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}

    try {
      var InstascanScanner = w.Instascan && w.Instascan.Scanner;
      if (typeof InstascanScanner === 'function' && InstascanScanner.prototype) {
        wrapMethod(InstascanScanner.prototype, 'addListener', function (original) {
          return function (eventName, callback) {
            if (String(eventName).toLowerCase() === 'scan') {
              addCallback(callback, 'Instascan.addListener', 'text');
            }
            return original.call(this, eventName, callback);
          };
        }, 'Instascan.addListener');
      }
    } catch (_) {}

    try {
      var Quagga = w.Quagga;
      if (Quagga && typeof Quagga.onDetected === 'function' && !Quagga.onDetected.__iceBridgeV4) {
        var originalOnDetected = Quagga.onDetected;
        var wrappedOnDetected = function (callback) {
          addCallback(callback, 'Quagga.onDetected', 'quagga');
          return originalOnDetected.call(this, callback);
        };
        wrappedOnDetected.__iceBridgeV4 = true;
        Quagga.onDetected = wrappedOnDetected;
      }
    } catch (_) {}
  }

  function tryContinuousFocus(video) {
    try {
      if (!video || !video.srcObject || !video.srcObject.getVideoTracks) return;
      var track = video.srcObject.getVideoTracks()[0];
      if (!track || track.__iceFocusV4) return;
      track.__iceFocusV4 = true;
      if (!track.getCapabilities || !track.applyConstraints) return;
      var caps = track.getCapabilities() || {};
      if (caps.focusMode && Array.prototype.indexOf.call(caps.focusMode, 'continuous') >= 0) {
        track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {});
      }
    } catch (_) {}
  }

  function directGuide(parent) {
    try {
      var children = parent.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i] && children[i].classList && children[i].classList.contains('ice-scan-guide')) {
          return children[i];
        }
      }
    } catch (_) {}
    return null;
  }

  function ensureScannerGuide() {
    if (document.hidden) return;
    var videos = [];
    try { videos = Array.prototype.slice.call(document.querySelectorAll('video')); } catch (_) {}
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      try {
        var rect = video.getBoundingClientRect();
        var style = w.getComputedStyle(video);
        if (rect.width < 160 || rect.height < 120 || style.display === 'none' || style.visibility === 'hidden') continue;
        tryContinuousFocus(video);
        var parent = video.parentElement;
        if (!parent || directGuide(parent)) continue;
        if (w.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

        var guide = document.createElement('div');
        guide.className = 'ice-scan-guide';
        guide.setAttribute('aria-hidden', 'true');
        guide.innerHTML = '<span>Pas-kan QR / barcode di dalam kotak</span><b></b>';
        guide.style.cssText = 'position:absolute;left:8%;right:8%;top:23%;height:48%;z-index:2147483000;pointer-events:none;border:2px solid rgba(34,197,94,.9);border-radius:14px;box-sizing:border-box;';
        var label = guide.querySelector('span');
        if (label) label.style.cssText = 'position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.82);color:#fff;border-radius:999px;padding:6px 10px;font:600 12px system-ui,sans-serif;';
        var line = guide.querySelector('b');
        if (line) line.style.cssText = 'position:absolute;left:7%;right:7%;top:50%;height:2px;background:#22c55e;box-shadow:0 0 8px #22c55e;';
        parent.appendChild(guide);
      } catch (_) {}
    }
  }


  function installNamedCallbackHooks() {
    if (namedHooksInstalled) return;
    namedHooksInstalled = true;
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      (function (name) {
        try {
          var descriptor = Object.getOwnPropertyDescriptor(w, name);
          if (descriptor && descriptor.configurable === false) {
            if (typeof w[name] === 'function') addCallback(w[name], 'window.' + name, 'html5');
            return;
          }
          var current = typeof w[name] === 'function' ? w[name] : null;
          if (current) addCallback(current, 'window.' + name, 'html5');
          Object.defineProperty(w, name, {
            configurable: true,
            enumerable: descriptor ? descriptor.enumerable : true,
            get: function () { return current; },
            set: function (value) {
              current = value;
              if (typeof value === 'function') addCallback(value, 'window.' + name, 'html5');
            }
          });
        } catch (_) {}
      })(names[i]);
    }
  }

  function installEventListenerHook() {
    if (eventHookInstalled) return;
    eventHookInstalled = true;
    try {
      var proto = w.EventTarget && w.EventTarget.prototype;
      if (!proto || typeof proto.addEventListener !== 'function' || proto.addEventListener.__iceBridgeV5) return;
      var original = proto.addEventListener;
      var wrapped = function (type, listener, options) {
        try {
          var key = String(type || '').toLowerCase();
          if (typeof listener === 'function' && /(scan|barcode|qrcode|qr-scanned)/.test(key)) {
            addCallback(listener, 'event:' + key, 'event');
          }
        } catch (_) {}
        return original.call(this, type, listener, options);
      };
      wrapped.__iceBridgeV5 = true;
      wrapped.__iceOriginal = original;
      proto.addEventListener = wrapped;
    } catch (_) {}
  }

  function elementText(el) {
    try {
      return [
        el.innerText, el.textContent, el.id, el.className, el.title,
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('data-testid')
      ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
    } catch (_) { return ''; }
  }

  function scannerTriggerScore(el) {
    var text = elementText(el);
    var score = 0;
    if (/scan\s*(qr|barcode)|(?:qr|barcode)\s*scan/.test(text)) score += 150;
    if (/buka\s*(kamera|camera)|kamera\s*scan|camera\s*scan/.test(text)) score += 120;
    if (/scanner|scan/.test(text)) score += 55;
    if (/qr|qrcode|barcode/.test(text)) score += 45;
    if (/kamera|camera/.test(text)) score += 30;
    if (/foto|photo|galeri|gallery|upload|lampiran/.test(text)) score -= 90;
    if (/tutup|close|batal|cancel|kembali|back|hapus|delete/.test(text)) score -= 160;
    try {
      if (el.disabled || el.getAttribute('aria-disabled') === 'true') score -= 100;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 10;
      var style = w.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden') score -= 80;
    } catch (_) {}
    return score;
  }

  function findScannerTrigger() {
    var nodes = [];
    try { nodes = Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')); } catch (_) {}
    var best = null;
    var bestScore = 89;
    var limit = Math.min(nodes.length, 350);
    for (var i = 0; i < limit; i++) {
      var score = scannerTriggerScore(nodes[i]);
      if (score > bestScore) { best = nodes[i]; bestScore = score; }
    }
    return best;
  }

  function closePrewarmUi() {
    try {
      var nodes = Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"]'));
      var best = null;
      var score = 0;
      for (var i = 0; i < Math.min(nodes.length, 300); i++) {
        var text = elementText(nodes[i]);
        var current = 0;
        if (/^(×|x)$/.test(text)) current += 90;
        if (/tutup|close|batal|cancel|kembali|back/.test(text)) current += 70;
        try {
          var rect = nodes[i].getBoundingClientRect();
          if (rect.width > 15 && rect.height > 12) current += 10;
        } catch (_) {}
        if (current > score) { best = nodes[i]; score = current; }
      }
      if (best && score >= 70) best.click();
    } catch (_) {}
  }

  function shouldAutoPrewarm() {
    try {
      var host = String(w.location && w.location.hostname || '').toLowerCase();
      return host === 'lp4m-lpw.liebrapermana.com' || /(^|\.)liebrapermana\.com$/.test(host);
    } catch (_) { return false; }
  }

  function prewarmScanner() {
    if (destroyed || prewarmRunning || suppressNextScannerStart || prewarmDone || callbacks.length > 0) return;
    if (!shouldAutoPrewarm()) return;
    if (!document.body) return;
    if (prewarmAttempts >= 4) return;
    var trigger = findScannerTrigger();
    if (!trigger) return;

    prewarmAttempts++;
    prewarmRunning = true;
    suppressNextScannerStart = true;
    report('Menyiapkan callback scanner otomatis…');
    try { trigger.click(); } catch (_) { prewarmRunning = false; suppressNextScannerStart = false; return; }

    w.setTimeout(function () {
      prewarmRunning = false;
      if (callbacks.length > 0) {
        suppressNextScannerStart = false;
        prewarmDone = true;
        closePrewarmUi();
        report('Tampermonkey siap tanpa membuka kamera.');
      } else {
        closePrewarmUi();
      }
      reportCount(true);
    }, 900);

    w.setTimeout(function () {
      if (!prewarmDone) suppressNextScannerStart = false;
    }, 2400);
  }

  function schedulePrewarm() {
    if (prewarmTimer) {
      try { w.clearTimeout(prewarmTimer); } catch (_) {}
    }
    var delays = [250, 3000, 6500, 11000, 18000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        w.setTimeout(function () {
          patch();
          prewarmScanner();
        }, delay);
      })(delays[i]);
    }
  }

  function patch() {
    if (destroyed) return;
    var stamp = now();
    if (stamp - lastPatchAt < 220) return;
    lastPatchAt = stamp;
    var currentUrl = String(w.location && w.location.href || '');
    if (lastUrl && currentUrl && currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      scanTargets = [];
      clearActiveTarget('navigation', false);
    } else if (!lastUrl) lastUrl = currentUrl;
    cleanupCallbacks();
    cleanupRecent();
    installNamedCallbackHooks();
    installEventListenerHook();
    installTargetListenersDeep();
    patchHtml5Qrcode();
    patchOtherLibraries();
    patchVirtualRoutes();
    refreshScanTargets(false);
    if (stamp - lastGuideAt > 1200) {
      lastGuideAt = stamp;
      ensureScannerGuide();
    }
    reportCount(false);
  }

  function clearPatchTimers() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
  }

  function schedulePatch() {
    clearPatchTimers();
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000, 22000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(function () {
          patch();
        }, delay));
      })(delays[i]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function (records) {
      if (destroyed || document.hidden) return;
      var useful = false;
      for (var i = 0; i < records.length && !useful; i++) {
        var added = records[i].addedNodes || [];
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          var tag = String(node.tagName || '').toLowerCase();
          if (tag === 'video' || tag === 'script' || tag === 'button' || tag === 'a' || tag === 'input' || tag === 'textarea' || tag === 'iframe' || (node.querySelector && node.querySelector('video,script,button,a,input,textarea,iframe,[contenteditable="true"],[role="button"]'))) {
            useful = true;
            break;
          }
        }
      }
      if (!useful || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
  }

  function invokeCallback(entry, text) {
    var detail = decodedResult(text);
    if (entry.mode === 'event') {
      var event;
      try { event = new CustomEvent('scan', { bubbles: true, detail: detail }); }
      catch (_) { event = { type: 'scan', detail: detail, data: text, text: text }; }
      return entry.fn.call(w, event);
    }
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; },
        valueOf: function () { return text; }
      });
    }
    if (entry.mode === 'quagga') {
      return entry.fn({
        codeResult: { code: text, format: 'code_128' },
        result: { code: text }
      });
    }
    if (entry.mode === 'zxing') {
      return entry.fn({
        text: text,
        rawValue: text,
        getText: function () { return text; },
        getBarcodeFormat: function () { return 'QR_CODE'; },
        toString: function () { return text; }
      }, null);
    }
    return entry.fn(text, detail);
  }

  function invokeLatestCaptured(text) {
    cleanupCallbacks();
    var attempted = 0;
    for (var i = callbacks.length - 1; i >= 0 && attempted < 2; i--) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      attempted++;
      try {
        invokeCallback(entry, text);
        entry.addedAt = now();
        return { called: 1, source: entry.source, errors: 0 };
      } catch (_) {}
    }
    return { called: 0, source: '', errors: attempted };
  }

  function invokeOneNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function fieldScore(el) {
    var meta = targetMeta(el);
    var score = 0;
    if (/input barcode hu here/.test(meta)) score += 160;
    if (/barcode/.test(meta)) score += 70;
    if (/(^|\W)hu($|\W)/.test(meta)) score += 80;
    if (/carton|karton/.test(meta)) score += 52;
    if (/material/.test(meta)) score += 72;
    if (/qr|qrcode/.test(meta)) score += 58;
    if (/scan|scanner/.test(meta)) score += 38;
    if (/kode|code/.test(meta)) score += 28;
    if (/serial|nomor|number/.test(meta)) score += 12;
    if (/search|cari|username|password|email|login/.test(meta)) score -= 80;
    try {
      if (el.disabled || el.type === 'hidden') score -= 60;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 12;
    } catch (_) {}
    return score;
  }

  function collectDeepInputs(root, out, visited) {
    if (!root || visited.length > 1200) return;
    try {
      var fields = root.querySelectorAll('input,textarea,[contenteditable="true"]');
      for (var i = 0; i < fields.length && out.length < 100; i++) {
        if (out.indexOf(fields[i]) < 0) out.push(fields[i]);
      }
      var all = root.querySelectorAll('*');
      for (var j = 0; j < all.length && visited.length < 1200; j++) {
        var node = all[j];
        visited.push(node);
        if (node.shadowRoot) collectDeepInputs(node.shadowRoot, out, visited);
      }
    } catch (_) {}
  }




  function directTargetMeta(el) {
    var parts = [];
    try {
      parts.push(el.id, el.name, el.type, el.placeholder, el.title, el.className);
      if (el.getAttribute) {
        parts.push(el.getAttribute('aria-label'), el.getAttribute('data-testid'),
          el.getAttribute('data-name'), el.getAttribute('data-field'),
          el.getAttribute('data-purpose'), el.getAttribute('autocomplete'),
          el.getAttribute('role'), el.getAttribute('inputmode'));
      }
      var doc = el.ownerDocument || document;
      if (el.id && doc.querySelector) {
        try {
          var explicit = doc.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
          if (explicit) parts.push(explicit.innerText || explicit.textContent);
        } catch (_) {}
      }
      var label = el.closest && el.closest('label');
      if (label) parts.push(label.innerText || label.textContent);
      var prev = el.previousElementSibling;
      if (prev) {
        var prevText = String(prev.innerText || prev.textContent || '').replace(/\s+/g, ' ').trim();
        if (prevText && prevText.length <= 90) parts.push(prevText);
      }
      var parent = el.parentElement;
      if (parent) {
        var children = parent.children || [];
        for (var i = 0; i < children.length; i++) {
          var child = children[i];
          if (child === el) continue;
          var tag = String(child.tagName || '').toLowerCase();
          if (!/^(label|span|small|strong|b|p|div)$/.test(tag)) continue;
          try {
            if (child.querySelector && child.querySelector('input,textarea,[contenteditable="true"],button,a')) continue;
          } catch (_) {}
          var text = String(child.innerText || child.textContent || '').replace(/\s+/g, ' ').trim();
          if (text && text.length <= 90) parts.push(text);
        }
      }
    } catch (_) {}
    return parts.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function hasScanMarker(meta) {
    return /input\s*barcode\s*hu\s*here|(?:^|\W)(?:hu|carton|karton|material|barcode|qr|qrcode|scan|scanner)(?:$|\W)/.test(String(meta || ''));
  }

  function isSearchLikeTarget(el, meta) {
    try {
      var type = String(el.type || '').toLowerCase();
      var role = String(el.getAttribute && el.getAttribute('role') || '').toLowerCase();
      if (type === 'search' || role === 'searchbox') return true;
      if (el.closest && el.closest('[role="search"],form[action*="search" i],form[action*="google" i]')) return true;
    } catch (_) {}
    return /(?:^|\W)(?:search|cari|pencarian|telusuri|penelusuran|query|google|bing|yahoo|duckduckgo|username|password|email|login)(?:$|\W)/.test(String(meta || ''));
  }

  function targetMeta(el) {
    return directTargetMeta(el);
  }

  function describeTarget(el) {
    var meta = targetMeta(el);
    if (/\bhu\b.*\bcarton\b|\bcarton\b.*\bhu\b/.test(meta)) return 'HU Carton';
    if (/\bqr\b.*\bmaterial\b|\bmaterial\b.*\bqr\b/.test(meta)) return 'QR Material';
    if (/\bmaterial\b/.test(meta)) return 'QR Material';
    if (/\bhu\b/.test(meta)) return 'HU';
    if (/\bqr\b|qrcode/.test(meta)) return 'QR';
    if (/barcode/.test(meta)) return 'Barcode';
    if (/scan|scanner/.test(meta)) return 'Kolom Scan';
    var fallback = '';
    try {
      fallback = String(el.placeholder || el.getAttribute('aria-label') || el.name || el.id || 'Kolom Scan').trim();
    } catch (_) { fallback = 'Kolom Scan'; }
    if (fallback.length > 28) fallback = fallback.slice(0, 28) + '…';
    return fallback || 'Kolom Scan';
  }

  function isVisibleTarget(el) {
    try {
      if (!el || el.disabled || String(el.type || '').toLowerCase() === 'hidden') return false;
      var doc = el.ownerDocument || document;
      var view = doc.defaultView || w;
      var style = view.getComputedStyle ? view.getComputedStyle(el) : null;
      if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
      var rect = el.getBoundingClientRect();
      return rect.width > 20 && rect.height > 12;
    } catch (_) { return false; }
  }

  function isScanTarget(el) {
    if (!el || el.nodeType !== 1) return false;
    var tag = String(el.tagName || '').toLowerCase();
    if (tag !== 'input' && tag !== 'textarea' && !el.isContentEditable) return false;
    var type = String(el.type || '').toLowerCase();
    if (/password|email|search|date|time|number|checkbox|radio|file|submit|button/.test(type)) return false;
    var meta = targetMeta(el);
    if (!hasScanMarker(meta) || isSearchLikeTarget(el, meta)) return false;
    return isVisibleTarget(el) && fieldScore(el) >= 38;
  }

  function collectScanTargets() {
    var nodes = [];
    collectDeepInputs(document, nodes, []);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { collectDeepInputs(w.frames[f].document, nodes, []); } catch (_) {}
      }
    } catch (_) {}
    var result = [];
    for (var i = 0; i < Math.min(nodes.length, 300); i++) {
      if (isScanTarget(nodes[i]) && result.indexOf(nodes[i]) < 0) result.push(nodes[i]);
    }
    return result;
  }

  function ensureTargetStyle(doc) {
    try {
      if (!doc || !doc.head || doc.getElementById('ice-scan-target-style-v6')) return;
      var style = doc.createElement('style');
      style.id = 'ice-scan-target-style-v6';
      style.textContent = '.ice-scan-target-active-v6{outline:3px solid #22c55e!important;outline-offset:2px!important;box-shadow:0 0 0 4px rgba(34,197,94,.20)!important;}';
      doc.head.appendChild(style);
    } catch (_) {}
  }

  function notifyTarget(force) {
    var state = scanTargets.length + '|' + (activeTarget ? activeTargetLabel : '') + '|' + (activeTarget ? '1' : '0');
    if (!force && state === lastTargetState) return;
    lastTargetState = state;
    androidCall('onTargetChanged', [activeTargetLabel || '', scanTargets.length, !!activeTarget]);
  }

  function removeTargetHighlight(el) {
    try { if (el && el.classList) el.classList.remove('ice-scan-target-active-v6'); } catch (_) {}
  }

  function setActiveTarget(el, automatic, silent) {
    if (!isScanTarget(el)) return false;
    var changed = activeTarget !== el || activeTargetAuto !== !!automatic;
    if (activeTarget && activeTarget !== el) removeTargetHighlight(activeTarget);
    activeTarget = el;
    activeTargetLabel = describeTarget(el);
    activeTargetAuto = !!automatic;
    ensureTargetStyle(el.ownerDocument || document);
    try { if (el.classList) el.classList.add('ice-scan-target-active-v6'); } catch (_) {}
    notifyTarget(changed);
    if (!silent && changed) {
      report((automatic ? 'Tujuan scan otomatis: ' : 'Tujuan scan: ') + activeTargetLabel + '.');
    }
    return true;
  }

  function clearActiveTarget(reason, silent) {
    var hadTarget = !!activeTarget;
    removeTargetHighlight(activeTarget);
    activeTarget = null;
    activeTargetLabel = '';
    activeTargetAuto = false;
    notifyTarget(hadTarget);
    if (!silent && reason === 'multiple') report('Sentuh kolom tujuan scan terlebih dahulu.');
    if (!silent && reason === 'navigation') report('Halaman berubah. Pilih kembali kolom tujuan scan.');
  }

  function refreshScanTargets(silent) {
    var next = collectScanTargets();
    scanTargets = next;

    if (activeTarget && next.indexOf(activeTarget) < 0) clearActiveTarget('removed', true);

    if (next.length === 1) {
      if (!activeTarget) setActiveTarget(next[0], true, !!silent);
    } else if (next.length > 1) {
      if (activeTarget && activeTargetAuto) clearActiveTarget('multiple', !!silent);
      if (!activeTarget) {
        notifyTarget(false);
        if (!silent) report('Sentuh kolom tujuan scan terlebih dahulu.');
      }
    } else {
      if (activeTarget) clearActiveTarget('removed', true);
      notifyTarget(false);
    }
    return next.length;
  }

  function eventPath(event) {
    try {
      if (event.composedPath) return event.composedPath();
    } catch (_) {}
    var out = [];
    var node = event.target;
    while (node) { out.push(node); node = node.parentNode || node.host; }
    return out;
  }

  function selectTargetFromEvent(event) {
    try { if (event && event.isTrusted === false) return; } catch (_) {}
    refreshScanTargets(true);
    if (!scanTargets.length) return;
    var path = eventPath(event || {});
    var selected = null;
    for (var i = 0; i < path.length && !selected; i++) {
      var node = path[i];
      if (scanTargets.indexOf(node) >= 0) selected = node;
      else if (node && String(node.tagName || '').toLowerCase() === 'label' && node.control && scanTargets.indexOf(node.control) >= 0) selected = node.control;
    }
    if (!selected && event && event.target && event.target.querySelector) {
      try {
        var child = event.target.querySelector('input,textarea,[contenteditable="true"]');
        if (scanTargets.indexOf(child) >= 0) selected = child;
      } catch (_) {}
    }
    if (selected) setActiveTarget(selected, false, false);
  }

  function installTargetListenersInDocument(doc) {
    try {
      if (!doc || doc.__iceTargetListenersV6) return;
      doc.__iceTargetListenersV6 = true;
      ensureTargetStyle(doc);
      var events = ['pointerdown', 'touchstart', 'mousedown', 'focusin', 'click'];
      for (var i = 0; i < events.length; i++) doc.addEventListener(events[i], selectTargetFromEvent, true);
    } catch (_) {}
  }

  function installTargetListenersDeep() {
    installTargetListenersInDocument(document);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { installTargetListenersInDocument(w.frames[f].document); } catch (_) {}
      }
    } catch (_) {}
  }

  function setNativeValue(el, text) {
    var tag = String(el.tagName || '').toLowerCase();
    var view = (el.ownerDocument && el.ownerDocument.defaultView) || w;
    if (tag === 'input') {
      var inputSetter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value');
      if (inputSetter && inputSetter.set) inputSetter.set.call(el, text); else el.value = text;
    } else if (tag === 'textarea') {
      var areaSetter = Object.getOwnPropertyDescriptor(view.HTMLTextAreaElement.prototype, 'value');
      if (areaSetter && areaSetter.set) areaSetter.set.call(el, text); else el.value = text;
    } else if (el.isContentEditable) {
      el.textContent = text;
    }
  }

  function dispatchInputAndEnter(el, text, pressEnter) {
    var view = (el.ownerDocument && el.ownerDocument.defaultView) || w;
    var EventCtor = view.Event || w.Event;
    var InputEventCtor = view.InputEvent || w.InputEvent;
    var KeyboardEventCtor = view.KeyboardEvent || w.KeyboardEvent;
    try { el.focus(); } catch (_) {}
    try { if (InputEventCtor) el.dispatchEvent(new InputEventCtor('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: text })); } catch (_) {}
    try { if (InputEventCtor) el.dispatchEvent(new InputEventCtor('input', { bubbles: true, inputType: 'insertText', data: text })); else throw new Error('no InputEvent'); }
    catch (_) { try { el.dispatchEvent(new EventCtor('input', { bubbles: true })); } catch (_) {} }
    try { el.dispatchEvent(new EventCtor('change', { bubbles: true })); } catch (_) {}
    if (pressEnter !== false) {
      var init = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keydown', init)); } catch (_) {}
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keypress', init)); } catch (_) {}
      try { if (KeyboardEventCtor) el.dispatchEvent(new KeyboardEventCtor('keyup', init)); } catch (_) {}
      try {
        var form = el.closest && el.closest('form');
        if (form) {
          if (typeof form.requestSubmit === 'function') form.requestSubmit();
          else form.dispatchEvent(new EventCtor('submit', { bubbles: true, cancelable: true }));
        }
      } catch (_) {}
    }
  }

  function fillSpecificInput(el, text, pressEnter) {
    if (!el || !isScanTarget(el)) return false;
    try {
      el.disabled = false;
      el.readOnly = false;
      el.removeAttribute('disabled');
      el.removeAttribute('readonly');
      setNativeValue(el, text);
      dispatchInputAndEnter(el, text, pressEnter);
      return true;
    } catch (_) { return false; }
  }

  function fillBestInput(text, pressEnter) {
    var nodes = [];
    collectDeepInputs(document, nodes, []);
    try {
      for (var f = 0; f < w.frames.length; f++) {
        try { collectDeepInputs(w.frames[f].document, nodes, []); } catch (_) {}
      }
    } catch (_) {}
    var best = null;
    var bestScore = 17;
    var limit = Math.min(nodes.length, 300);
    for (var i = 0; i < limit; i++) {
      if (!isScanTarget(nodes[i])) continue;
      var score = fieldScore(nodes[i]);
      if (score > bestScore) { best = nodes[i]; bestScore = score; }
    }
    if (!best) return false;
    return fillSpecificInput(best, text, pressEnter);
  }

  function dispatchFallbackEvents(text) {
    var detail = decodedResult(text);
    var names = ['scanSuccess', 'qr-scanned', 'barcode-scanned'];
    var count = 0;
    for (var i = 0; i < names.length; i++) {
      try {
        document.dispatchEvent(new CustomEvent(names[i], { bubbles: true, detail: detail }));
        count++;
      } catch (_) {}
    }
    return count;
  }

  function processOne(item) {
    patch();
    refreshScanTargets(true);

    var captured = { called: 0, source: '', errors: 0 };
    var named = '';
    var input = false;
    var virtualSource = '';
    var events = 0;
    var reason = '';
    var selectedTarget = activeTarget;
    var selectedLabel = activeTargetLabel;
    var targetCount = scanTargets.length;

    if (targetCount > 1 && !selectedTarget) {
      reason = 'target_required';
    } else if (selectedTarget) {
      input = fillSpecificInput(selectedTarget, item.text, item.pressEnter);
      if (!input && targetCount > 1) reason = 'target_fill_failed';
    }

    if (!reason && !input) {
      captured = invokeLatestCaptured(item.text);
      if (!captured.called) named = invokeOneNamed(item.text);
      if (!captured.called && !named) virtualSource = queueVirtualScan(item.text);
      if (!captured.called && !named && !virtualSource) input = fillBestInput(item.text, item.pressEnter);
      if (!captured.called && !named && !virtualSource && !input) events = dispatchFallbackEvents(item.text);
    }

    var ok = !!(captured.called || named || virtualSource || input);
    if (!ok && !reason) reason = 'scanner_not_ready';
    var result = {
      ok: ok,
      callbacks: captured.called,
      source: captured.source || virtualSource,
      named: named,
      virtual: virtualSource,
      inputs: input ? 1 : 0,
      events: events,
      errors: captured.errors,
      captured: callbacks.length,
      queued: queue.length,
      sources: callbackSources(),
      requestId: item.requestId || '',
      text: item.text,
      target: selectedLabel || '',
      targetCount: targetCount,
      targetSelected: !!selectedTarget,
      reason: ok ? '' : reason
    };

    if (reason === 'target_required') report('Sentuh kolom tujuan scan terlebih dahulu.');
    else if (reason === 'target_fill_failed') report('Kolom tujuan tidak dapat diisi. Sentuh ulang kolom tujuan.');
    else if (input && selectedLabel) report('Kode dikirim ke ' + selectedLabel + '.');
    else if (captured.called) report('Kode terkirim ke scanner aktif.');
    else if (named) report('Kode terkirim lewat ' + named + '.');
    else if (virtualSource) report('Kode dikirim lewat jalur ' + virtualSource + '.');
    else if (input) report('Kode diisi ke kolom scan.');
    else report('Scanner belum siap. Buka ulang menu Scan QR.');

    androidCall('onSendReport', [JSON.stringify(result)]);
  }

  function processQueue() {
    if (processing || destroyed) return;
    processing = true;

    function next() {
      if (destroyed || !queue.length) {
        processing = false;
        return;
      }
      var item = queue.shift();
      try { processOne(item); } catch (_) {}
      w.setTimeout(next, SEND_GAP_MS);
    }

    next();
  }

  function send(text, requestId, pressEnter) {
    text = String(text == null ? '' : text).trim();
    if (!text) {
      report('Kode masih kosong.');
      return JSON.stringify({ ok: false, reason: 'empty' });
    }

    patch();
    refreshScanTargets(false);
    if (scanTargets.length > 1 && !activeTarget) {
      report('Sentuh kolom tujuan scan terlebih dahulu.');
      return JSON.stringify({ ok: false, reason: 'target_required', targetCount: scanTargets.length });
    }

    var stamp = now();
    if (recent[text] && stamp - recent[text] < DUPLICATE_MS) {
      report('Kode sama baru saja diproses.');
      return JSON.stringify({ ok: false, reason: 'duplicate' });
    }
    recent[text] = stamp;
    cleanupRecent();

    if (queue.length >= MAX_QUEUE) {
      report('Antrean scan penuh. Tunggu sebentar.');
      return JSON.stringify({ ok: false, reason: 'queue_full', queued: queue.length });
    }

    queue.push({ text: text, addedAt: stamp, requestId: String(requestId == null ? '' : requestId), pressEnter: pressEnter !== false });
    processQueue();
    return JSON.stringify({ ok: true, queued: queue.length, processing: processing });
  }

  function status() {
    patch();
    return JSON.stringify({
      version: VERSION,
      callbacks: callbacks.length + virtualRouteCount(),
      capturedCallbacks: callbacks.length,
      virtualRoutes: virtualRouteCount(),
      sources: callbackSources(),
      queued: queue.length,
      processing: processing,
      html5Qrcode: typeof w.Html5Qrcode === 'function',
      html5Scanner: typeof w.Html5QrcodeScanner === 'function',
      prewarmDone: prewarmDone,
      prewarmAttempts: prewarmAttempts,
      suppressNextScannerStart: suppressNextScannerStart,
      targetCount: scanTargets.length,
      targetSelected: !!activeTarget,
      target: activeTargetLabel || ''
    });
  }

  function destroy() {
    destroyed = true;
    clearPatchTimers();
    queue = [];
    callbacks = [];
    pendingVirtualScans = [];
    barcodeDetectorActive = false;
    jsQrActive = false;
    scanTargets = [];
    clearActiveTarget('destroy', true);
    try { if (observer) observer.disconnect(); } catch (_) {}
    observer = null;
    reportCount(true);
  }

  w.__LPWScannerBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    status: status,
    report: report,
    destroy: destroy,
    prewarm: prewarmScanner,
    getCallbackCount: function () { return callbacks.length + virtualRouteCount(); },
    getTarget: function () { return { label: activeTargetLabel || '', count: scanTargets.length, selected: !!activeTarget }; },
    clearTarget: function () { clearActiveTarget('manual', true); refreshScanTargets(false); }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
    w.addEventListener('pagehide', function () {
      clearPatchTimers();
      queue = [];
      clearActiveTarget('navigation', true);
    }, false);
  } catch (_) {}

  patch();
  installObserver();
  schedulePatch();
  schedulePrewarm();
  report('Tools siap. Jika ada banyak kolom scan, sentuh kolom tujuan terlebih dahulu.');
})();
