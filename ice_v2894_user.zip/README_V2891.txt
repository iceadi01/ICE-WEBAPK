ICE Inject v2.8.9.1

- Fitur dual jaringan, Wi-Fi lokal khusus, auto-connect SSID, dan pemaksaan jalur data seluler dihapus.
- WebView, login/lisensi, Tampermonkey/bridge, tab, bookmark, scanner, antrean, dan foto QR tetap dipertahankan.
- Semua koneksi sekarang mengikuti jaringan default yang dipilih Android.
- versionCode dinaikkan menjadi 30 agar dapat dipasang sebagai pembaruan dari v2.8.9.
