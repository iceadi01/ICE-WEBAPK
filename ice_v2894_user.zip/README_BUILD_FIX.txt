Build fix v2.8.6:
- Menonaktifkan lint release yang menggagalkan build karena targetSdk 27 lama.
- targetSdk 27 sengaja dipertahankan untuk kompatibilitas perilaku jaringan aplikasi.
- Fitur aplikasi tidak diubah.
