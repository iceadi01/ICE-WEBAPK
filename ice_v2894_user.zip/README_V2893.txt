ICE Inject v2.8.9.3 - Pilih Tujuan Scan

- Jika halaman hanya memiliki 1 kolom scan, tujuan dipilih otomatis.
- Jika halaman memiliki 2 atau lebih kolom scan, pengguna wajib menyentuh kolom tujuan.
- Kolom terakhir yang disentuh tetap menjadi tujuan selama halaman tidak di-refresh.
- Sentuh kolom lain untuk memindahkan tujuan scan seketika tanpa refresh.
- Refresh, pindah URL/halaman, atau kembali dari halaman lain mereset tujuan menjadi belum dipilih.
- Input Tampermonkey, input ICE, foto QR, dan antrean memakai tujuan aktif yang sama.
- Antrean dijeda aman jika tujuan belum dipilih; kode tidak dibuang atau salah masuk.
- Tujuan aktif diberi garis hijau dan badge TUJUAN pada panel ICE.
- Callback scanner tetap dipersiapkan otomatis tanpa membuka kamera.
- versionCode 32.
