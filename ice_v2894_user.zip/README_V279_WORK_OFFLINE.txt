ICE Inject v2.7.9 USER work-offline build

Tujuan:
- Tetap USER build, bukan admin.
- Tetap wajib key.
- Cocok untuk kerja di WiFi perusahaan yang tidak punya internet tetapi butuh akses web lokal.

Cara kerja:
- Aktivasi pertama wajib internet.
- Saat ada internet, APK cek server seperti biasa. Kalau key dihapus/cabut/reset HP di dashboard, APK akan terkunci saat server menjawab tidak aktif.
- Kalau sedang di WiFi lokal tanpa internet, APK boleh tetap masuk memakai cache lisensi aktif maksimal 12 jam sejak cek online terakhir.
- Mode offline tidak memperpanjang key. Jika key expired, APK tetap terkunci.
- Setelah internet tersedia lagi, APK cek ulang server. Jika key sudah dihapus/cabut/reset, APK terkunci.

Penting:
- Server/website yang disarankan: ICE License v6.6 atau lebih baru.
- Kalau ingin benar-benar terkunci segera setelah key dihapus, pengguna harus tersambung internet dan APK harus jalan/terbuka.
