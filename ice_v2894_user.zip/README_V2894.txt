ICE Inject v2.8.9.4 - Strict Scan Target

Perbaikan:
- Kolom pencarian Google/Bing/Yahoo/DuckDuckGo tidak dapat menjadi tujuan scan.
- Input umum, login, email, password, pencarian, dan query diabaikan.
- Tujuan scan hanya kandidat dengan penanda tegas HU, carton, material, barcode, QR, atau scan pada ID/name/placeholder/label.
- Mempertahankan pindah tujuan tanpa refresh; refresh/pindah halaman tetap mereset pilihan.
- Menambah dukungan jalur BarcodeDetector, jsQR, ZXing, dan qrcode.callback.
- CB menghitung callback atau jalur scanner yang benar-benar aktif, bukan input biasa.
- versionCode 33.
