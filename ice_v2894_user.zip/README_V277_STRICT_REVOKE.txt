ICE Inject v2.7.7 USER strict revoke build

Fix penting:
- Tetap USER build, bukan admin.
- Tetap wajib key.
- Setelah APK aktif, APK cek server berkala ±20 detik saat aplikasi dipakai.
- Jika key dihapus, dicabut/revoked, expired, atau perangkat di-reset dari dashboard, APK akan terkunci saat online.
- Endpoint check memakai strict_device_check=1 agar device tidak otomatis bind ulang dari key lama.

WAJIB dipasangkan dengan ICE License Server v6.6 agar tombol Reset HP/Copot Perangkat langsung mengunci APK lama.
