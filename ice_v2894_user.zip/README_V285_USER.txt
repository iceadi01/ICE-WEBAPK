ICE Inject User v2.8.5

MODE USER
- Nama aplikasi: ICE Inject
- Package: com.mimar.iceinject
- ADMIN_BUILD=false
- Version code: 25
- Version name: 2.8.5
- Bisa dipasang berdampingan dengan ICE Inject Admin karena package admin berbeda.

LOGIN USER
- User wajib login memakai username dan password dengan koneksi internet/data setiap APK dibuka dari awal.
- Setelah login berhasil, APK dapat dipakai pada Wi-Fi perusahaan tanpa internet selama proses aplikasi masih hidup.
- Jika APK ditutup paksa/proses mati, sesi memori hilang dan user harus login kembali memakai internet.
- Saat internet tersedia, status akun diperiksa berkala. Akun yang dinonaktifkan/dihapus akan terkunci pada pemeriksaan berikutnya.
- Server bawaan: https://accuracy.fwh.is
- Endpoint: /login-app.php dan /check-session.php

FITUR FOTO QR
- Tekan tombol "Foto QR lalu scan".
- Kamera terbuka untuk menjepret QR/barcode.
- Foto hanya disimpan sementara di cache, tidak masuk galeri.
- Setelah dijepret, kode dibaca otomatis dan langsung dikirim ke bridge scanner.
- File sementara dihapus setelah proses selesai.

FITUR YANG TETAP ADA
- Scanner/bridge, input keyboard, antrean QR massal, tab, bookmark, zoom, mode desktop, GPS, dan pengaturan lainnya tetap tersedia.

CATATAN BUILD
- Source ini memakai compile SDK 34, Android Gradle Plugin 8.5.2, Gradle 8.7, dan Java 17.
- Untuk memperbarui APK user lama tanpa uninstall, APK harus ditandatangani dengan keystore yang sama di folder signing.
- Repository yang memuat folder signing WAJIB Private. Jangan unggah ke repository Public.
