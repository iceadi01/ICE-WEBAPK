ICE Inject v2.7.8 USER strict online build

Fix penting:
- Tetap USER build, bukan admin.
- Tetap wajib key.
- Tidak ada mode offline untuk USER build.
- Saat aplikasi dibuka, cache lisensi tidak langsung membuka browser; APK harus cek server dulu.
- Jika internet mati / server tidak bisa dicek / key dihapus / key dicabut / device di-reset, APK terkunci.
- Saat aplikasi sedang dipakai, cek server berkala ±15 detik.
- Wajib dipakai bersama server license v6.6 atau lebih baru.

Cara test:
1. Install APK v2.7.8.
2. Aktivasi key.
3. Buka dashboard web, hapus/cabut/reset HP pada key.
4. Tunggu ±15 detik atau tutup-buka APK. APK harus kembali terkunci.
5. Matikan internet lalu buka APK. APK harus tetap terkunci/tidak masuk sampai server bisa dicek aktif.
